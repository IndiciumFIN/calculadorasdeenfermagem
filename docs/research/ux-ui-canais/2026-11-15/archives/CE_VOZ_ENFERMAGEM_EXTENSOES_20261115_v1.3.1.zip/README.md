# CE · Voz da Enfermagem · Extensões / Widgets · v1.3.1
Complemento incremental de evidências ao pacote v1.3.0. Não modifica código, contratos nem matrizes anteriores. Evidência ≠ homologação de solução.
