# Pesquisa exploratória de demandas ocultas da enfermagem v1.4.0

Complemento documental incremental dos planos anteriores, com 24 candidatos e evidências identificáveis. Não é uma homologação do Registry ou do código.
