# Plano executivo reconciliado F0–F6 — Área do Assinante, Administrador e Marketplace

**Versão:** 1.0.0 · **Data:** 2026-11-15 · **Estado:** candidato, não implementado.  
**Invariantes:** não criar segundo site; não promover sem testes; preservar geradores e contratos canônicos; só alterar arquivos mediante WO validada; manter originais e evidências SHA-256; não afirmar independência Maker/Checker inexistente.

## Escopo transversal

**Shell único:** sidebar responsiva de dois níveis (desktop >=1200 px como proposta do plano), busca global visível, centro de alertas, perfis Plantão/Completo/Gestão, conta sempre alcançável e barra inferior mobile. São experiências separadas por papel, mas sem duplicar componentes. O mesmo contrato de visualização recebe rotas/ações permitidas do servidor.

**Templates T1–T7:** Painel; Lista com filtros; Detalhe; Wizard; Configurações em abas; Tabela financeira; Estados de vazio/erro/carregamento/sem permissão. Preservar DS, header/footer e fontes do projeto; slots governados para conteúdo e política. A camada UX nunca define direitos financeiros ou clínicos.

**Módulos comercializáveis:** Pesquisa científica, Currículo, Trilhas e Concursos. Os serviços são envelopes comerciais de capacidades canônicas existentes/novas, com contrato de versão e habilitação independente; simulados e revisão espaçada são motores compartilhados.

## Sequência e critérios de aceite

| Fase | Entregas | Gate de saída (objetivo) |
|---|---|---|
| **F0 — Inventário & arquitetura** | reconciliar ZIPs, identificar fonte de verdade, modelos de permissão/dados, decisão de infraestrutura e provedor, contratos e WOs | inventário+SHA; arquitetura sem duplicações; SQL/API candidatos; nenhuma credencial em pacote; decisões pendentes registradas |
| **F1 — Identidade & autorização** | sessão real, RBAC/ABAC, MFA admin, RLS no DB, servidor de direitos de acesso, auditoria, testes de escalonamento | acesso não autorizado recebe 401/403; isolamento por usuário; MFA para admin; nenhum endpoint privilegiado público |
| **F2 — Shell & Central do Assinante** | shell compartilhado, busca, alertas, perfil, favoritos, histórico, preferências, telas de contratos/assinatura/pagamentos inicialmente por dados de teste de servidor | desktop/tablet/mobile, teclado/leitor de tela, estados vazios, dados sincronizados, sem DOM perigoso e sem prometer transação ativa |
| **F3 — Admin & catálogo canônico** | usuários/papéis, serviços/flags, pacotes/ofertas, preços versionados, contratos versionados, auditoria e operação financeira de leitura; integrações controladas | todas as alterações auditadas, schema validado, funcionalidades bloqueadas por papel, testes de não regressão dos 70 configs |
| **F4 — Quatro serviços** | capacidades Pesquisa, Currículo, Trilhas, Concursos conectadas por contratos, sem duplicar motor de simulados/revisão; feature flag e sandbox | direitos e cotas com testes negativos; sem dados de pacientes; cobertura de APIs; revisão clínica e das fontes pertinentes |
| **F5 — Cobrança & conformidade** | provedor(s), autorização Pix quando suportada, cartão tokenizado, boleto/Pix avulso, webhook assinado, conciliação, chargeback, reembolso, cancelamento, NFS-e conforme regime aplicável, LGPD e CDC | eventos idempotentes; acerto de faturas/ledger; contrato aceito antes de compra; estorno/arrependimento validado; recuperação de falha sem falsos direitos |
| **F6 — Migração & lançamento controlado** | importação consentida do localStorage; rollback, observabilidade, backup, degradação segura, testes multiviewport, i18n, SEO público e lançamentos progressivos | restauração testada; cobertura E2E/smoke; acessibilidade; aprovação canônica; sem divergência de contrato; nenhuma regressão crítica; publicação apenas autorizada |

F2–F5 podem ser elaboradas em ramos técnicos paralelos, mas nenhuma etapa é considerada concluída sem seus gates; F4 deve operar primeiro em sandbox até o pagamento F5 estar validado.

## Contratos de dados mínimos

| Domínio | Fontes/tabelas candidatas | Regras |
|---|---|---|
| Identidade | `users`, `profiles`, `roles`, `memberships`, `sessions` | reutilizar esquema de autenticação efetivamente eleito, não replicar usuários entre bancos |
| Catálogo | `capabilities`, `services`, `service_capabilities`, `packages`, `package_services`, `price_versions`, `offers` | IDs estáveis do Kernel; versionamento e relações N:N; flags separadas da disponibilidade |
| Direitos | `subscriptions`, `subscription_items`, `entitlement_events`, `entitlement_projections`, `quota_counters` | evento imutável -> projeção; assinatura ativa isoladamente não concede serviço inexistente |
| Contratos | `contract_templates`, `contract_versions`, `acceptances`, `amendments` | hash conteúdo; versionamento; aceite auditável; download do texto de aceite |
| Financeiro | `invoices`, `payment_attempts`, `provider_events`, `refunds`, `disputes`, `pix_authorizations`, `financial_ledger_entries` | idempotência, retenção fiscal, moeda em unidade mínima, estados separados, reconciliação |
| Experiência | `favorites`, `collections`, `notes`, `history`, `study_plans`, `alerts`, `preferences` | RLS por pessoa; migração explícita de dados do navegador |
| Serviços | registros canônicos de questões/editais, pesquisas/referências, currículo versionado, progresso de trilha | proveniência + escopo privado + reutilização do motor existente |
| Governança | `work_orders`, `policy_decisions`, `audit_events`, `source_registry`, `review_evidence`, `feature_flags` | não inventar IDs oficiais; Kernel numera/valida conforme política efetiva |

### Contrato de API candidato (não endpoint implementado)

- `GET /api/me/capabilities`: retorna capacidade, direito, cota, razão de bloqueio sem revelar dados de outros usuários.
- `GET /api/me/subscription`, `/contracts`, `/invoices`, `/alerts`: sempre autorizados por sessão e escopo.
- `POST /api/billing/checkout-intent`: cria intenção server-side, sem receber valor do cliente como autoridade.
- `POST /api/billing/webhooks/{provider}`: autenticação por assinatura do provedor e evento idempotente.
- `GET/POST /api/admin/services` e `/packages`: políticas de papéis no servidor, versionamento e auditoria.
- `POST /api/privacy/export-request`, `/delete-request`: canalização de requerimentos com estado de atendimento.

## Estados comerciais canônicos

**Serviço:** `draft` → `preview` → `public` → `sales_paused`/`sunset` → `retired`, com `runtime_access` condicionado à vigência de direitos. Uma oferta invisível não equivale a serviço indisponível para clientes legados.

**Assinatura:** `incomplete` → `trialing`/`active` → `past_due` → `paused`/`canceled`; os eventos do provedor controlam as projeções de cobrança; eventos de cortesia seguem fluxo distinto. Datas efetivas e direitos preservam histórico. Casos de chargeback não devem ser confundidos com cancelamento voluntário.

**Fatura:** `draft` → `open` → `paid`/`void`/`uncollectible`; pagamentos têm tentativas/estornos independentes; conciliação não infere liquidação do simples envio de checkout.

## Conflitos que o plano original precisa resolver

1. “Desabilitar remove da API imediatamente” versus manter acesso durante período pago: implementar controle de visibilidade/venda separado da execução do direito existente.
2. “Admin vê tudo” versus LGPD e minimização: escopo por necessidade e mascaramento, não acesso indiscriminado a currículo, notas ou dados pessoais.
3. “2 pessoas para ações sensíveis” versus operação por mantenedor único: não simular aprovação; separar situações com HOLD e controles compensatórios revisáveis.
4. “Somente webhook concede direitos” versus concessão manual: ambos criam eventos com proveniência distinta; apenas o webhook pode declarar liquidação financeira.
5. “Fase 4 publica serviços” versus “Fase 5 cria cobrança”: F4 é sandbox/flagged; comercialização somente após F5.
6. O plano original remete a **7 fases** mas não contém um quadro completo F0–F6; esta versão materializa a sequência sem atribuir prazos inventados.

## Matriz resumida de testes obrigatórios

- Segurança: IDOR horizontal/vertical, acesso admin sem MFA, autenticação desligada, token expirado, mutação de preço sem permissão, bypass por URL pública.
- Financeiro: webhook repetido e fora de ordem, pagamento recusado, disputa, cupom, prorrata, cobrança duplicada, alteração retroativa de preço, falha no Pix, conciliação independente.
- Consumidor: direito de arrependimento, cancelamento self-service sem obstáculos, cópia de contrato, recibo, estorno, confirmação compreensível.
- Dados: RLS, exportação, exclusão quando aplicável, retenção fiscal, dados privados vazando na busca, sincronização/migração do localStorage.
- UX: 360/768/1200/1440px, teclado, screen reader, `prefers-reduced-motion`, Ctrl+K e `/`, loading, vazio, no-access, busca sem resultado, menu responsivo.
- Canonical: geradores `--check`, 70 configs preservadas, IDs sem colisão, registros de fonte/evidência, gates de publicação e no-duplicate.

## Fontes normativas que devem ser registradas na matriz de autoridades

- Lei 8.078/1990, art. 49 — texto oficial Planalto: https://www.planalto.gov.br/ccivil_03/leis/l8078compilado.htm
- Decreto 7.962/2013 — comércio eletrônico: https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2013/decreto/d7962.htm
- Resolução BCB nº 1/2020 consolidada, incluindo dispositivos do Pix Automático: https://www.bcb.gov.br/estabilidadefinanceira/exibenormativo?numero=1&tipo=Resolu%C3%A7%C3%A3o+BCB
- ANPD, direitos dos titulares: https://www.gov.br/anpd/pt-br/assuntos/titular-de-dados-1/direito-dos-titulares

Estas URLs são fontes oficiais de contexto. Regras específicas e versões devem ser registradas com snapshot e revisadas juridicamente antes de transações reais.
