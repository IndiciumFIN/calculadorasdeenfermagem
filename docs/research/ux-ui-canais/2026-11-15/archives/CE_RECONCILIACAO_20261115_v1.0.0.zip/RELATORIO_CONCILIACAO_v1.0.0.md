# Conciliação técnica independente — Assinante, Administrador e Marketplace

**Versão:** 1.0.0 · **Data:** 15/11/2026 · **Natureza:** análise de pacotes locais, não implantação.  
**Fonte funcional:** `Texto colado.txt` (Plano completo — Área do Assinante, Área do Administrador e Marketplace de Ferramentas por Serviço).  
**Fontes de implementação:** 12 ZIPs e 3 documentos auxiliares fornecidos no mesmo envio.  
**Preservação:** nenhum ZIP original alterado; nenhuma publicação, merge ou mutação de banco de dados.

## 1. Veredito

A proposta de produto é coerente na visão geral, mas **não pode ser tratada como pronta para desenvolvimento pago**. O conjunto contém duas famílias de código que precisam de integração planejada:

1. **Static/UX** (`enfcare*`, `calculadoras-de-enfermagem-ux-ui`, `mobile-first-2.1.0`): site gerado deterministicamente a partir de configurações, páginas públicas de Assinante e Admin, estado local, 70 ferramentas clínicas. A área do administrador é declaradamente pública e somente leitura; não é um painel protegido.
2. **Grok workspace** (`xOZ*`, `oq0*`, `WZ*`): frontend React/TanStack para outro recorte do site, publicação estática em `plataforma/`, Better Auth e infraestrutura Postgres/Neon/PGLite. A única migration SQL identificada é `migrations/auth/0001_auth.sql` com tabelas de identidade/sessão. A autenticação documenta `VITE_AUTH_ENABLED=false` como padrão distribuído. Não foram encontrados contratos de cobrança ou direitos de serviço no código `src/`, `migrations/` e `scripts/`.

**Conclusão:** não assumir que a autenticação Grok já protege as rotas HTML do Assinante/Admin. Não promover artefatos compilados (`.vercel/output`) como fontes canônicas. É necessário definir fronteiras e integrar autenticação, direitos e dados do servidor antes de monetizar.

## 2. Conciliação de versões

| Família | Arquivos | Evidência | Tratamento |
|---|---:|---|---|
| `enfcare.zip` até `(3)` | 415–417 | alterações incrementais em 1 a 7 arquivos por versão | preservar como histórico de origem; revisar diferenças antes de substituir |
| `enfcare (4)/(5)/(6)` | 417 cada | os três ZIPs têm mesmo SHA-256 integral | duplicata exata; reter um exemplar como referência |
| `calculadoras-de-enfermagem-ux-ui.zip` | 418 | 415 arquivos comuns a `enfcare (4)` idênticos por CRC32+tamanho; contém 3 logs adicionais | candidato a fonte estática de análise, sem assumir homologação |
| `calculadoras-de-enfermagem-mobile-first-2.1.0.zip` | 407 | 388 arquivos comuns iguais, 16 modificados comparado a `enfcare (4)` | baseline anterior, não mesclar no escuro |
| `xOZ*` e `oq0*` | 1810 cada | 1809 arquivos internos iguais; alteração apenas `.grok/status` | conteúdo funcional aparente equivalente; hashes dos ZIPs diferem |
| `WZ*` | 1796 | 1779 arquivos internos comuns iguais a `xOZ*`; 11 diferentes, 20 só em `xOZ*`, 6 só em `WZ*` | ramo distinto, sobretudo conteúdo `estudos`; reconciliar por origem canônica |

Arquivos e hashes completos estão em `INVENTARIO_ZIPS_SHA256_v1.0.0.json`. A comparação por conteúdo interno usa CRC32 e tamanho; para a duplicação perfeita dos 3 `enfcare` foi usado SHA-256 integral do ZIP.

### Manifesto mobile-first

- O SHA-256 integral de `calculadoras-de-enfermagem-mobile-first-2.1.0.zip` confere com o arquivo `.zip.sha256` anexado.
- Todos os **406** arquivos listados em `manifesto-mobile-first.json` coincidem em tamanho e SHA-256 com o conteúdo do ZIP.
- O ZIP tem **407** arquivos: `docs/manifesto-mobile-first.json` está excluído da própria relação (autorreferência evitada). **Não é, por si só, falha de integridade.**

## 3. Auditoria reproduzida no pacote `calculadoras-de-enfermagem-ux-ui.zip`

Foi executada uma cópia isolada em `/tmp`, sem escrever no pacote original:

| Verificação | Resultado observado | Escopo / reserva |
|---|---|---|
| `python3 tools/auditar.py` | **PASS** — sem falhas bloqueantes, fila clínica 0 | fontes JSON, cascas, rotas, referências e links |
| `python3 tools/gerar_paginas.py --check` | **PASS** | sincronismo de ferramentas |
| `python3 tools/gerar_conteudo.py --check` | **PASS** | sincronismo de conteúdo |
| `python3 tools/gerar_areas.py --check` | **PASS** | sincronismo Assinante/Admin/Acesso |
| `python3 tools/gerar_manus_routes.py --check` | **PASS** | rotas de integração |
| `node tools/minificar-ux-css.mjs --check` | **PASS** | saída minificada sincronizada |
| `node tools/gate_app.mjs` | **NÃO EXECUTADO COM SUCESSO** | falta dependência `playwright-core` nesta cópia local; não atribuir PASS ao teste de browser |

**FIND-001 — dois falsos candidatos potenciais à exclusão:** o auditor lista `assets/css/areas-ux.css` e `assets/css/home-ux.css` como “órfãos” porque as páginas referenciam os arquivos minificados. Contudo, ambos são fontes legíveis dos arquivos `.min.css` e estão vinculados ao processo de minificação. Não os excluir sem verificar dependência de build.

## 4. Evidências de telas e recursos existentes

- **Assinante:** `templates/area-assinante.html`, `assinante/index.html`, `assets/js/app-area.js`, `assets/js/app-listas.js`. Há perfis de uso Plantão/Completo/Gestão, favoritos, histórico, catálogo de ferramentas e preferências. A captura `docs/evidencias-mobile/assinante-04-trilho-desktop-1440.png` já mostra trilho lateral simples de 4 itens; portanto, “sem sidebar” do texto de referência não descreve exatamente este ZIP. Falta a **sidebar de 2 níveis e com módulos de negócio** planejada.
- **Admin:** `templates/area-admin.html`, `admin/index.html`; catálogo derivado de `configs/paginas`, filtros e saúde do pipeline. É uma visão operacional do conteúdo, sem RBAC e sem transações de receita.
- **Acesso:** `conta/login.html`, `templates/area-acesso.html`, `assets/js/app-acesso.js`; é um **hub de navegação pública**, não uma tela de login real.
- **Modelo clínico:** 70 configurações em `configs/paginas/`; geradores e auditorias preservados. O relatório mobile-first descreve 51 ferramentas `score`, 17 `formula`, 2 `named`; a categorização “61 escalas + 9 calculadoras” do plano vem de outra taxonomia e deve ser conciliada no registro, não presumida equivalente.
- **Busca:** existe rota pública `busca.html`, mas não uma busca global de sessão cobrindo conteúdo pessoal, faturas, contratos e serviços com permissões.
- **Grok:** `src/lib/auth/*`, `src/lib/db.ts`, `migrations/auth/0001_auth.sql` permitem estudar infraestrutura de identidade; não implementam, isoladamente, marketplace, cobrança ou direitos de uso.

## 5. Achados críticos por prioridade

| ID | Severidade | Achado | Decisão/controle proposto |
|---|---|---|---|
| F-01 | Crítica | Assinante/Admin no ZIP estático são páginas públicas; nenhuma garantia de sessão | backend obrigatório, auth real, autorização no servidor, proteção de endpoints e dados |
| F-02 | Crítica | Duas bases técnicas coexistem sem contrato de integração | designar repositório/branch e fronteira canônica do app, evitar segundo site |
| F-03 | Crítica | Sem esquema de serviços, pacotes, versões de preço, assinatura, direitos, cobranças ou contratos | criar contratos versionados e migrations sob WO; nunca recriar conteúdo clínico |
| F-04 | Alta | Regra 'serviço desligado desaparece da API' contradiz 'assinante atual mantém acesso' | separar `catalog_visibility`, `sales_status` e `runtime_status`; garantir direito até vencimento quando aplicável |
| F-05 | Alta | Falta prova de origem de pagamento/contrato e trilha de eventos | webhooks validados e idempotentes, ledger imutável, reconciliação financeira independente |
| F-06 | Alta | Plano anuncia sete fases, mas não detalha F1 e F6 nem a matriz de gates | completar F0–F6 em plano de implementação |
| F-07 | Alta | Teste de navegador não reexecutado por dependência não instalada | instalar dependências em ambiente permitido e executar E2E, acessibilidade, multiviewport e casos negativos |
| F-08 | Alta | Uso de `localStorage` para preferências; migração para conta ainda inexistente | exportação/importação assistida, compatibilidade e não armazenar dados sensíveis ali |
| F-09 | Alta | Reembolso condicionado a não uso mencionado no plano exige análise de conformidade | revisão jurídica do art. 49 do CDC, Decreto 7.962/2013 e fluxo de arrependimento |
| F-10 | Alta | Pix Automático tratado como detalhe da UI, sem ciclo de autorização/cancelamento/retries | modelo de autorização e estados aderente às regras atuais do BCB e provedor contratado |
| F-11 | Média | Potencial falso positivo de 'órfãos' CSS | considerar fontes geradoras como dependências, não excluir |
| F-12 | Média | Busca global e avisos de cobrança inexistentes na casca atual | criar contratos de busca, notificações e escopos de visibilidade por papel |
| F-13 | Alta | Admin de controle financeiro não dispõe de segregação de funções verificável | papéis, MFA, limiares, auditoria independente e controles compatíveis com mantenedor único |
| F-14 | Média | Ferramentas novas podem duplicar motores clínicos/educacionais | catálogo canônico, serviços como composição de capacidades e direitos, não cópias de ferramentas |

## 6. Ajustes obrigatórios do modelo de negócio

### Separar conceitos

- **Capability (capacidade):** implementa um motor reutilizável (simulados, pesquisa, currículo, revisão espaçada).
- **Service (serviço comercial):** liga capacidades a um público, termos, limites, experiência e visibilidade.
- **Offer (oferta):** exibe condições comerciais e eventuais cupons, sem conceder direitos.
- **Package (pacote):** agrega serviços e cotas, versionados.
- **Price version:** valor, moeda, impostos, início de vigência, ciclo; não sobrescrever um contrato já aceito.
- **Entitlement (direito de acesso):** derivado de evento válido de assinatura/pagamento, cortesia autorizada ou licença; servidor valida vigência/cota.
- **Service availability:** `draft`, `preview`, `public`, `sales_paused`, `sunset`, `retired`; a exibição no catálogo não equivale ao acesso de quem já comprou.
- **Contract version / acceptance:** termos com hash, idioma, escopo, data e evidência de aceite, retenção e exportação.

### Regras de alto risco

1. A resposta da API deve ser autorizada por sessão + papel + direito + escopo do recurso + disponibilidade; não basta ocultar botões.
2. Webhooks devem verificar assinatura do provedor, armazenar o ID externo com índice único e processar idempotentemente, mesmo com eventos fora de ordem.
3. Reembolso, chargeback, disputa, pagamento parcial, troca de plano, prorrata e cancelamento requerem estados e reconciliação próprios; Pix/Stripe não devem ser assumidos compatíveis sem checagem do contrato do provedor.
4. Logs de auditoria *append-only* por aplicação não bastam sozinhos como imutabilidade; adicionar proteção de banco, integridade/hash, retenção e acesso separado.
5. Aprovação a duas pessoas não pode ser apresentada como executada quando há um único mantenedor. Usar controles técnicos compensatórios verificáveis e manter casos que exigem segunda pessoa em HOLD até existir aprovador legítimo.
6. Serviços não podem admitir dados de pacientes em campos de perfil, notas, currículo ou busca; testar explicitamente ausência de vazamento.

## 7. Limites desta revisão

- Nenhum repositório GitHub, Supabase, banco de produção, provedor de pagamento ou website em operação foi consultado ou alterado. Não declarar implantação ou homologação de produção.
- A identidade visual foi inspeccionada por páginas e captura embutida, mas não há novo teste completo com browser nesta análise.
- Resultados de testes embutidos nos ZIPs foram tratados como evidências históricas, não como execução atual, exceto os comandos explicitamente reproduzidos acima.
- Este relatório não substitui parecer jurídico, revisão clínica assinada nem testes de segurança especializados.

## 8. Decisão técnica

**HOLD para promoção a produção paga. PASS para aproveitar os geradores, catálogo canônico, design system e componentes existentes como ponto de partida.** Executar a sequência F0–F6 do arquivo `PLANO_EXECUCAO_F0_F6_v1.0.0.md` com gates mensuráveis e isolação de branch. O módulo de assinaturas deve ser acrescentado por composição, não por forks de conteúdo.
