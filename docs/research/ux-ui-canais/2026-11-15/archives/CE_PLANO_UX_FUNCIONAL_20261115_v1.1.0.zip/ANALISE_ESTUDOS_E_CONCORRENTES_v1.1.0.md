# Revisão de evidências — Enfermagem, escalas, handover e UX (2026-11-15)

## Hierarquia de evidências (uso correto)

- **Norma/órgão oficial** define requisitos dentro de seu escopo; não mede satisfação da nossa interface.
- **Estudo empírico com enfermeiros** mede uma amostra e uma aplicação concreta; não prova que copiar o visual melhora a nossa.
- **Benchmark comercial** evidencia uma funcionalidade e sua comunicação de produto; não prova redução de erros, segurança ou usabilidade.
- **Proposta interna** é hipótese a ser validada com usuários reais, não dado externo.

## 1. Estudos relevantes

**Escalas de plantão — Aksu e Dinç, BMC Nursing (2025).** Piloto de aplicativo móvel com 12 enfermeiros de oncologia, uso por um mês e satisfação geral de 8/10; o software trabalha com restrições, preferências e características profissionais. Os autores não fizeram uma comparação controlada objetiva de tempos, apesar da percepção de maior rapidez. **Aplicação**: rascunho, regras hard/soft, painéis distintos por perfil, validação e transparência do escalonamento. https://link.springer.com/article/10.1186/s12912-025-03370-9

**Passagem de plantão — Dematte et al., Rev Bras Enferm (2024).** Protótipo baseado em Design Thinking, usabilidade de 79 pontos e coeficiente de validade de conteúdo 0,7. Os autores afirmam que a implantação e seus efeitos sobre falhas de comunicação ainda requerem estudos. **Aplicação:** fluxos SBAR separados da agenda de turnos e necessidade de teste de efetividade. https://pubmed.ncbi.nlm.nih.gov/39607162/

**Urgência e passagem de plantão — Menolli et al. (2025).** Estudo de aceitabilidade/usabilidade com 20 enfermeiros dos contextos pré-hospitalar móvel e intra-hospitalar, no Paraná. **Aplicação:** testar jornadas específicas para emergência, não presumir que handover genérico atende todos os setores. https://revistas.unipar.br/index.php/saude/article/view/11551

**Rotina de trabalho por turnos — JMIR Formative Research (2026).** Trabalho de desenvolvimento e viabilidade, publicado em 30 de setembro de 2026; avaliou notificações sincronizadas aos turnos, ergonomia e carga de entrada. Participantes relataram dificuldades iniciais com navegação de calendário e dimensionamento/posicionamento de botões. **Aplicação:** agenda legível, botões fáceis de acertar, atalhos, entradas curtas, avisos ligados ao evento e métricas objetivas. https://formative.jmir.org/2026/1/e103689

## 2. Benchmark funcional de enfermagem

**Nursegrid (página oficial, consultada em novembro/2026)** descreve calendários de múltiplos empregadores, eventos pessoais, ícones e cores, lembretes, compartilhamento por link e feed iCal, além de visualização por smartwatch. A diferença de alto valor é unir cronograma de turnos à vida pessoal, sem apresentar tela clínica desnecessária. **Não é evidência de eficácia ou segurança**; testar desempenho e aceitação diretamente com nossos usuários. https://nursegrid.com/for-nurses/calendar

## 3. Normas e segurança

- **WCAG 2.2, critério 2.5.7:** alternativa de toque para arrastar, inclusive Kanban; teclado e foco continuam obrigatórios. https://www.w3.org/WAI/WCAG22/Understanding/dragging-movements
- **COFEN 736/2024:** o processo de Enfermagem inclui documentação no prontuário. `Passagem de plantão` com paciente não deve ser simulada como publicação da comunidade ou nota pessoal pública. https://www.cofen.gov.br/resolucao-cofen-no-736-de-17-de-janeiro-de-2024/
- **COFEN 743/2024:** revogou os parâmetros da Resolução 543/2017; verificar o Parecer Normativo 1/2024 antes de codificar regras de dimensionamento. https://www.cofen.gov.br/resolucao-cofen-no-743-de-12-de-marco-de-2024/
- **Anvisa / RDC 657/2022 (SaMD):** finalidade de uso determina eventual enquadramento; alarmes clínicos, interpretação de sinais e integração com equipamentos não podem nascer de um simples temporizador PWA. https://www.gov.br/anvisa/pt-br/assuntos/noticias-anvisa/2022/software-como-dispositivo-medico-perguntas-e-respostas
- **MDN Background Sync:** API não universal; PWA deve ter recuperação manual com tela de status. https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorkerRegistration/sync
- **HL7 FHIR:** nos serviços que adotam o padrão, updates condicionais via If-Match/ETag ajudam a detectar conflitos. https://hl7.org/fhir/R4/http.html
- **OMS:** princípios de fator humano e segurança acima de estímulos visuais e interações decorativas. https://www.who.int/publications/i/item/9789240032705

## 4. Protocolo de pesquisa primária recomendado

**Perfis**: enfermeiro assistencial, enfermeiro de urgência, gestor escalista, técnico de enfermagem, estudante, profissional com dificuldade motora ou visual. **Tarefas**: achar ferramenta de cálculo, reorganizar cards sem arrastar, pedir troca e enxergar estado, simular handover SBAR sem paciente, usar offline versão expirada, sincronizar conflitos, configurar alarme, personalizar tela. **Métricas**: sucesso sem ajuda, tempo até tarefa, quantidade de ações, erros críticos, interpretação de alertas/estados, contraste/leitor de tela, SUS/UMUX-Lite, NASA-TLX opcional. **Segurança**: cenário simulado e nenhum dado real de paciente na pesquisa aberta.

**Critério decisório:** não aprovar a interface apenas por SUS alto; falha grave em tarefa clínica deve impedir aprovação, ainda que satisfação geral seja alta. A análise é contínua por dispositivo, perfil e contexto.
