# Pacote incremental do planejamento UX/UI v1.1.0

Atualização do plano anterior `CE_PLANO_UX_FUNCIONAL_20261115_v1.0.0`. **Inclui apenas os deltas**, a matriz consolidada versão 1.1.0 e documentação nova. Os originais v1.0.0 devem permanecer preservados como baseline.

- `MATRIZ_PLANEJAMENTO_UX_UI_v1.1.0.xlsx` — **visão acumulada** com abas de 267 telas anteriores + 46 novas e demais registros.
- `ADENDO_WORKSPACE_PLANTAO_CLINICO_v1.1.0.md` — decisões de produto, telas, botões, animações, offline, sync, risco clínico e gates.
- `ANALISE_ESTUDOS_E_CONCORRENTES_v1.1.0.md` — evidência publicada com limitações.
- `NOVAS_TELAS/ACOES/ESTADOS/FUNCOES/COMPONENTES/ANIMACOES/JORNADAS/TESTES/ESTUDOS.csv` e `.json` — apenas deltas para conciliação canônica.
- `CONTRATOS_CONTROLES.csv/.json` — contrato ação por botão para 46 telas novas.
- `CONTRATOS_ENTIDADES.csv/.json` — entidades e camadas sem duplicidade.
- `MATRIZ_PLATAFORMAS.csv/.json` — suporte offline, sync e limitações por canal.
- `RESUMO_METRICAS.json` e `manifest-sha256.json` — cobertura e integridade.

IDs `UX-CAND-*` são provisórios, não IDs do Kernel. Nenhum SQL, frontend, backend ou pagamento foi implementado nesta etapa. Conectores e apps externos não foram alterados. A análise de implementação depende de reconciliação com os registros vivos e Work Order homologada.
