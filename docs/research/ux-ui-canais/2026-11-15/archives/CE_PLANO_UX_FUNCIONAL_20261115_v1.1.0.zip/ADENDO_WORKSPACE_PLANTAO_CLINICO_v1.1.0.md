# UX/UI canônico — adendo v1.1.0 (2026-11-15)

> **Natureza:** planejamento candidato, antes de implementar. Não significa homologação clínica, funcional ou de código. IDs `UX-CAND-*` são apenas referências locais; o Kernel deve atribuir os identificadores definitivos após validação de Work Order. Esta entrega não altera o repositório, Supabase, planos nem autorizações existentes.

## 0. Propósito e delta

O plano UX/UI anterior (v1.0.0) contempla 267 telas/vistas candidatas, 928 ações, 1.510 combinações de estado, 78 funcionalidades, 80 componentes, 53 microinterações e 20 jornadas. O adendo **não duplica** agendas, Kanban, modo urgência, offline, favoritos, notificações, personalização e sincronização que existiam como capacidades genéricas: especializa o fluxo, os contratos e os estados para uso real de enfermagem.

Esta versão acrescenta **46 telas**, **255 ações**, **355 estados**, **20 contratos funcionais**, **24 componentes candidatos**, **15 microinterações**, **12 jornadas** e **16 testes**, com 12 novas fontes de evidência. O escopo acumulado documentado é de **313 telas/vistas candidatas, 1.183 ações, 1.865 estados e 98 contratos funcionais**, sem afirmar que cada tela corresponde a um arquivo ou página independente.

## 1. Princípios de não duplicação

- **Canonical Content** guarda informação/ferramenta/protocolo e sua versão; **Design System** estabelece tokens e componentes reutilizáveis; **View Contract** posiciona slots conforme contexto; **Action Registry** declara a ação e seus pré-requisitos; **User State** guarda favorito, layout, progresso, agenda etc.; **Domain Service** executa lógica segura e verifica autoridade; **Evidence** comprova alterações e testes. Esses objetos são distintos.
- A mesma tarefa `Task` é apresentada por *Kanban*, lista, agenda e timeline; não há quatro bancos de tarefas. O mesmo `Shift` alimenta calendário, detalhe e troca; o mesmo `WidgetDefinition` pode gerar diferentes `WidgetInstance`, sempre com um componente oficial do DS.
- Cada ação tem `actionKey`, input schema, domínio, autorização, entitlement, política offline, confirmação, feedback, rollback e evento auditável. Nenhum menu simula uma execução que não ocorreu.
- O HERO e a Action Bar originais das bibliotecas não serão alterados. O modo clínico não coloca upsell, marketing, música, gamificação ou animações atrativas sobre resultados.

## 2. Telas e estrutura de navegação

### 2.1 App Shell e acessos permanentes

**Mobile:** barra superior com logotipo compacto, troca de workspace, busca e status de sincronismo; conteúdo orientado à tarefa; barra inferior de até cinco destinos, adaptável à persona. Uma aba `Explorar` dá acesso a todo catálogo; `Jornada` agrega tarefas, cursos, carreira e progresso. Botão flutuante apenas quando oferecer ação primária inequívoca, sem sobreposição de resultado clínico.

**Desktop:** sidebar esquerda com busca/filtros (quando catálogo), barra de ações, conteúdo principal e drawer de contexto. Workspaces podem ter barra lateral com abas, Kanban e agenda. Design tokens oficiais `#1A3E74`, H1 Nunito Sans, texto Inter; contrastes WCAG 2.2 AA. Dropdown sempre apresenta labels legíveis, indicador de ação indisponível e razão; itens destrutivos têm confirmação proporcional ao risco.

### 2.2 Home e área pessoal

Áreas modulares: `Acesso rápido`, `Continue de onde parou`, `Meus plantões`, `Agenda`, `Favoritos`, `Ler depois`, `Coleções`, `Progresso`, `Notificações`, `Sincronização`. Usuário escolhe widgets, ordem, tamanho e densidade. Há `Adicionar widget`, `Remover`, `Configurar`, `Mover para cima/baixo`, `Restaurar padrão`, `Desfazer` e `Salvar painel`. A personalização nunca altera o algoritmo clínico.

### 2.3 Workspace

**Tipos:** pessoal; estudos; carreira; pesquisa; instituição/equipe (somente após governança). Todo workspace mostra dono, membros e função, visibilidade, estado de sincronização, compartilhamento e menu `⋯`. O usuário pode criar, renomear, copiar **configuração** e arquivar; não duplicar conteúdo canônico. Se sair do workspace com rascunho não salvo: `Salvar`, `Descartar` (com confirmação) ou `Continuar editando`.

**Acesso institucional:** convidar membros, conceder permissões e publicar escala exigem servidor, trilha de auditoria e regras do Kernel. Ao alternar tenant não vazar dados em caches, widgets ou recentes.

### 2.4 Agenda e plantões — dois domínios

**Agenda pessoal:** dia/semana/mês, turnos, horários, blocos de estudo, entrevistas e eventos; modelos de recorrência e lembretes. Botões `+ Evento`, `+ Plantão`, `Hoje`, `Mês`, `Semana`, `Copiar padrão`, `Importar calendário`, `Exportar iCal`, `Compartilhar agenda`. O compartilhamento não expõe dados privados automaticamente.

**Escala institucional:** rascunho -> restrições (`hard`/`soft`) -> verificação de cobertura, competência, jornada, folgas e regras locais -> proposta -> aprovação -> publicação confirmada. Botões `Novo rascunho`, `Adicionar profissional`, `Configurar restrições`, `Validar`, `Ver conflito`, `Solicitar aprovação`, `Publicar` (apenas autorizado). A escala não pode ser tornada oficial apenas arrastando um card.

**Troca de plantão:** `Solicitar` -> `Pendente` -> `Aceita pelo colega` -> `Aprovada pelo gestor` -> `Publicada`; `Recusada` e `Cancelada` preservam histórico. Nunca rotular `Confirmado` ao criar o pedido.

**Passagem de plantão assistencial:** objeto e processo separados de escala de horário. MVP de **simulação educacional SBAR** sem dados reais. Prontuário/passagem com dados clínicos e identificação de paciente só sob integração institucional homologada; exige classificação regulatória, autorização, controle de acesso, log e políticas de retenção. Não colocar PHI no localStorage/PWA público.

### 2.5 Beira-leito e urgência

**Modo beira-leito:** toolbar estável com `Buscar ferramenta`, `Calculadoras`, `Protocolos`, `Referências`, `Ampliar fonte`, `Alto contraste`, `Sair`. Conteúdo aprovado, unidade explícita, aviso de versão e data; leitura grande, foco visual e nenhum banner comercial. *Não é prontuário, monitorização, prescrição ou dispositivo médico por si só.*

**Modo urgência:** atalhos homologados, poucas decisões, sem onboarding ou upsell, sem transições que atrasem a tarefa, com acesso offline somente a pacotes cuja validação, integridade e vigência foram verificadas. Um aviso de contexto explica limitação; em caso de versão obsoleta ou incompleta, bloquear função insegura e mostrar fonte atualizável. Ferramentas devem passar por avaliação de finalidade de uso e legislação SaMD quando aplicável.

### 2.6 Tempo e alarmes

**Cronômetro:** `Iniciar`, `Pausar`, `Volta`, `Retomar`, `Zerar`, `Copiar`. Implementar aferição do tempo decorrido por relógio monotônico e evitar perda silenciosa por suspensão da página. **Temporizador:** `Iniciar`, `Pausar`, `Reiniciar`, `Silenciar`, `Cancelar` com indicação persistente de que o navegador/aparelho pode suspender execução em background.

**Alarme pessoal/lembrete:** `Novo`, `Repetir`, `Editar`, `Adiar`, `Desativar`, `Excluir`, `Testar`, `Permitir notificações`. Serviços de entrega precisam diferenciar `agendado`, `disparado pelo servidor`, `entregue ao canal`, `exibido no dispositivo` e `confirmado pelo usuário`: não presumir equivalência. A plataforma não deve prometer que um alarme de browser substitui alarmes assistenciais, de medicação, equipamentos ou monitor multiparamétrico. Se quiser avançar a monitorização clínica real, projeto/regulação e arquitetura separados.

### 2.7 Kanban e organização

`Novo quadro`, `Criar cartão`, `Criar coluna`, `Mover para…`, `Mover para cima/baixo`, `Arrastar`, `Filtrar`, `Ordenar`, `Visualizar em agenda`, `Voltar`, `Arquivar`, `Restaurar`, `Desfazer`. O arrasto cria uma proposta de mudança e deve ser acompanhado por alternativa de um toque e teclado. **A mesma `Task`** está em quatro visualizações: Kanban, lista, calendário e timeline. Em dados institucionalmente governados, movimento pode exigir aprovação.

### 2.8 Widgets, wallpaper e configurações

Widgets candidatos: favoritos; recentes; meu próximo plantão; agenda; checklist pessoal; projetos Kanban; objetivos PDI; concursos e prazo; simulado em andamento; leituras; material salvo; calculadora favorita; progresso real; status de sincronização; versões offline. Sem mostrar pacientes, leitos ou indicadores sensíveis em tela de bloqueio ou widgets de plataforma.

Fundos: paleta oficial, claro/escuro, neutro, imagens do catálogo aprovado/licenciado, importação pessoal apenas nas áreas privadas permitidas. **Bloqueio automático de wallpaper** no modo clínico e quando contrastes falham. `Prévia`, `Aplicar`, `Restaurar`, `Remover`. Redução de movimento e alto contraste sobrepõem escolhas estéticas.

### 2.9 Offline e sincronização

- **Classes de conteúdo:** (A) cache público sem dados pessoais; (B) rascunho pessoal permitido e criptografado se suportado; (C) dados institucionais sensíveis **não** entram na PWA pública; (D) conteúdo clínico validado com versão, licença, hash, expiração e política de revogação.
- **Fila de mutações:** `pendente_local -> enviando -> aceito_servidor` ou `erro_recuperável / conflito / recusado`. Mostrar data da última sincronização confirmada. `Online` não significa `Atualizado`.
- **Conflitos:** comparação base/local/remoto por objeto/versionId; não fazer *last-write-wins* para escala institucional, aprovação, conteúdo clínico ou registro governado. Retry com idempotencyKey e limite; não descartar alterações silenciosamente.
- **Compatibilidade:** service worker e cache passam por teste por navegador; `Background Sync` não é universal, portanto deve haver botão `Sincronizar agora` e sincronização com app aberta. A entrega de push/background não deve ser apresentada como garantida.
- **Multiplataforma:** web/PWA primeiro; interfaces futuras (nativo, widget OS, extensão) são projeções do mesmo contrato. `CalendarConnector` adota exportação iCal como primeiro passo, e integração bidirecional só com consentimento e escopos claros.

## 3. Componentes DS e tokens

Reutilizar o que já existe; novos componentes candidatos são apenas variantes ou lacunas a reconciliar. `AppShell`, `ActionBar`, `Card`, `Button`, `Menu`, `Popover`, `Drawer`, `Modal`, `Toast`, `Table`, `Tabs`, `CalendarView`, `KanbanView`, `Progress`, `Badge` e `OfflineBanner` continuam como primitivas. O adendo acrescenta `WorkspaceSwitcher`, `WidgetGallery/WidgetFrame`, `RosterEditor`, `SwapRequestSheet`, `StopwatchWidget`, `EmergencyQuickPanel`, `SyncQueuePanel`, `ConflictResolutionDrawer` e equivalentes, com schema/contrato tipado.

**Movimento:** 0–220 ms para feedback ordinário; nenhum movimento decorativo em modo urgência; respeito a `prefers-reduced-motion`. Indicadores de progresso nunca antecipam sucesso do servidor. Não usar auto-carrossel ou auto-scroll em tarefas clínicas.

## 4. Matriz de autorização, risco e monetização

| Domínio | Perfil típico | Offline | Monetização | Publicação/efeito |
|---|---|---|---|---|
| Favoritos, coleções, layout, PDI | Usuário pessoal | Sim, com fila de sync | Upgrade opcional sem bloqueio de acesso clínico | Persistência pessoal com ACK |
| Agenda, lembretes | Usuário pessoal | Parcial, sem garantia de alarme | Oferta fora do fluxo do cuidado | Exportação/iCal, permissão |
| Escalas e trocas institucionais | Gestor/profissional autorizado | Rascunho apenas | Planos institucionais candidatos | Servidor valida e aprova |
| Handover com dados de paciente | Instituição e profissional habilitado | HOLD | Não aplicável antes de compliance | Sistema clínico autenticado, não app público |
| Calculadoras e modo urgência | Todos conforme licença/capacidade | Apenas pacote validado | Sem anúncios/upsell no resultado | Motor clínico versionado |
| Kanban, workspace, widgets | Usuários permitidos | Parcial | Upgrade por recursos não essenciais | Estado do usuário, sem alterar domínio |
| Alarmes médicos | Instituição/regulação pertinente | HOLD | N/A | Não implementado como PWA pessoal |

## 5. Pesquisa externa e limites

**Pesquisas avaliadas:** Aksu & Dinç 2025 (escala; 12 enfermeiros; satisfação média 8/10), Dematte et al. 2024 (protótipo de passagem de plantão: usabilidade 79), estudo da urgência Brasil 2025 (20 enfermeiros), estudo JMIR 2026 com trabalhadores por turnos (notificações alinhadas ao plantão, problemas de ergonomia), Nursegrid (benchmark funcional comercial, não evidência causal). **Normas e suporte:** WCAG 2.2 2.5.7; COFEN 736/2024 (processo e prontuário); 743/2024 revoga 543/2017 e remete ao Parecer 1/2024; Anvisa RDC 657/2022 sobre SaMD; HL7 FHIR para controle concorrente quando houver interoperabilidade; MDN Background Sync com disponibilidade limitada; OMS 2021–2030 segurança.

Todos os detalhes de metodologia, limitação, URLs estão em `NOVOS_ESTUDOS.csv`. Pesquisas internacionais, amostras pequenas e páginas de marketing **não** são prova de eficácia clínica, e nenhum resultado é automaticamente transferível à plataforma.

## 6. Gatilhos de não conformidade e gates

1. **G0 Reconciliação:** comparar 46 telas candidatas com rotas/branches/DS/Registry já existentes; conciliar o que for igual; não duplicar nem sobrescrever homologados.
2. **G1 Contratos:** 100% dos botões/actionKeys e estados com destino, política de acesso/offline, feedback e teste; alternativa por toque ao drag.
3. **G2 Pesquisa e protótipo:** testes de tarefas com profissionais e estudantes; avaliar tempo, sucesso, erros críticos, carga cognitiva e SUS/UMUX-Lite **com limites claros**.
4. **G3 Segurança:** risco SaMD e avaliação institucional para beira-leito/urgência, escalas, alarmes, handover e dados sensíveis; revisão normativa vigente.
5. **G4 Validação técnica:** iOS/Android/Web, rede suspensa, PWA background, telas 320–1920px, teclado, leitor de tela, relógio monotônico e reentrada.
6. **G5 Kernel:** WO validada, IDs definitivos, gates, evidências, SHA-256 e assinatura; só então implementar e promover conforme política.

**Critério de conclusão documental:** tela × persona × objetivo × ação/controle × input/output × estados × permissões × risco × offline × sync × teste × evidência alinhados; ausência de duplicidade canônica; resultados de estudos usados apenas dentro de sua validade.
