/**
 * CKO Ecosystem Candidate v1.0.0 — model-driven local workspace.
 * Source of truth: configs/ecossistema/{catalogo,formularios,ofertas}.json
 * ATTENTION: localStorage is convenience/persistence only, never authentication
 * or entitlements. No network submission, checkout, public posting or patient data.
 * All user text is rendered via textContent, never as HTML.
 */
(() => {
  'use strict';
  const root = document.body.dataset.root || '../';
  const startArea = document.body.dataset.area || '';
  const $ = (s, p = document) => p.querySelector(s);
  const $$ = (s, p = document) => [...p.querySelectorAll(s)];
  const ns = 'cko.ecossistema.v1.';
  const state = { area: startArea || '', active: '', search: '', status: '', data: null, sidebar: true, toast: '', draft: null };
  const APP = $('#cko-eco-app');
  const rootUrl = `${root}configs/ecossistema/`;
  const keyOf = store => ns + store;
  const el = (tag, attrs = {}, ...children) => {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k === 'className') n.className = v;
      else if (k === 'text') n.textContent = String(v);
      else if (k === 'htmlFor') n.htmlFor = v;
      else if (k === 'value') n.value = v;
      else if (k === 'checked') n.checked = Boolean(v);
      else if (k === 'onClick') n.addEventListener('click', v);
      else if (k === 'onChange') n.addEventListener('change', v);
      else if (k === 'onInput') n.addEventListener('input', v);
      else if (k === 'hidden') n.hidden = !!v;
      else n.setAttribute(k, String(v));
    }
    for (const c of children.flat(Infinity)) {
      if (c == null || c === false) continue;
      n.append(c instanceof Node ? c : document.createTextNode(String(c)));
    }
    return n;
  };
  const button = (label, action, cls = 'cko-button') => el('button', {type:'button',className:cls,onClick:action,text:label});
  const note = (s, type='') => el('p', {className:'cko-note '+type,text:s});
  const heading = (s, lvl=2) => el(`h${lvl}`,{text:s});
  const parse = (raw,fallback) => { try {return raw ? JSON.parse(raw) : fallback;} catch (_) {return fallback;} };
  const read = (store) => {try{const data = parse(localStorage.getItem(keyOf(store)),[]);return Array.isArray(data)?data:[];}catch(_){return [];}};
  const save = (store, rows) => {
    try {localStorage.setItem(keyOf(store),JSON.stringify(rows));document.dispatchEvent(new CustomEvent('cko:store-changed',{detail:{store}}));return true;}
    catch (_) {alert('Não foi possível salvar no dispositivo. Exporte os dados e verifique o espaço disponível.');return false;}
  };
  const uuid = () => (globalThis.crypto && crypto.randomUUID) ? crypto.randomUUID() : 'local-'+Date.now()+'-'+Math.random().toString(36).slice(2);
  const fmtDate = dt => dt ? new Date(dt).toLocaleDateString('pt-BR') : '—';
  const isoDay = () => new Date().toISOString().slice(0,10);
  const tool = key => state.data.models[key];
  const cap = key => state.data.catalog.capabilities.find(c=>c.key===key);
  const srv = key => state.data.catalog.services.find(s=>s.key===key);
  const titles = new Map();
  const escapeCSV = v => {
    let value=String(v??'');
    if (/^[=+\-@\t\r]/.test(value)) value="'"+value;
    return '"'+value.replace(/"/g,'""')+'"';
  };
  const download = (filename,content,type='application/json;charset=utf-8') => {
    const a=document.createElement('a'); const u=URL.createObjectURL(new Blob([content],{type}));
    a.href=u;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),2000);
  };
  const notify = str => {state.toast=str;const s=$('#cko-status');if(s)s.textContent=str;};
  const setHash = (area,key='')=> {location.hash=area+(key?'/'+key:'');};
  const titleFor = key => {const c=cap(key);return c?c.title:key;};
  const safeHref = url => {
    try {const u=new URL(url,location.href);return ['https:','http:'].includes(u.protocol)?u.href:null;}
    catch (_) {return null;}
  };
  function decorateHeader() {
    $('.cko-eco-search').addEventListener('input', e=>{state.search=e.target.value.trim().toLocaleLowerCase('pt-BR');render();});
    $('.cko-eco-search').addEventListener('keydown',e=>{if(e.key==='Escape'){e.target.value='';state.search='';render();}});
    $('.cko-eco-menu').addEventListener('click',()=>{document.body.classList.toggle('cko-nav-open');});
    $('.cko-eco-overlay').addEventListener('click',()=>document.body.classList.remove('cko-nav-open'));
    document.addEventListener('keydown',e=>{
      if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('.cko-eco-search').focus();}
      if(e.key==='Escape')document.body.classList.remove('cko-nav-open');
    });
    window.addEventListener('hashchange',onRoute);
    $('#cko-export').addEventListener('click',exportWorkspace);
    $('#cko-import').addEventListener('change',importWorkspace);
  }
  function onRoute() {
    const path=decodeURIComponent(location.hash.slice(1));
    const [area,...keyParts]=path.split('/'); const key=keyParts.join('/');
    state.area=state.data.catalog.services.some(s=>s.key===area)?area:startArea;
    state.active=key&&cap(key)&&cap(key).area===state.area?key:'';
    document.body.classList.remove('cko-nav-open');render();
  }
  function renderNav() {
    const nav=$('#cko-navigation');nav.replaceChildren();
    nav.append(el('h2',{className:'cko-nav-label',text:'Explorar'}));
    nav.append(el('a',{href:root+'ecossistema/',className:'cko-nav-item'+(!state.area?' is-active':''),text:'Visão geral'}));
    state.data.catalog.services.filter(s=>s.visibility!=='hidden').forEach(s=> {
      const anchor=el('a',{href:root+s.path,className:'cko-nav-item'+(state.area===s.key?' is-active':''),text:s.name});
      nav.append(anchor);
      if(s.key===state.area){
        const sub=el('div',{className:'cko-nav-sub'});
        state.data.catalog.capabilities.filter(c=>c.area===s.key).forEach(c=>{
          sub.append(el('a',{href:'#'+s.key+'/'+c.key,className:state.active===c.key?'is-active':'',text:c.title}));
        }); nav.append(sub);
      }
    });
    nav.append(el('div',{className:'cko-nav-footer'},note('Navegação pública · trabalho privado no dispositivo. Nenhum plano contratado é inferido.')));
  }
  function render() {
    if(!state.data)return;
    renderNav();const s=$('#cko-content');s.replaceChildren();
    if(state.active){renderTool(s,cap(state.active));}
    else if(state.area){renderArea(s,srv(state.area));}
    else renderOverview(s);
    $('#cko-status').textContent=state.toast;
    const total=state.data.catalog.capabilities.length;
    $('.cko-eco-count').textContent=`${total} capacidades catalogadas · ${state.data.catalog.services.length} serviços · motores clínicos existentes preservados`;
  }
  function crumb(container,...items){container.append(el('p',{className:'cko-crumb',text:items.join(' / ')}));}
  function hero(container,eyebrow,title,description){
    container.append(el('section',{className:'cko-hero'},el('span',{className:'cko-eyebrow',text:eyebrow}),heading(title,1),el('p',{text:description})));
  }
  function statusBadge(kind){return el('span',{className:'cko-chip cko-chip--'+kind,text:kind==='local'?'Funcional neste dispositivo':kind==='existing'?'Página pública existente':'Integração pendente'});}
  function card(c){
    const isPlanned=c.implementation==='planned';
    const cardEl=el('article',{className:'cko-card'});
    cardEl.append(el('div',{className:'cko-card-top'},statusBadge(c.implementation)),heading(c.title,3),el('p',{text:c.description}));
    if(c.implementation==='existing'){
      cardEl.append(el('a',{className:'cko-button cko-button--outline',href:root+c.existing_route,text:'Abrir recurso existente'}));
    }else cardEl.append(el('a',{className:'cko-button '+(isPlanned?'cko-button--outline':''),href:'#'+c.area+'/'+c.key,text:isPlanned?'Ver dependências':'Abrir ferramenta'}));
    return cardEl;
  }
  function matching(c){return !state.search||[c.title,c.description,c.area,c.key].some(v=>String(v||'').toLocaleLowerCase('pt-BR').includes(state.search));}
  function renderOverview(container){
    hero(container,'Portal integrado de enfermagem','Ferramentas, conhecimento e desenvolvimento em um só lugar','Uma fonte canônica para as experiências: sem duplicar conteúdo clínico, trilhas, motores ou design system.');
    const counts={};for(const cap of state.data.catalog.capabilities)counts[cap.implementation]=(counts[cap.implementation]||0)+1;
    container.append(el('div',{className:'cko-stat-grid'},
      el('div',{className:'cko-stat'},el('strong',{text:counts.local||0}),el('span',{text:'fluxos locais operacionais'})),
      el('div',{className:'cko-stat'},el('strong',{text:counts.existing||0}),el('span',{text:'projeções já existentes'})),
      el('div',{className:'cko-stat'},el('strong',{text:counts.planned||0}),el('span',{text:'pendências identificadas'}))));
    container.append(heading('Ecossistemas disponíveis'));
    const grid=el('div',{className:'cko-grid'});
    state.data.catalog.services.filter(s=>s.visibility!=='hidden'&&(!state.search||s.name.toLowerCase().includes(state.search)||state.data.catalog.capabilities.some(c=>c.area===s.key&&matching(c)))).forEach(s=>{
      const c=el('article',{className:'cko-card cko-service'});
      c.append(el('span',{className:'cko-eyebrow',text:(s.capability_keys||[]).length+' capacidades'}),heading(s.name,3),el('p',{text:s.summary}),el('a',{href:root+s.path,className:'cko-button',text:'Explorar serviço'}));grid.append(c);
    }); container.append(grid);
    container.append(el('div',{className:'cko-box'},heading('Ofertas e trajetórias de plano'),note('Os preços e contratos ainda não foram publicados. Comparações são simulações informativas e não concedem acesso.')));
    renderOffers(container);
    container.append(note('O catálogo preserva os motores existentes. Publicações comunitárias, cobranças, direitos pagos e dados compartilhados exigem backend e validação do Kernel.','cko-note--warn'));
  }
  function renderArea(container,service){
    crumb(container,'Ecossistemas',service.name);
    hero(container,'Experiência reutilizável',service.name,service.summary);
    const box=el('div',{className:'cko-toolbar'});
    const locals=service.capability_keys.filter(k=>cap(k).implementation==='local').length;
    box.append(note(`${service.capability_keys.length} capacidades · ${locals} fluxos locais operacionais.`));
    const allFilter=el('select',{className:'cko-select','aria-label':'Filtrar por situação'});
    [['','Todos os estados'],['local','Operacionais'],['existing','Existentes'],['planned','Pendentes']].forEach(([v,l])=>allFilter.append(el('option',{value:v,text:l})));
    allFilter.value=state.status;allFilter.addEventListener('change',()=>{state.status=allFilter.value;render();});box.append(allFilter);
    container.append(box);
    const grid=el('div',{className:'cko-grid'});let shown=0;
    service.capability_keys.map(cap).filter(c=>matching(c)&&(!state.status||c.implementation===state.status)).forEach(c=>{grid.append(card(c));shown++;});
    if(!shown)grid.append(note('Nenhuma ferramenta corresponde aos filtros atuais.'));
    container.append(grid);
    container.append(el('div',{className:'cko-offer-strip'},heading('Outras opções para sua trajetória',3),note('Compare escopos e addons previstos, sem cobrança ou bloqueio das ferramentas clínicas públicas.'),button('Comparar opções',()=>{location.href=root+'ecossistema/#ofertas';renderOffersModal();},'cko-button cko-button--outline')));
  }
  function renderTool(container,c){
    const service=srv(c.area);crumb(container,'Ecossistemas',service.name,c.title);
    container.append(el('a',{href:'#'+c.area,className:'cko-back',text:'← Voltar ao catálogo'}));
    hero(container,`${service.name} · ${c.key}`,c.title,c.description);
    container.append(statusBadge(c.implementation));
    if(c.implementation==='existing'){
      container.append(note('Esta capacidade reutiliza uma rota pública da plataforma; nenhum motor novo será criado.'));
      container.append(el('a',{href:root+c.existing_route,className:'cko-button',text:'Abrir página pública'}));return;
    }
    if(c.implementation==='planned'){
      container.append(el('section',{className:'cko-box'},heading('Dependência documentada',2),note('Este recurso ainda não tem implementação completa validada. Não há simulação enganosa de postagem, mentoria, cobrança, acesso pago, decisão clínica ou sincronização.'),note('A integração exige fonte autorizada, serviço de servidor e/ou homologação funcional e normativa.', 'cko-note--warn')));
      renderOffers(container);return;
    }
    const definition=tool(c.key);if(!definition){container.append(note('Contrato de ferramenta ausente — bloqueado.','cko-note--warn'));return;}
    container.append(note('Os dados desta ferramenta ficam apenas neste navegador. Exporte seu trabalho para evitar perdas. Não registre dados identificáveis de pacientes.'));
    const special=definition.mode;
    if(special==='cv')renderCV(container,c.key);
    else if(special==='quiz')renderQuiz(container);
    else if(special==='flashcards')renderFlashcards(container,definition);
    else if(special==='prisma')renderPrisma(container);
    else if(special==='search')renderStrategy(container);
    else renderEditor(container,definition,c.key);
  }
  function fieldControl(field,value=''){
    let ctrl;
    if(field.type==='select'){
      ctrl=el('select',{name:field.key,required:field.required?'true':null,className:'cko-field-control'});
      ctrl.append(el('option',{value:'',text:'Selecione'}));(field.options||[]).forEach(v=>ctrl.append(el('option',{value:v,text:v})));
      ctrl.value=value||'';
    }else if(field.type==='textarea'){
      ctrl=el('textarea',{name:field.key,rows:'3',maxlength:field.maxLength||10000,className:'cko-field-control'});ctrl.value=value||'';
    }else ctrl=el('input',{name:field.key,type:field.type||'text',value:String(value??''),maxlength:field.type==='number'?null:(field.maxLength||250),className:'cko-field-control'});
    return el('label',{className:'cko-field'},el('span',{text:field.label}),ctrl);
  }
  function formPanel(fields,starting,onSubmit,onCancel){
    const form=el('form',{className:'cko-form'});
    fields.forEach(field=>form.append(fieldControl(field,starting?.[field.key])));
    form.append(el('div',{className:'cko-actions'},el('button',{type:'submit',className:'cko-button',text:'Salvar registro'}),button('Cancelar',onCancel,'cko-button cko-button--outline')));
    form.addEventListener('submit',event=>{
      event.preventDefault();if(!form.reportValidity())return;
      const d={};for(const f of fields){const x=$(`[name="${f.key}"]`,form);const v=x.value.trim();if(v.length>(f.maxLength||10000)){alert('Campo maior que o máximo permitido.');return;}
        if(f.type==='number'&&v!==''&&!Number.isFinite(Number(v))){alert('Número inválido.');return;}
        if(f.type==='url'&&v&&!safeHref(v)){alert('Use URL http ou https.');return;}
        d[f.key]=v;
      }
      onSubmit(d);
    });return form;
  }
  function renderEditor(container,def,key){
    const records=read(def.store),isProfile=def.mode==='profile';
    let editing=null,showing=isProfile||!records.length;
    const live=el('div',{className:'cko-panel'});container.append(live);
    function update(){
      live.replaceChildren();
      const hdr=el('div',{className:'cko-panel-head'},heading(isProfile?'Perfil canônico':'Meus registros',2),
        button(isProfile?'Editar perfil':'+ Novo registro',()=>{editing=null;showing=true;update();}));
      live.append(hdr);
      if(def.info)live.append(note(def.info));
      if(showing){live.append(formPanel(def.fields,isProfile?records[0]:editing?.row,values=>{
        const items=read(def.store);if(isProfile){save(def.store,[{...values,_id:'single',updated_at:new Date().toISOString()}]);}
        else if(editing){const i=items.findIndex(x=>x._id===editing.id);if(i>=0)items[i]={...items[i],...values,updated_at:new Date().toISOString()};save(def.store,items);}
        else {items.unshift({...values,_id:uuid(),created_at:new Date().toISOString()});save(def.store,items);}
        editing=null;showing=false;notify('Registro salvo neste navegador.');update();
      },()=>{editing=null;showing=false;update();}));}
      const current=read(def.store);
      if(!current.length&&!showing)live.append(note('Nenhum registro salvo.'));
      if(def.mode==='skillgap'&&current.length){
        const sum=current.reduce((a,r)=>a+Math.max(0,Number(r.meta||0)-Number(r.atual||0)),0);
        live.append(el('div',{className:'cko-metric',text:`Lacuna agregada: ${sum} pontos (níveis informados). Priorize as maiores diferenças.`}));
      }
      if(def.mode==='pico'&&current.length){
        const p=current[0];live.append(el('div',{className:'cko-result'},heading('Questão estruturada',3),note(`Em ${p.populacao||'[população]'}, ${p.intervencao||'[intervenção]'}, comparada a ${p.comparacao||'[comparação]'}, como se relaciona com ${p.desfecho||'[desfecho]'}?`)));
      }
      if(def.mode==='letter'&&current.length){
        const profile=read('profile')[0]||{};const l=current[0];
        const text=`À ${l.destinatario||'[instituição]'},\n\nTenho interesse na oportunidade de ${l.cargo||'[cargo]'}. ${l.motivo||''}\n\n${l.contribuicao||profile.experiencia||''}\n\nAtenciosamente,\n${profile.nome||'[seu nome]'}`;
        live.append(el('div',{className:'cko-result'},heading('Carta composta a partir dos dados canônicos',3),el('pre',{className:'cko-pre',text}),button('Baixar carta .txt',()=>download('carta-apresentacao.txt',text,'text/plain;charset=utf-8'))));
      }
      if(def.mode==='progress'&&current.length){
        const value=current.map(x=>Math.max(0,Math.min(100,Number(x.percentual)||0)));const avg=value.reduce((a,b)=>a+b,0)/value.length;
        live.append(el('div',{className:'cko-metric',text:`Progresso médio declarado: ${avg.toFixed(1)}% (${current.length} trilhas)`}));
      }
      if(current.length){
        const list=el('div',{className:'cko-record-list'});
        current.forEach((r,i)=>{
          const title=String(r[def.fields[0]?.key]||`Registro ${i+1}`);
          const box=el('article',{className:'cko-record'},el('div',{},heading(title,3),note(def.fields.slice(1,3).map(f=>f.label+': '+(r[f.key]||'—')).join(' · '))));
          const action=el('div',{className:'cko-actions'},button('Editar',()=>{editing={id:r._id,row:r};showing=true;update();},'cko-button cko-button--outline'));
          if(!isProfile)action.append(button('Excluir',()=>{if(confirm('Excluir este registro local?')){save(def.store,read(def.store).filter(x=>x._id!==r._id));update();}},'cko-button cko-button--danger'));
          box.append(action);list.append(box);
        });live.append(list);
      }
      const toolbar=el('div',{className:'cko-actions'});
      toolbar.append(button('Exportar JSON',()=>download(def.store+'.json',JSON.stringify(read(def.store),null,2)),'cko-button cko-button--outline'));
      toolbar.append(button('Exportar CSV',()=>{
        const all=read(def.store);const heads=def.fields.map(f=>f.key);
        const csv=[heads.map(escapeCSV).join(','),...all.map(r=>heads.map(h=>escapeCSV(r[h])).join(','))].join('\r\n');
        download(def.store+'.csv','\uFEFF'+csv,'text/csv;charset=utf-8');
      },'cko-button cko-button--outline'));
      live.append(toolbar);
    }update();
  }
  function renderCV(container,key){
    const p=read('profile')[0]||{};const certs=read('learning_credentials');const portfolio=read('career_portfolio');const academic=key==='carreiras.cv-academico';const productions=read('research_outputs');
    const lines=[p.nome||'[Nome profissional]',p.titulo||'',p.cidade||'',p.contato||'', '', 'PERFIL',p.resumo||'', '', 'FORMAÇÃO',p.formacao||'', '', 'EXPERIÊNCIA',p.experiencia||'', '', 'COMPETÊNCIAS',p.habilidades||'', '', 'IDIOMAS',p.idiomas||''];
    if(certs.length)lines.push('','CERTIFICAÇÕES',...certs.map(c=>`${c.titulo} — ${c.emissor} (${c.emissao||'data não informada'})`));
    if(portfolio.length)lines.push('','PROJETOS E PORTFÓLIO',...portfolio.map(c=>`${c.titulo}: ${c.descricao||''} ${c.url||''}`));
    if(academic&&productions.length)lines.push('','PRODUÇÃO ACADÊMICA',...productions.map(c=>`${c.titulo} — ${c.tipo} (${c.ano||'ano não informado'})`));
    const text=lines.join('\n').trim();
    container.append(el('div',{className:'cko-actions'},el('a',{className:'cko-button',href:'#carreiras/carreiras.passaporte',text:'Preencher passaporte'}),
      button('Baixar currículo .txt',()=>download(academic?'curriculo-academico.txt':'curriculo-profissional.txt',text,'text/plain;charset=utf-8'),'cko-button cko-button--outline'),
      button('Imprimir / salvar PDF',()=>window.print(),'cko-button cko-button--outline')));
    container.append(el('section',{className:'cko-cv-print cko-result'},heading('Prévia de currículo composta',2),el('pre',{className:'cko-pre',text})));
    container.append(note('O currículo usa o mesmo passaporte, as certificações, o portfólio e, quando acadêmico, a produção científica. Não cria cópias divergentes de identidade.'));
  }
  function renderFlashcards(container,def){
    renderEditor(container,def,'educacao.flashcards');
    const panel=el('section',{className:'cko-box'});container.append(panel);
    const due=()=>read('flashcards').filter(r=>!r.next_due||r.next_due<=isoDay());
    function refresh(){panel.replaceChildren(heading('Sessão de revisão espaçada',2));const pending=due();
      panel.append(note(`${pending.length} cartão(ões) disponíveis hoje.`));if(!pending.length){panel.append(note('Revisão em dia. Adicione um cartão ou retorne na próxima data.'));return;}
      const r=pending[0];panel.append(heading(r.frente||'Pergunta',3));
      const ans=el('div',{className:'cko-answer',hidden:true},note(r.verso||'Sem verso.'));
      panel.append(ans,button('Mostrar resposta',()=>{ans.hidden=false;}));
      const actions=el('div',{className:'cko-actions'});
      [['Errei',0],['Difícil',3],['Lembrei',5]].forEach(([label,quality])=>actions.append(button(label,()=>{
        const items=read('flashcards');const x=items.find(i=>i._id===r._id);if(!x)return;
        const reps=Number(x.repetitions||0),interval=Number(x.interval||0),ease=Number(x.ease||2.5);
        x.repetitions=quality<3?0:reps+1;
        x.interval=quality<3?1:(reps===0?1:reps===1?6:Math.max(1,Math.round(interval*ease)));
        x.ease=Math.max(1.3,ease+(0.1-(5-quality)*(0.08+(5-quality)*0.02)));
        const next=new Date();next.setDate(next.getDate()+x.interval);x.next_due=next.toISOString().slice(0,10);
        save('flashcards',items);notify('Revisão registrada.');refresh();
      },'cko-button cko-button--outline')));
      panel.append(actions);
    }refresh();
    document.addEventListener('cko:store-changed',function onStorage(e){if(e.detail.store!=='flashcards')return;if(!panel.isConnected){document.removeEventListener('cko:store-changed',onStorage);return;}refresh();});
  }
  function renderQuiz(container){
    const store='question_bank';let questions=read(store);let selected=[],answers={};
    const panel=el('section',{className:'cko-panel'});container.append(panel);
    const intro=el('div',{},heading('Banco único de questões',2),note('Alimenta simultaneamente simulados, quizzes, concursos e o caderno de erros. Sem conteúdo fictício nem prova copiada.'));
    const formFields=[{key:'enunciado',label:'Enunciado',type:'textarea',maxLength:5000},{key:'alternativas',label:'Alternativas (uma por linha, mínimo 2)',type:'textarea',maxLength:5000},{key:'correta',label:'Número da alternativa correta (1, 2, 3...)',type:'number'},{key:'tema',label:'Disciplina ou tema',type:'text'},{key:'fonte',label:'Fonte, permissão ou referência',type:'text'},{key:'explicacao',label:'Explicação / justificativa',type:'textarea',maxLength:5000}];
    let creating=false;
    function refresh(){questions=read(store);panel.replaceChildren(intro.cloneNode(true));
      panel.append(el('div',{className:'cko-actions'},button('+ Adicionar questão',()=>{creating=!creating;refresh();}),button('Exportar banco JSON',()=>download('banco-questoes.json',JSON.stringify(read(store),null,2)),'cko-button cko-button--outline')));
      if(creating)panel.append(formPanel(formFields,null,data=>{
        const alternatives=data.alternativas.split('\n').map(v=>v.trim()).filter(Boolean);const answer=Number(data.correta);
        if(alternatives.length<2||!Number.isInteger(answer)||answer<1||answer>alternatives.length){alert('Informe ao menos duas alternativas e a resposta correta entre 1 e '+alternatives.length+'.');return;}
        const rows=read(store);rows.push({...data,_id:uuid(),tentativas:0,erros:0});save(store,rows);creating=false;refresh();
      },()=>{creating=false;refresh();}));
      panel.append(note(`${questions.length} questões cadastradas. O resultado é privado e baseado somente nesse banco.`));
      if(!questions.length)return;
      const acts=el('div',{className:'cko-actions'},button('Iniciar simulado',()=>startQuiz()));panel.append(acts);
      const list=el('div',{className:'cko-record-list'});
      for(const q of questions){list.append(el('div',{className:'cko-record'},heading(q.enunciado,3),note(`Tema: ${q.tema||'—'} · Tentativas: ${q.tentativas||0} · Erros: ${q.erros||0}`),button('Excluir',()=>{if(confirm('Excluir questão local?')){save(store,read(store).filter(x=>x._id!==q._id));refresh();}},'cko-button cko-button--danger')));}
      panel.append(list);
    }
    function startQuiz(){selected=read(store).slice(0,25);answers={};panel.replaceChildren(heading('Simulado local',2));
      selected.forEach((q,i)=>{
        const alternatives=q.alternativas.split('\n').map(x=>x.trim()).filter(Boolean),group=el('fieldset',{className:'cko-question'},el('legend',{text:`${i+1}. ${q.enunciado}`}));
        alternatives.forEach((a,j)=>{
          const input=el('input',{type:'radio',name:'q'+i,value:String(j+1)});input.addEventListener('change',()=>answers[q._id]=j+1);
          group.append(el('label',{className:'cko-option'},input,el('span',{text:a})));
        });panel.append(group);
      });
      panel.append(button('Corrigir respostas',()=>{
        let correct=0;const reviews=[];const rows=read(store);
        for(const q of selected){const answer=Number(answers[q._id]||0),isCorrect=answer===Number(q.correta);if(isCorrect)correct++;
          const x=rows.find(r=>r._id===q._id);if(x){x.tentativas=Number(x.tentativas||0)+1;x.erros=Number(x.erros||0)+(isCorrect?0:1);}
          reviews.push(`${isCorrect?'Acerto':'Erro'}: ${q.enunciado} | resposta correta: ${q.correta} | ${q.explicacao||''}`);
        }
        save(store,rows);panel.replaceChildren(heading('Resultado da sessão',2),el('div',{className:'cko-metric',text:`${correct}/${selected.length} acertos (${Math.round(100*correct/selected.length)}%)`}),el('pre',{className:'cko-pre',text:reviews.join('\n\n')}),button('Nova sessão',()=>refresh()));
      }));
    }refresh();
  }
  function renderPrisma(container){
    const rows=read('research_screening');const stats={};for(const r of rows){const k=r.decisao||'Sem classificação';stats[k]=(stats[k]||0)+1;}
    container.append(el('div',{className:'cko-stat-grid'},el('div',{className:'cko-stat'},el('strong',{text:rows.length}),el('span',{text:'Registros locais'})),el('div',{className:'cko-stat'},el('strong',{text:stats['Incluído']||0}),el('span',{text:'Incluídos'})),el('div',{className:'cko-stat'},el('strong',{text:stats['Duplicado']||0}),el('span',{text:'Duplicados marcados'}))));
    container.append(heading('Contagem por situação',2));
    const ul=el('ul',{className:'cko-record-list'});Object.entries(stats).forEach(([k,n])=>ul.append(el('li',{text:`${k}: ${n}`})));container.append(ul);
    container.append(note('Contagens simples dos registros. Um fluxograma PRISMA formal exige informação adicional sobre exclusão, múltiplas fontes e elegibilidade.'));
    container.append(el('a',{href:'#pesquisa/pesquisa.triagem',className:'cko-button',text:'Registrar decisões de triagem'}));
  }
  function renderStrategy(container){
    const p=read('research_pico')[0];if(!p){container.append(note('Comece registrando uma questão PICO.'));container.append(el('a',{href:'#pesquisa/pesquisa.pico',className:'cko-button',text:'Abrir PICO'}));return;}
    const parts=[p.populacao,p.intervencao,p.comparacao,p.desfecho].filter(Boolean);
    const query=parts.map(term=>'('+term+')').join(' AND ');
    container.append(el('div',{className:'cko-result'},heading('Estratégia inicial para revisão',2),el('pre',{className:'cko-pre',text:query}),note('Consulta inicial produzida a partir dos seus termos. Adapte vocabulário controlado, sinônimos e operadores à base escolhida.'),button('Copiar estratégia',()=>navigator.clipboard?.writeText(query).then(()=>notify('Consulta copiada.')).catch(()=>notify('Cópia indisponível.'))),el('a',{href:'https://scholar.google.com/scholar?q='+encodeURIComponent(query),target:'_blank',rel:'noopener noreferrer',className:'cko-button cko-button--outline',text:'Pesquisar no Google Scholar'})));
  }
  function renderOffers(container){
    const packages=state.data.offers.packages;const wrap=el('div',{className:'cko-offers'});
    packages.forEach(p=>{
      const card=el('article',{className:'cko-card'},el('span',{className:'cko-eyebrow',text:'Proposta · não comercializada'}),heading(p.name,3),el('p',{text:p.description}),note('Preço ainda não definido'));
      const list=el('ul',{className:'cko-offer-list'});for(const feature of p.features)list.append(el('li',{text:feature}));
      card.append(list,button('Comparar inclusão e retirada',()=>comparePlan(p.key),'cko-button cko-button--outline'));wrap.append(card);
    });container.append(wrap);
    const addons=state.data.offers.addons||[];container.append(note(`${addons.length} complementos comerciais previstos. Nenhuma seleção altera assinatura, contrato ou direito de acesso.`));
  }
  function comparePlan(key){
    const packages=state.data.offers.packages;const target=packages.find(p=>p.key===key);if(!target)return;
    const comparison=el('div',{className:'cko-modal-backdrop'});const content=el('section',{className:'cko-modal',role:'dialog','aria-modal':'true','aria-label':'Simulação de planos'});
    const select=el('select',{className:'cko-select','aria-label':'Plano de origem'});
    packages.forEach(p=>select.append(el('option',{value:p.key,text:p.name})));select.value=packages[0].key;
    const summary=el('div',{className:'cko-result'});
    function refresh(){const from=packages.find(p=>p.key===select.value),before=new Set(from.services),after=new Set(target.services);
      const gain=[...after].filter(x=>!before.has(x)).map(k=>srv(k)?.name||k),loss=[...before].filter(x=>!after.has(x)).map(k=>srv(k)?.name||k);
      summary.replaceChildren(heading(`${from.name} → ${target.name}`,3),note(`Incluídos: ${gain.join(', ')||'nenhum'}`),note(`Fora do pacote de destino: ${loss.join(', ')||'nenhum'}`),note('Simulação apenas. Acesso atual é desconhecido; nenhum dado será apagado e nenhum plano será contratado.','cko-note--warn'));
    }select.addEventListener('change',refresh);refresh();
    content.append(heading('Comparar trajetórias de assinatura',2),note('Escolha o plano de referência para estimar upsell ou downsell; não há precificação ou cobrança ativa.'),select,summary,button('Fechar',()=>comparison.remove()));
    comparison.addEventListener('click',e=>{if(e.target===comparison)comparison.remove();});comparison.append(content);document.body.append(comparison);$('button',content)?.focus();
  }
  function renderOffersModal(){if(location.hash==='#ofertas'){state.area='';state.active='';render();}}
  function exportWorkspace(){
    const models=Object.values(state.data.models),stores=[...new Set(models.map(m=>m.store))],data={schema_version:'cko-eco-backup-1',created_at:new Date().toISOString(),stores:{}};
    stores.forEach(store=>data.stores[store]=read(store));download('cko-ecossistema-backup.json',JSON.stringify(data,null,2));notify('Backup exportado.');
  }
  async function importWorkspace(event){
    const f=event.target.files?.[0];event.target.value='';if(!f)return;
    if(f.size>5_000_000){alert('O arquivo excede o limite de 5 MB.');return;}
    try{
      const data=JSON.parse(await f.text());if(data.schema_version!=='cko-eco-backup-1'||!data.stores||typeof data.stores!=='object')throw Error('Formato incompatível.');
      const known=new Set(Object.values(state.data.models).map(m=>m.store)),valid=[];
      for(const [store,rows] of Object.entries(data.stores)){
        if(!known.has(store)||!Array.isArray(rows)||rows.length>5000)continue;
        if(rows.some(r=>!r||typeof r!=='object'||Array.isArray(r)))continue;
        valid.push([store,rows]);
      }
      if(!valid.length)throw Error('Backup sem dados reconhecidos.');
      if(!confirm(`Restaurar ${valid.length} coleções locais? Os dados atuais dessas coleções serão substituídos.`))return;
      let count=0;for(const [store,rows] of valid){if(save(store,rows))count++;}
      notify(`${count} coleções restauradas.`);render();
    }catch(err){alert('Importação não realizada: '+err.message);}
  }
  async function start(){
    try{
      const response=await Promise.all(['catalogo.json','formularios.json','ofertas.json'].map(f=>fetch(rootUrl+f).then(r=>{if(!r.ok)throw Error(`Falha ao abrir ${f}`);return r.json();})));
      const [catalog,forms,offers]=response;const models=forms.models;
      if(!Array.isArray(catalog.services)||!Array.isArray(catalog.capabilities)||!models||!Array.isArray(offers.packages))throw Error('Contrato de catálogo inválido.');
      state.data={catalog,models,offers};catalog.capabilities.forEach(c=>titles.set(c.key,c.title));
      decorateHeader();onRoute();
    }catch(err){APP.replaceChildren(el('div',{className:'cko-box'},heading('Não foi possível carregar o catálogo'),note(err.message),note('Abra as páginas por um servidor HTTP (não pelo protocolo file://).')));}
  }
  start();
})();
