-- CKO COMMERCE DRAFT v1.0.0 · 2026-11-15
-- RECONCILIATION_HOLD: DO NOT APPLY without a Kernel-issued Work Order,
-- explicit database target, server auth model, legal review and backup.
-- PostgreSQL model candidate, not a migration applied to production.
-- No role, public endpoint, seed prices, credential or subscription is created.
-- Security invariant: only a trusted server may create subscriptions or entitlements.

CREATE SCHEMA IF NOT EXISTS cko_commerce;
REVOKE ALL ON SCHEMA cko_commerce FROM PUBLIC;

CREATE TABLE IF NOT EXISTS cko_commerce.capability (
  capability_key text PRIMARY KEY,
  registry_version text NOT NULL,
  status text NOT NULL CHECK (status IN ('local','existing','planned')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cko_commerce.service (
  service_key text PRIMARY KEY,
  catalog_visibility text NOT NULL CHECK (catalog_visibility IN ('public','hidden','preview')),
  sales_status text NOT NULL CHECK (sales_status IN ('draft','available','paused','sunset','not_launched')),
  runtime_status text NOT NULL CHECK (runtime_status IN ('public_preview','enabled','paused','retired')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cko_commerce.service_capability (
  service_key text NOT NULL REFERENCES cko_commerce.service(service_key),
  capability_key text NOT NULL REFERENCES cko_commerce.capability(capability_key),
  PRIMARY KEY(service_key,capability_key)
);
CREATE TABLE IF NOT EXISTS cko_commerce.package (
  package_key text PRIMARY KEY,
  state text NOT NULL CHECK (state IN ('draft','available','retired')) DEFAULT 'draft'
);
CREATE TABLE IF NOT EXISTS cko_commerce.package_version (
  package_version_id uuid PRIMARY KEY,
  package_key text NOT NULL REFERENCES cko_commerce.package(package_key),
  version text NOT NULL,
  terms_sha256 char(64) NOT NULL,
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  UNIQUE(package_key,version),
  CHECK(effective_to IS NULL OR effective_to>effective_from)
);
CREATE TABLE IF NOT EXISTS cko_commerce.package_version_service (
  package_version_id uuid NOT NULL REFERENCES cko_commerce.package_version(package_version_id),
  service_key text NOT NULL REFERENCES cko_commerce.service(service_key),
  quota jsonb NOT NULL DEFAULT '{}'::jsonb,
  PRIMARY KEY(package_version_id,service_key)
);
CREATE TABLE IF NOT EXISTS cko_commerce.price_version (
  price_version_id uuid PRIMARY KEY,
  package_version_id uuid NOT NULL REFERENCES cko_commerce.package_version(package_version_id),
  amount_minor bigint NOT NULL CHECK(amount_minor>=0),
  currency char(3) NOT NULL DEFAULT 'BRL',
  cycle text NOT NULL CHECK(cycle IN ('month','year','one_time')),
  tax_policy_version text NOT NULL,
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  UNIQUE(package_version_id,currency,cycle,effective_from)
);
CREATE TABLE IF NOT EXISTS cko_commerce.offer_version (
  offer_version_id uuid PRIMARY KEY,
  target_price_version_id uuid NOT NULL REFERENCES cko_commerce.price_version(price_version_id),
  offer_type text NOT NULL CHECK(offer_type IN ('upsell','downsell','retention','standard')),
  disclosure_version text NOT NULL,
  source_rule_version text NOT NULL,
  published_at timestamptz,
  archived_at timestamptz
);
CREATE TABLE IF NOT EXISTS cko_commerce.subscription (
  subscription_id uuid PRIMARY KEY,
  subject_id uuid NOT NULL, -- bind to the chosen verified authentication authority
  package_version_id uuid NOT NULL REFERENCES cko_commerce.package_version(package_version_id),
  price_version_id uuid NOT NULL REFERENCES cko_commerce.price_version(price_version_id),
  status text NOT NULL CHECK(status IN ('pending','active','past_due','canceled','expired')),
  period_start timestamptz,
  period_end timestamptz,
  cancel_at_period_end boolean NOT NULL DEFAULT false,
  external_provider text,
  external_subscription_id text,
  UNIQUE(external_provider,external_subscription_id),
  CHECK(period_end IS NULL OR period_start IS NULL OR period_end>period_start)
);
CREATE TABLE IF NOT EXISTS cko_commerce.acceptance (
  acceptance_id uuid PRIMARY KEY,
  subscription_id uuid NOT NULL REFERENCES cko_commerce.subscription(subscription_id),
  subject_id uuid NOT NULL,
  terms_sha256 char(64) NOT NULL,
  locale text NOT NULL,
  accepted_at timestamptz NOT NULL,
  acceptance_evidence_ref text NOT NULL
);
CREATE TABLE IF NOT EXISTS cko_commerce.provider_event (
  provider_event_id uuid PRIMARY KEY,
  provider text NOT NULL,
  external_event_id text NOT NULL,
  signature_verified boolean NOT NULL CHECK(signature_verified=true),
  received_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  status text NOT NULL CHECK(status IN ('received','validated','processed','failed')),
  payload_sha256 char(64) NOT NULL,
  UNIQUE(provider,external_event_id)
);
CREATE TABLE IF NOT EXISTS cko_commerce.entitlement (
  entitlement_id uuid PRIMARY KEY,
  subject_id uuid NOT NULL,
  subscription_id uuid REFERENCES cko_commerce.subscription(subscription_id),
  service_key text NOT NULL REFERENCES cko_commerce.service(service_key),
  source_event_id uuid REFERENCES cko_commerce.provider_event(provider_event_id),
  kind text NOT NULL CHECK(kind IN ('subscription','authorized_grant','institutional_license')),
  valid_from timestamptz NOT NULL,
  valid_until timestamptz,
  revoked_at timestamptz,
  CHECK(valid_until IS NULL OR valid_until>valid_from)
);
CREATE INDEX IF NOT EXISTS idx_cko_entitlement_subject
  ON cko_commerce.entitlement(subject_id,service_key,valid_from,valid_until);
CREATE TABLE IF NOT EXISTS cko_commerce.plan_change_request (
  request_id uuid PRIMARY KEY,
  subscription_id uuid NOT NULL REFERENCES cko_commerce.subscription(subscription_id),
  target_package_version_id uuid NOT NULL REFERENCES cko_commerce.package_version(package_version_id),
  offer_version_id uuid REFERENCES cko_commerce.offer_version(offer_version_id),
  kind text NOT NULL CHECK(kind IN ('upsell','downsell','cancel','pause')),
  state text NOT NULL CHECK(state IN ('requested','quoted','confirmed','rejected','applied','failed')),
  consent_evidence_ref text,
  requested_at timestamptz NOT NULL DEFAULT now(),
  effective_at timestamptz
);
CREATE TABLE IF NOT EXISTS cko_commerce.audit_event (
  audit_event_id uuid PRIMARY KEY,
  action text NOT NULL,
  object_type text NOT NULL,
  object_id text NOT NULL,
  subject_id uuid,
  actor_id uuid,
  evidence_ref text,
  payload_sha256 char(64) NOT NULL,
  previous_hash char(64),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- This candidate intentionally has no grants/policies/endpoints. PostgreSQL
-- RLS default-deny is enabled; implement role-specific access only after
-- independent auth+authorization review. Server privilege grants must be
-- reviewed separately; frontend service role and publishable role forbidden.
DO $$
DECLARE tab record;
BEGIN
  FOR tab IN SELECT tablename FROM pg_tables WHERE schemaname='cko_commerce'
  LOOP
    EXECUTE format('ALTER TABLE cko_commerce.%I ENABLE ROW LEVEL SECURITY',tab.tablename);
    EXECUTE format('ALTER TABLE cko_commerce.%I FORCE ROW LEVEL SECURITY',tab.tablename);
    EXECUTE format('REVOKE ALL ON cko_commerce.%I FROM PUBLIC',tab.tablename);
  END LOOP;
END $$;

-- No automatic creation of entitlements from UI/plan selection.
-- Server must verify idempotent and signed payment events, contract version,
-- refund/chargeback states, right of withdrawal and effective plan changes.
-- Pausing sales does not revoke existing valid entitlements.
