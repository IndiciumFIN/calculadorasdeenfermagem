#!/usr/bin/env python3
"""CKO ecosystem browser gate using an in-memory fixture (no HTTP navigation).

This environment blocks all Chromium navigation by policy. The gate still runs
Chromium with the actual generated HTML, CSS and JS, injecting the three JSON
sources via a deterministic fetch stub. It DOES NOT assert deployment readiness.
"""
import json
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]

def gate():
    s=BeautifulSoup((ROOT/'ecossistema/index.html').read_text(encoding='utf-8'),'html.parser')
    for tag in s.select('script[src],link[href]'):tag.decompose()
    html=str(s)
    payload={
        '../configs/ecossistema/catalogo.json':json.loads((ROOT/'configs/ecossistema/catalogo.json').read_text()),
        '../configs/ecossistema/formularios.json':json.loads((ROOT/'configs/ecossistema/formularios.json').read_text()),
        '../configs/ecossistema/ofertas.json':json.loads((ROOT/'configs/ecossistema/ofertas.json').read_text()),
    }
    script=(ROOT/'assets/js/cko-ecosystem.js').read_text(encoding='utf-8')
    styles=(ROOT/'assets/css/ds-canonico.css').read_text(encoding='utf-8')+'\n'+(ROOT/'assets/css/cko-ecosystem.css').read_text(encoding='utf-8')
    results=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        context=browser.new_context(accept_downloads=True,viewport={'width':1440,'height':900})
        page=context.new_page();errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content(html)
        page.add_style_tag(content=styles)
        page.evaluate('''payload => {
          const cache=new Map();
          Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>cache.has(k)?cache.get(k):null,setItem:(k,v)=>cache.set(k,String(v)),removeItem:k=>cache.delete(k)}});
          window.fetch=async path => ({ok:true,json:async()=>structuredClone(payload[path])});
          window.confirm=()=>true;
          window.alert=()=>{};
        }''',payload)
        page.add_script_tag(content=script)
        page.locator('.cko-service').first.wait_for(timeout=6000)
        assert page.locator('.cko-service').count()==8
        results.append('hub and all 8 service views')
        def route(path):
            page.evaluate('hash => {location.hash=hash}', '#'+path)
            page.wait_for_timeout(100)
        route('carreiras/carreiras.passaporte')
        page.locator('input[name="nome"]').fill('Pessoa Teste')
        page.locator('input[name="titulo"]').fill('Enfermagem · exemplo')
        page.locator('textarea[name="resumo"]').fill('Currículo de exemplo.')
        page.get_by_role('button',name='Salvar registro').click()
        assert 'Pessoa Teste' in page.locator('#cko-content').inner_text()
        route('carreiras/carreiras.cv')
        assert 'Pessoa Teste' in page.locator('.cko-cv-print').inner_text()
        results.append('single profile -> CV composition')
        route('carreiras/carreiras.pdi')
        page.locator('input[name="objetivo"]').fill('Especialização')
        page.locator('input[name="competencia"]').fill('Liderança')
        page.get_by_role('button',name='Salvar registro').click()
        assert 'Especialização' in page.locator('#cko-content').inner_text()
        results.append('PDI CRUD')
        route('pesquisa/pesquisa.pico')
        page.locator('input[name="populacao"]').fill('Adultos')
        page.locator('input[name="intervencao"]').fill('Educação')
        page.locator('input[name="desfecho"]').fill('Adesão')
        page.get_by_role('button',name='Salvar registro').click()
        route('pesquisa/pesquisa.estrategias')
        assert '(Adultos) AND (Educação) AND (Adesão)' in page.locator('.cko-result').inner_text()
        results.append('PICO -> literature query')
        route('educacao/educacao.flashcards')
        page.locator('input[name="frente"]').fill('Sigla SBAR')
        page.locator('textarea[name="verso"]').fill('Situação, Background, Avaliação, Recomendação')
        page.get_by_role('button',name='Salvar registro').click()
        route('educacao/educacao.trilhas');route('educacao/educacao.flashcards')
        assert 'Sigla SBAR' in page.locator('#cko-content').inner_text()
        page.get_by_role('button',name='Mostrar resposta').click()
        page.get_by_role('button',name='Lembrei').click()
        assert 'Revisão em dia' in page.locator('#cko-content').inner_text()
        results.append('flashcards spaced repetition')
        route('concursos/concursos.questoes')
        page.get_by_role('button',name='+ Adicionar questão').click()
        page.locator('textarea[name="enunciado"]').fill('Quanto é 2+2?')
        page.locator('textarea[name="alternativas"]').fill('3\n4\n5')
        page.locator('input[name="correta"]').fill('2')
        page.get_by_role('button',name='Salvar registro').click()
        page.get_by_role('button',name='Iniciar simulado').click()
        page.locator('input[name=q0][value="2"]').check()
        page.get_by_role('button',name='Corrigir respostas').click()
        assert '1/1 acertos' in page.locator('#cko-content').inner_text()
        route('educacao/educacao.simulados')
        assert 'Quanto é 2+2?' in page.locator('#cko-content').inner_text()
        results.append('shared contests and learning question bank')
        route('carreiras/carreiras.portfolio')
        page.locator('input[name="titulo"]').fill('<img src=x onerror=alert(1)>')
        page.get_by_role('button',name='Salvar registro').click()
        assert page.locator('.cko-record img').count()==0
        results.append('user content rendered as text, no HTML injection')
        route('')
        page.get_by_role('button',name='Comparar inclusão e retirada').first.click()
        assert page.get_by_role('dialog').count()==1
        assert 'nenhum plano será contratado' in page.get_by_role('dialog').inner_text()
        page.get_by_role('button',name='Fechar').click()
        results.append('upsell / downsell offer comparison, zero entitlement')
        with page.expect_download() as d:page.locator('#cko-export').click()
        assert d.value.suggested_filename=='cko-ecossistema-backup.json'
        results.append('full workspace backup export')
        page.set_viewport_size({'width':390,'height':844})
        assert page.locator('.cko-eco-menu').is_visible()
        assert page.locator('.cko-mobile-tabs').is_visible()
        assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1')
        results.append('mobile navigation, no horizontal overflow')
        # Every registered capability must render a valid, honest state.
        for c in payload['../configs/ecossistema/catalogo.json']['capabilities']:
            route(c['area']+'/'+c['key'])
            content=page.locator('#cko-content').inner_text()
            assert c['title'] in content, f'Missing tool title: {c["key"]}'
            if c['implementation']=='planned':
                assert 'Dependência documentada' in content, c['key']
            elif c['implementation']=='local':
                assert 'Os dados desta ferramenta ficam apenas neste navegador' in content, c['key']
            else:
                assert 'Abrir página pública' in content, c['key']
        results.append('all 68 capabilities render without false readiness')
        assert not errors, 'JavaScript exceptions: '+repr(errors)
        results.append('zero page JS exceptions')
        browser.close()
    return results

if __name__=='__main__':
    for result in gate():print('PASS',result)
