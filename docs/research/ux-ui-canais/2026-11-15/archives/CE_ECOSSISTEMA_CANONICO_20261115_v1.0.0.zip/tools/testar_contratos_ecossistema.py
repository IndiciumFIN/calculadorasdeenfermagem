#!/usr/bin/env python3
"""Declarative catalog/schema/relationships/commerce safety gate.
Runs locally; does not authorize promotion or provision a database.
"""
import json
from pathlib import Path
from jsonschema import Draft202012Validator
from gerar_ecossistema import load,validate

ROOT=Path(__file__).resolve().parents[1]


def gate():
    objects={'catalogo':load('catalogo.json'),'formularios':load('formularios.json'),'ofertas':load('ofertas.json')}
    for name,obj in objects.items():
        schema=json.loads((ROOT/'schema'/f'ecossistema-{name}.schema.json').read_text(encoding='utf-8'))
        Draft202012Validator.check_schema(schema)
        issues=list(Draft202012Validator(schema).iter_errors(obj))
        if issues:raise AssertionError(name+' schema: '+'; '.join(i.message for i in issues[:5]))
    c,f,o=objects['catalogo'],objects['formularios'],objects['ofertas']
    validate(c,f,o)
    capabilities=c['capabilities'];keys={x['key'] for x in capabilities}
    local={x['key'] for x in capabilities if x['implementation']=='local'}
    assert set(f['models'])==local,'local capability and tool model 1:1 required'
    assert len(keys)==68
    assert not o['checkout_enabled']
    assert o['entitlement_authority']=='server_only_not_implemented'
    assert all(p['monthly_price'] is None and p['annual_price'] is None for p in o['packages'])
    assert len({f['models'][k]['store'] for k in local})<len(local),'cross-projection model reuse required'
    assert f['models']['carreiras.passaporte']['store']==f['models']['carreiras.cv']['store']=='profile'
    shared={f['models'][k]['store'] for k in ['educacao.simulados','educacao.quizzes','concursos.questoes','concursos.caderno']}
    assert shared=={'question_bank'}
    assert not any('checkout' in str(x.get('implementation','')) for x in capabilities)
    print('PASS schema/unique keys/relationships and 48 models')
    print('PASS source reuse: passaporte->CV; quiz->contest; research PICO->search')
    print('PASS commerce: checkout disabled, no invented prices or entitlements')
    return True

if __name__=='__main__':gate()
