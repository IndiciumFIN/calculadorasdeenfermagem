#!/usr/bin/env python3
"""Deterministic renderer + referential gate for the CKO ecosystem candidate.

All view pages share one template, one DS and one runtime. No schema/tool reuse
is inferred from labels. All data contracts live under configs/ecossistema.
Usage: python3 tools/gerar_ecossistema.py [--check]
This does not deploy, assign Kernel IDs or authorize commerce.
"""
import html
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CONFIG=ROOT/'configs/ecossistema'
TEMPLATE=ROOT/'templates/ecossistema.html'


def load(name):
    path=CONFIG/name
    data=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data,dict):raise ValueError(f'{name} deve ser objeto JSON')
    return data


def validate(cat,forms,offers):
    errors=[]
    services=cat.get('services',[])
    caps=cat.get('capabilities',[])
    models=forms.get('models',{})
    keys=[s.get('key') for s in services]
    known={c.get('key') for c in caps}
    if len(keys)!=len(set(keys)):errors.append('service.key duplicada')
    if len(known)!=len(caps):errors.append('capability.key duplicada')
    if len(keys)!=len(cat.get('areas',[])):errors.append('áreas e serviços divergentes')
    if not isinstance(models,dict):errors.append('models não é objeto')
    for s in services:
        if s.get('key') not in {a.get('key') for a in cat['areas']}:errors.append(f'area não declarada {s.get("key")}')
        if len(s.get('capability_keys',[]))!=len(set(s.get('capability_keys',[]))):errors.append('duplicidade de ferramenta em '+s['key'])
        for c in s.get('capability_keys',[]):
            if c not in known:errors.append(f'referência inexistente: {s["key"]}.{c}')
    for c in caps:
        area=c.get('area');key=c.get('key');status=c.get('implementation')
        if area not in keys:errors.append(f'area ausente {key}')
        if not any(key in s.get('capability_keys',[]) for s in services):errors.append(f'capability sem serviço {key}')
        if status not in {'local','planned','existing'}:errors.append('status inválido '+str(key))
        if status=='local':
            if c.get('tool')!=key or key not in models:errors.append('implementação local sem contrato '+str(key))
        if status=='existing':
            route=c.get('existing_route')
            if not route or not (ROOT/route).exists():errors.append('rota existente não encontrada '+str(key))
    permitted={'text','textarea','number','date','select','url'}
    for key,model in models.items():
        if key not in known:errors.append('modelo órfão '+key)
        if not model.get('store') or model.get('mode') not in {'collection','profile','cv','skillgap','pico','letter','progress','quiz','flashcards','prisma','search'}:errors.append('modelo inconsistente '+key)
        for f in model.get('fields',[]):
            if f.get('type') not in permitted or not f.get('key'):errors.append('campo não tipado '+key)
            if f.get('type')=='select' and not f.get('options'):errors.append('select sem opções '+key)
    package_keys={p.get('key') for p in offers.get('packages',[])}
    if len(package_keys)!=len(offers.get('packages',[])):errors.append('pacote duplicado')
    for p in offers.get('packages',[]):
        for svc in p.get('services',[]):
            if svc not in keys:errors.append(f'pacote {p["key"]} refere serviço ausente {svc}')
    if offers.get('checkout_enabled') is not False:errors.append('checkout não pode ser ligado sem autoridade de servidor')
    if errors:raise ValueError('\n'.join(errors))
    return True


def targets(cat):
    yield 'ecossistema','', 'Ecossistema de ferramentas','Comunidade, carreiras, cursos, concursos e pesquisa em uma base canônica.'
    for a in cat['areas']:
        if a['key']=='clinica':
            # Existing subscriber page owns this route; never overwrite generated views.
            continue
        yield a['path'].strip('/'),a['key'],a['name'],a['description']


def generate(check=False):
    cat,forms,offers=load('catalogo.json'),load('formularios.json'),load('ofertas.json')
    validate(cat,forms,offers)
    template=TEMPLATE.read_text(encoding='utf-8')
    diff=[]
    for folder,key,title,desc in targets(cat):
        params={'ROOT':'../','AREA':key,'TITLE':title,'DESCRIPTION':desc}
        output=template
        for k,v in params.items():output=output.replace('{{'+k+'}}',html.escape(v,quote=True))
        if '{{' in output:raise ValueError('Token pendente: '+folder)
        path=ROOT/folder/'index.html'
        if check:
            if not path.is_file() or path.read_text(encoding='utf-8')!=output:diff.append(str(path.relative_to(ROOT)))
        else:
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_text(output,encoding='utf-8')
            print('generated',path.relative_to(ROOT))
    if diff:raise ValueError('Divergentes: '+', '.join(diff))
    print('CKO ecosystem:',len(cat['capabilities']),'capabilities,',len(forms['models']),'tools,',len(cat['services']),'areas', 'CHECK PASS' if check else 'GENERATED')


if __name__=='__main__':
    try:generate(check='--check' in sys.argv)
    except (ValueError,KeyError) as e:print('FAIL',e,file=sys.stderr);raise SystemExit(1)
