# CKO — Matriz de capacidades e estados de implementação

**Data:** 2026-11-15 · **Status:** CANDIDATE_HOLD. Não confundir operação de um editor/organizador local com uma plataforma profissional completa.

|Área|Local|Existente|HOLD|Total|
|---|---:|---:|---:|---:|
|Comunidade profissional|2|1|8|11|
|Carreiras e desenvolvimento|17|0|1|18|
|Aprendizagem|8|0|2|10|
|Concursos e residências|7|0|1|8|
|Pesquisa científica|8|0|0|8|
|Gestão profissional e institucional|4|0|4|8|
|Marketplace e oportunidades|2|0|2|4|
|Núcleo clínico compartilhado|0|1|0|1|

**Total: 48 fluxos locais, 2 referências existentes, 18 pendências = 68 capacidades; mais 70 ferramentas clínicas não duplicadas.**

|Chave candidata|Capacidade|Situação|Armazenamento ou origem|
|---|---|---|---|
|`comunidade.forum`|Fórum de Enfermagem|Reuso de rota pública|forum-enfermagem.html|
|`comunidade.rascunhos`|Preparar pergunta para a comunidade|Fluxo local operante (escopo restrito)|community_drafts|
|`comunidade.perguntas`|Perguntas e respostas|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`comunidade.grupos`|Grupos e squads|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`comunidade.mentorias`|Mentoria coletiva e individual|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`comunidade.moderacao`|Moderação e denúncias|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`comunidade.reputacao`|Reputação e contribuições|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`comunidade.enquetes`|Enquetes e sugestões|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`comunidade.eventos`|Eventos e encontros|Fluxo local operante (escopo restrito)|community_events|
|`comunidade.comunidade-publica`|Comunidade para pacientes e cuidadores|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`comunidade.jovens`|Jovens e vocação|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`carreiras.cv`|Gerador de currículo de enfermagem|Fluxo local operante (escopo restrito)|profile|
|`carreiras.passaporte`|Passaporte profissional|Fluxo local operante (escopo restrito)|profile|
|`carreiras.lacunas`|Análise de competências (skill gap)|Fluxo local operante (escopo restrito)|career_skills|
|`carreiras.pdi`|Plano de desenvolvimento individual|Fluxo local operante (escopo restrito)|career_goals|
|`carreiras.portfolio`|Portfólio e procedimentos|Fluxo local operante (escopo restrito)|career_portfolio|
|`carreiras.cv-academico`|Currículo acadêmico / Lattes|Fluxo local operante (escopo restrito)|profile|
|`carreiras.entrevistas`|Simulador de entrevistas|Fluxo local operante (escopo restrito)|career_interviews|
|`carreiras.vagas`|Vagas e oportunidades|Fluxo local operante (escopo restrito)|career_opportunities|
|`carreiras.candidaturas`|Acompanhamento de candidaturas|Fluxo local operante (escopo restrito)|career_applications|
|`carreiras.ongs`|Vagas em ONGs e projetos sociais|Fluxo local operante (escopo restrito)|career_opportunities|
|`carreiras.hospitais`|Hospitais de excelência|Fluxo local operante (escopo restrito)|career_opportunities|
|`carreiras.internacional`|Carreira internacional|Fluxo local operante (escopo restrito)|career_opportunities|
|`carreiras.mercado`|Mercado de trabalho e salários|Fluxo local operante (escopo restrito)|salary_notes|
|`carreiras.empreender`|Empreendedorismo em enfermagem|Fluxo local operante (escopo restrito)|career_venture|
|`carreiras.networking`|Networking profissional|Fluxo local operante (escopo restrito)|career_contacts|
|`carreiras.mentoria-ia`|Mentoria assistida por IA|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`carreiras.autoconhecimento`|Autoconhecimento profissional|Fluxo local operante (escopo restrito)|career_reflections|
|`carreiras.carta`|Carta de apresentação|Fluxo local operante (escopo restrito)|career_letters|
|`educacao.trilhas`|Trilhas de aprendizado|Fluxo local operante (escopo restrito)|learning_tracks|
|`educacao.cursos`|Cursos e microcursos|Fluxo local operante (escopo restrito)|learning_courses|
|`educacao.certificacoes`|Certificações profissionais|Fluxo local operante (escopo restrito)|learning_credentials|
|`educacao.simulados`|Simulados de enfermagem|Fluxo local operante (escopo restrito)|question_bank|
|`educacao.quizzes`|Quizzes e avaliações|Fluxo local operante (escopo restrito)|question_bank|
|`educacao.flashcards`|Flashcards e revisão espaçada|Fluxo local operante (escopo restrito)|flashcards|
|`educacao.casos`|Casos clínicos interativos|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`educacao.mapas`|Mapas mentais e materiais|Fluxo local operante (escopo restrito)|learning_concepts|
|`educacao.certificados`|Certificados de conclusão|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`educacao.ingles`|Inglês técnico de enfermagem|Fluxo local operante (escopo restrito)|flashcards|
|`concursos.plano`|Plano reverso de concurso|Fluxo local operante (escopo restrito)|exam_study|
|`concursos.editais`|Painel de editais e inscrições|Fluxo local operante (escopo restrito)|exam_notices|
|`concursos.questoes`|Banco de questões|Fluxo local operante (escopo restrito)|question_bank|
|`concursos.caderno`|Caderno de erros e revisão|Fluxo local operante (escopo restrito)|question_bank|
|`concursos.residencias`|Residências e seleções|Fluxo local operante (escopo restrito)|exam_notices|
|`concursos.comparador`|Comparador de editais|Fluxo local operante (escopo restrito)|exam_notices|
|`concursos.documentos`|Checklist de documentos|Fluxo local operante (escopo restrito)|exam_docs|
|`concursos.ranking`|Desempenho e rankings|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`pesquisa.pico`|Construtor PICO|Fluxo local operante (escopo restrito)|research_pico|
|`pesquisa.referencias`|Organizador de referências|Fluxo local operante (escopo restrito)|research_references|
|`pesquisa.estrategias`|Estratégia de busca bibliográfica|Fluxo local operante (escopo restrito)|research_pico|
|`pesquisa.triagem`|Triagem e elegibilidade|Fluxo local operante (escopo restrito)|research_screening|
|`pesquisa.prisma`|Fluxograma PRISMA|Fluxo local operante (escopo restrito)|research_screening|
|`pesquisa.qualidade`|Avaliação crítica e qualidade|Fluxo local operante (escopo restrito)|research_appraisal|
|`pesquisa.tcc`|Projetos, TCC e protocolos|Fluxo local operante (escopo restrito)|research_projects|
|`pesquisa.producao`|Produção acadêmica e publicações|Fluxo local operante (escopo restrito)|research_outputs|
|`gestao.indicadores`|Indicadores assistenciais|Fluxo local operante (escopo restrito)|mgmt_metrics|
|`gestao.escalas-plantao`|Escalas de plantão|Fluxo local operante (escopo restrito)|work_schedule|
|`gestao.qualidade`|Auditoria e qualidade|Fluxo local operante (escopo restrito)|mgmt_quality|
|`gestao.nr01`|NR-01 e riscos ocupacionais|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`gestao.nr32`|NR-32 e biossegurança|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`gestao.cme`|Central de Material e Esterilização|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`gestao.sae`|SAE, registros e SBAR|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`gestao.documentos`|Geradores de formulários e documentos|Fluxo local operante (escopo restrito)|mgmt_documents|
|`mercado.materiais`|Materiais e modelos|Fluxo local operante (escopo restrito)|market_materials|
|`mercado.parcerias`|Parceiros e instituições|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`mercado.criadores`|Vitrine de criadores|HOLD — não implementada|Depende de backend, fonte homologada ou controle normativo|
|`mercado.bolsas`|Bolsas e auxílios|Fluxo local operante (escopo restrito)|market_scholarships|
|`clinica.calculadoras`|Calculadoras e escalas|Reuso de rota pública|assinante/|

## Gates obrigatórios antes de afirmar “completo”

- Reconciliação com o master registry real no GitHub/Supabase e IDs gerados pelo Kernel; sem essa evidência, os identificadores locais são candidatos.
- Homologação clínica/regulatória e proteção de dados por público, com retenção e consentimento conforme finalidade.
- Login, perfil, autorização por recurso, RLS, segregação administrativa, contratos, cobrança e reconciliação financeira E2E.
- Conteúdo e serviços multiusuário para Comunidade, mentoria, avaliações, editais, vagas e sistemas normativos ocupacionais.
- Teste E2E por URL real, automatizado e com aprovação independente.
