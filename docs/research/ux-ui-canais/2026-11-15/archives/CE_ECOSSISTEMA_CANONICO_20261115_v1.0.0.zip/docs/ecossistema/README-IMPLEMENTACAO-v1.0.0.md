# CKO · Ecossistema integrado de ferramentas — entrega candidata v1.0.0

**Data:** 2026-11-15  
**Status:** `CANDIDATE_HOLD` · revisão local, sem Work Order Kernel, sem merge, sem GitHub, sem Supabase e sem implantação comercial.

## Escopo efetivamente materializado

- **68 capacidades registradas**, distribuídas em 8 serviços de experiência, incluindo referência ao núcleo clínico existente; **70 ferramentas clínicas do pacote original preservadas** sem clonar configurações, lógica ou conteúdo.
- **48 projeções de ferramentas com operação local**, apoiadas em **35 coleções compartilhadas**. Isso significa CRUD/edição, persistência no navegador, exportação por ferramenta em JSON e CSV, e exportação/importação global. **Não equivale a 48 aplicativos profissionais completos nem a serviço na nuvem.**
- **2 projeções de rotas existentes**, sem criar motor duplicado (fórum informativo e central clínica).
- **18 capacidades registradas em HOLD**, sem telas que simulem serviço online ou conformidade normativa.
- **7 novas páginas de domínio + hub `/ecossistema/`** a partir de `templates/ecossistema.html` e do gerador `tools/gerar_ecossistema.py`.
- **Integração por link**, nos templates canônicos da área de acesso e da área do assinante, após rodar gerador existente. A Área do Assinante e seus recursos antigos não foram substituídos. O script `npm run gerar` e o portão `npm run check` passam agora pelo novo gerador, com o teste de contratos opcional separado para ambientes sem Python `jsonschema`.
- **Prévia de três pacotes, regras e sete addons candidatos**, com visualização de diferenças de serviços para upsell/downsell. Sem preço, checkout, contrato celebrado ou concessão de direitos.

## Fontes e contratos

| Artefato | Responsabilidade única |
|---|---|
| `configs/ecossistema/catalogo.json` | Capacidade, origem, serviço, estado e dependências |
| `configs/ecossistema/formularios.json` | Modelo de dados dos 48 fluxos locais, com nomes de coleções compartilhados |
| `configs/ecossistema/ofertas.json` | Propostas e políticas comerciais sem autoridade de cobrança |
| `schema/ecossistema-*.schema.json` | Tipos JSON Schema Draft 2020-12 |
| `templates/ecossistema.html` | HTML de composição (não duplicar tela por serviço) |
| `assets/css/ds-canonico.css` | Design System original, **não modificado** |
| `assets/css/cko-ecosystem.css` | Estilos locais no namespace `.cko-*`, consumindo apenas tokens `--ds-*` |
| `assets/js/cko-ecosystem.js` | Renderer, navegação, CRUD local, PICO, CV, simulados, revisão espaçada, import/export |
| `tools/gerar_ecossistema.py` | Geração idempotente e validação referencial |
| `migrations/candidates/*.sql` | Candidato de banco, **não aplicado** |

### Reuso verificável

- `Passaporte profissional → Currículo profissional/acadêmico → Carta de apresentação`: uma coleção `profile`, com portfólio, certificações e produção acadêmica por composição.
- `Simulados → Quizzes → Questões → Caderno de erros`: uma coleção `question_bank` com correção e histórico de tentativas/erros; **questões não foram inventadas**.
- `PICO → Estratégia de busca`: mesma coleção `research_pico`; a consulta é ponto de partida, não revisão automática.
- `Referências → Triagem → Resumo PRISMA`: coleções próprias para dados distintos, com cálculo dos contadores a partir de triagens existentes; **não afirma conformidade PRISMA**.
- `Vagas hospitalares / ONGs / internacionais`: mesma coleção `career_opportunities`, com atributo de tipo.
- `Concursos / residências / comparador`: mesma coleção `exam_notices`, preenchida pelo próprio usuário, sem alegar monitoramento oficial em tempo real.

## Segurança, privacidade e limitações técnicas

1. Todas as páginas desta entrega são **públicas**. `localStorage` não é autenticação nem autorização, não protege dados contra usuários do mesmo perfil de navegador e pode ser apagado pelo navegador. Não utilizar para prontuário ou dados de paciente.
2. O editor de rascunhos da comunidade **não publica** nada. Mentorias, comentários, grupos, moderação, reputação e a comunidade para pacientes/cuidadores exigem backend, classificação etária, consentimento e revisão editorial.
3. Registros de NR-01, NR-32, SAE e CME permanecem HOLD. Um CRUD genérico não poderia demonstrar conformidade normativa ou segurança assistencial.
4. `ofertas.json` é somente prévia; sem preço definido e sem checkout. Um usuário nunca se torna Premium por seleção em JavaScript. O desenho `migrations/candidates` depende de autenticação, política de acesso, processamento de webhooks, legislação e Kernel antes da aplicação.
5. Exportação CSV mitiga fórmulas em células (`=`, `+`, `-`, `@`); texto do usuário é renderizado como texto, não como HTML; URLs aceitam apenas HTTP(S). Limites de 5MB e validações de backup são locais; **não constituem avaliação de segurança de produção**.
6. Faltam sincronização, contas, controle de acesso, notificações, faturas, cancelamento em servidor, pesquisa/vagas em tempo real, publicação comunitária e funcionalidade de IA governada. **Não declarar esses recursos como completos.**

## Testes executados nesta cópia

- `python tools/gerar_ecossistema.py --check` — PASS, 8 páginas sincronizadas.
- `python tools/testar_contratos_ecossistema.py` — PASS JSON Schema + vínculos + salvaguardas de comércio.
- `python tools/testar_ecossistema.py` — PASS 11 verificações em Chromium com HTML/CSS/JS reais, porém navegação substituída por **fixture em memória**, pois HTTP/file são bloqueados pelo navegador deste ambiente.
- `python tools/gerar_areas.py --check`, `python tools/gerar_paginas.py --check`, `python tools/gerar_conteudo.py --check`, `python tools/gerar_manus_routes.py --check`, `node tools/minificar-ux-css.mjs --check`, `python tools/auditar.py` — PASS após regenerar as rotas.
- Testes negativos de backend, RLS, pagamento, consentimento e colaboração: **NÃO EXECUTADOS**. Nenhuma conexão a DB/checkout configurada.

## Gates que faltam para um sistema completo

| Gate | Pendência | Estado |
|---|---|---|
| K0 | Work Order gerada pelo Kernel e vinculação ao repositório/branch e IDs definitivos | HOLD |
| K1 | Reconciliar objetos canônicos existentes do GitHub/Supabase e deduplicar pelo identificador original + versão | HOLD |
| K2 | Conectar identidade, consentimento, usuários, papéis, RLS, auditoria e revogação | HOLD |
| K3 | Publicação, moderação e relacionamentos comunitários com restrições por público e idade | HOLD |
| K4 | Conteúdo validado e fontes oficiais para cursos, questões, NR, clínica, vagas e residências | HOLD |
| K5 | Serviços comerciais versionados, contratos, tributos, cobrança, Pix Automático, estorno e cancelamento | HOLD |
| K6 | E2E real servido via URL, segurança, acessibilidade assistiva, testes clínicos e aprovação independente | HOLD |

### Instrução de integração manual sem promover produção

Aplicar somente os arquivos presentes no pacote incremental em uma branch candidata. Usar os scripts existentes para reconstruir áreas e rotas. Executar os gates acima; não tocar `main` nem aplicar SQL sem autorização do Kernel. **Não repacotar as fontes originais**, pois esta entrega é um patch de arquivos adicionados/alterados.
