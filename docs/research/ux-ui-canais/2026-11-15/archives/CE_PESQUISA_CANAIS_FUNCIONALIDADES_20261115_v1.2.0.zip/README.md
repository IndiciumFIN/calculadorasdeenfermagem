# Pacote incremental v1.2.0

Complementa CE_PLANO_UX_FUNCIONAL_20261115_v1.1.0. Contém somente novos artefatos de planejamento e pesquisa; arquivos da versão anterior não foram alterados. Não implanta código, não cria dados no Supabase e não aprova nenhuma Work Order.
