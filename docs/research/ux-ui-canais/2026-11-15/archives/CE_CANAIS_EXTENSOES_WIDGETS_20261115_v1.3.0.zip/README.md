# CE canais v1.3.0
Complemento documental a v1.1.0/v1.2.0, para revisão antes de código. Não homologado.
