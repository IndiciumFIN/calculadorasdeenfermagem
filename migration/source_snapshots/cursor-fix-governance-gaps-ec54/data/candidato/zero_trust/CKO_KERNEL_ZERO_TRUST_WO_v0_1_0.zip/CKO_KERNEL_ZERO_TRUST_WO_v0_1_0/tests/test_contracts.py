"""Schema and registry conformance tests. JSON Schema meta-validation is optional."""
import json
import unittest
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
try: import jsonschema
except ImportError: jsonschema=None

class ContractTests(unittest.TestCase):
    def test_all_seven_schemas_have_required_contract_fields(self):
        schemas=sorted((BASE/'contracts').glob('*.schema.json'))
        self.assertEqual(len(schemas),7)
        for path in schemas:
            d=json.loads(path.read_text(encoding='utf8'))
            self.assertEqual(d['$schema'],'https://json-schema.org/draft/2020-12/schema')
            self.assertFalse(d['additionalProperties'])
            self.assertTrue(d['required'])

    @unittest.skipUnless(jsonschema,'Optional jsonschema package not installed')
    def test_draft_2020_12_meta_schemas(self):
        for path in (BASE/'contracts').glob('*.schema.json'):
            with self.subTest(path=path.name):
                jsonschema.Draft202012Validator.check_schema(json.loads(path.read_text(encoding='utf8')))

    @unittest.skipUnless(jsonschema,'Optional jsonschema package not installed')
    def test_demo_wo_evidence_and_find_conform_to_contracts(self):
        demo=json.loads((BASE/'examples'/'demo_evidence.json').read_text(encoding='utf8'))
        mapping={'wo-request':'proposed_work_order_request',
                 'work-order-authorized':'kernel_signed_wo',
                 'signed-run-evidence':'signed_success_manifest',
                 'policy-find':'auto_created_find'}
        for contract,key in mapping.items():
            schema=json.loads((BASE/'contracts'/f'{contract}.schema.json').read_text(encoding='utf8'))
            with self.subTest(contract=contract):
                jsonschema.validate(demo[key],schema)
        schema=json.loads((BASE/'contracts'/'audit-event.schema.json').read_text(encoding='utf8'))
        for event in demo['signed_audit_events']:
            jsonschema.validate(event,schema)
        schema=json.loads((BASE/'contracts'/'signed-run-evidence.schema.json').read_text(encoding='utf8'))
        jsonschema.validate(demo['signed_denial_manifest'],schema)

    def test_all_candidate_tasks_have_unique_owner_and_referenced_validators(self):
        tasks=json.loads((BASE/'registries'/'task_definition_registry.json').read_text(encoding='utf8'))['tasks']
        agents={a['agent_id'] for a in json.loads((BASE/'registries'/'agent_identity_inventory.json').read_text(encoding='utf8'))['agents']}
        valid=set(json.loads((BASE/'registries'/'validator_registry.json').read_text(encoding='utf8'))['validators'])
        for t in tasks.values():
            if t['origin']=='NEW_PROPOSED_CANDIDATE':
                self.assertIn(t['owner_agent_id'],agents)
                self.assertEqual(len(t['validator_ids']),len(set(t['validator_ids'])))
                self.assertTrue(set(t['validator_ids']).issubset(valid))
                self.assertFalse(t['independently_homologated'])

    def test_policy_preserves_kernel_only_issuer_no_superagent_write(self):
        p=json.loads((BASE/'policies'/'zero_trust_wo.json').read_text(encoding='utf8'))
        self.assertTrue(p['rules']['superagent_cannot_issue_wo'])
        self.assertTrue(p['rules']['superagent_cannot_execute'])
        self.assertTrue(p['rules']['any_artifact_creation_requires_wo'])
        self.assertTrue(p['rules']['find_on_policy_denial'])

if __name__=='__main__':unittest.main()
