/** Candidate CKO LLM Gateway admission layer. NOT DEPLOYED.
 * The existing gateway lacks WO enforcement; this must be placed before any
 * provider call and paired with network egress restriction.
 * Requires a separately authenticated Kernel introspection service that checks:
 * - real caller identity/OIDC, WO signature, issuer, task, action, tenant
 * - policy/task/validator versions and hashes, prompt/input/model bindings
 * - nonce replay and expiry, authorized request, cost/resource limits
 * - audience=cko-llm-gateway, subject/model/temperature=0, 1-time consumption
 * Fail-closed on missing token, unreachable Kernel, timeout, malformed reply.
 */
export type Admission = {ok: true; authorizationId: string; callerId: string} | {ok: false; status: number; reason: string};

export async function admitLLMInvocation(req: Request): Promise<Admission> {
  if (req.method !== "POST") return {ok:false,status:405,reason:"method_not_allowed"};
  const url = Deno.env.get("CKO_KERNEL_INTROSPECTION_URL");
  const kernelBearer = Deno.env.get("CKO_GATEWAY_TO_KERNEL_WORKLOAD_CREDENTIAL");
  // Do not fall back to legacy gateway when verification service is absent.
  if (!url || !kernelBearer || !url.startsWith("https://"))
    return {ok:false,status:503,reason:"kernel_pep_unavailable"};
  const callerToken = req.headers.get("authorization") || "";
  const wo = req.headers.get("x-cko-work-order") || "";
  const idempotencyKey = req.headers.get("x-cko-run-nonce") || "";
  if (!callerToken.startsWith("Bearer ") || !wo || !idempotencyKey)
    return {ok:false,status:403,reason:"authenticated_wo_required"};
  let parsed: Record<string, unknown>;
  try { parsed = await req.clone().json(); } catch { return {ok:false,status:400,reason:"body_invalid"}; }
  if (parsed.temperature !== 0 || typeof parsed.model !== "string" || !Array.isArray(parsed.messages))
    return {ok:false,status:403,reason:"model_request_outside_wo_contract"};
  const controller = new AbortController();
  const timeout = setTimeout(()=>controller.abort(), 3000);
  try {
    const answer = await fetch(url, {
      method: "POST", signal: controller.signal,
      headers: {"content-type":"application/json","authorization":`Bearer ${kernelBearer}`},
      body: JSON.stringify({requested_audience:"cko-llm-gateway", caller_token:callerToken,
        work_order_id:wo, run_nonce:idempotencyKey, model:parsed.model,
        temperature:0, request_payload:parsed})
    });
    if (answer.status !== 200) return {ok:false,status:403,reason:"kernel_denied"};
    const verified = await answer.json();
    if (verified?.allowed !== true || verified?.decision !== "ALLOW" ||
        verified?.audience !== "cko-llm-gateway" || typeof verified?.authorization_id !== "string" ||
        typeof verified?.subject !== "string") return {ok:false,status:403,reason:"invalid_kernel_attestation"};
    return {ok:true,authorizationId:verified.authorization_id,callerId:verified.subject};
  } catch { return {ok:false,status:503,reason:"kernel_attestation_unavailable"}; }
  finally {clearTimeout(timeout);}
}

// Integration reminder: call admitLLMInvocation() before using provider secrets,
// and do not give agents alternate provider API keys or network egress paths.
