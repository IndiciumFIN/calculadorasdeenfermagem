# CKO · Kernel Zero-Write-Without-WO · pacote incremental v0.1.0

**Status:** `CANDIDATE_NOT_HOMOLOGATED` — revisão e demonstração offline, **NÃO INSTALADO**.

**Origem examinada:** `IndiciumFIN/calculadorasdeenfermagem`, branch `cursor/fix-governance-gaps-ec54`, commit `7cea80c572b1a789aa45388ff2af6828c1ff82b4` no momento do inventário de agentes. A branch foi atualizada durante a análise; o pacote NÃO atualiza, reescreve ou reconcilia automaticamente o repositório.

## Diagnóstico reproduzível do inventário

- 110 IDs distintos em `agents/registry.json`: **2 com status declarado `vigente`**, 108 com status `candidato` (COSO/IT Governance). A presença de um ID não demonstra autenticação ou separação real de funções.
- 20 papéis candidatos de supervisão/orquestração no inventário consolidado (**incluindo um `AGT-ORCH-001` recém-proposto**). Papéis `SUPERAGENT`, `ORCHESTRATOR` ou `DOMAIN_COORDINATOR` são **classificações propostas** para governança, não papéis já homologados do runtime.
- 18 IDs de especialidade propostos, sem pretender substituir os 110 existentes. Com isso, 128 IDs **sem colisões** no inventário candidato.
- 15 Task Definitions vistas na branch: 9 marcadas `QUALIFICADA`, 6 `NAO_QUALIFICADA` no fonte. O pacote **não aceita essas marcações como prova de homologação independente**. Todas as 15 aparecem como `HOLD_RECONCILE` no overlay.
- 10 Task Definitions adicionais para criar apenas **candidatos**, todas `CANDIDATE_NOT_HOMOLOGATED`, com executor principal único indicado. Nem elas, nem os 18 agentes adicionais, são ativados pela geração do ZIP.
- Principais violações atuais de exclusividade: `packages/cli/registry.py` possui escrita direta (`add`, `set_status`) e `supabase/functions/cko-deepseek-gateway/index.ts` aceita chamadas de modelo sem a atestação de uma WO do Kernel.

## Regra absoluta proposta

> **Nenhum agente, superagente, LLM, CLI, CMS, Builder, função Edge, script ou job cria, altera, remove, publica ou persiste qualquer artefato ou status sem uma Work Order emitida, assinada, vigente e validada pelo serviço exclusivo do Kernel, vinculada a uma Task Definition previamente homologada.**

O **agente pode solicitar**, mas não emitir, aprovar, assinar, transferir ou reinterpretar WO. **O superagente só orquestra solicitações e resultados**, não herda as permissões dos agentes filhos. O **Kernel não decide domínio ou política**: resolve contratos e políticas aprovadas do Master Data / Canonical Control Plane, aplica a verificação e registra o resultado autorizado.

**Exceção estritamente técnica para evitar um paradoxo de auditoria:** se uma solicitação chega sem WO e deve ser bloqueada, **o Kernel** pode registrar um evento e um FIND por meio de sua própria **WO raiz de auditoria pré-provisionada e assinada externamente** (`WO-SYSTEM-AUDIT-ROOT-001`). Essa capacidade **não autoriza criar conteúdo de usuário** nem é delegável a agentes. Sem essa WO raiz válida, o serviço deve falhar na inicialização.

## Sequência executável proposta

1. `Task Registry`: procedimento conhecido, versionado, com proprietário único e validação independente da qualificação.
2. `WO Request`: proposta **não persistida pelo agente**, com identidade de solicitante, executor, ação, alvo, hash de entrada, política, validade e escopo.
3. `Human Approval`: autorização assinada por serviço distinto, vinculada ao SHA-256 canônico da solicitação.
4. `Kernel.issue`: valida identidades, qualificação, SoD, Task Definition, recursos, expiracão, aprovação, política e unicidade; **assina a WO** e emite manifesto de autorização.
5. `Kernel.execute`: compara a WO com a emitida, confere assinatura, issuer, audience, nonce, validade, executor autenticado e Task Registry. **Consome a WO uma vez**, inclusive na falha.
6. `Validators`: executa os validadores obrigatórios; cada um produz `PASS`/`FAIL` com ID de política. Em falha: **não escreve conteúdo**, emite manifesto assinado com resultado `DENIED`, evento encadeado e FIND determinístico/deduplicado.
7. Em `PASS`: emite manifesto assinado de execução, hash de artefato e cria **apenas candidato não homologado**. Nenhuma publicação/alteração de estado canônico ocorre no protótipo.
8. `FIND`: permanece `OPEN` até correção via Task Definition aprovada, reteste independente e outra WO de fechamento com aprovação humana. O protótipo **nega todos os encerramentos de FIND**, pois essa integração completa ainda não foi homologada.

## Assinaturas e limitação probatória

O mecanismo offline usa **HMAC-SHA256** com três chaves de teste separadas (identidade, aprovação humana e Kernel) e uma quarta chave de raiz de auditoria. A assinatura cobre os objetos canônicos; a trilha de eventos registra hash anterior e MAC. **Isso demonstra integridade verificável no protótipo, não assinatura digital institucional, confiança em identidade de produção ou não repúdio.**

Para produção, usar chaves assimétricas KMS/HSM, identidades reais via OIDC/workload identity, atestação assinada com `key_id`, registrador transacional com restrição UNIQUE e consumo idempotente, event-store imutável/WORM e autorização DB-first. Agentes não podem ter acesso ao service_role, credenciais de banco, provider secrets, filesystem de publicação ou tokens de GitHub com escrita.

**Não confundir:** esquema JSON válido ≠ autorização real; assinatura válida ≠ conclusão semântica correta; validação `PASS` de candidato ≠ homologação ou publicação; teste negativo `PASS` ≠ controle universal em produção.

## Arquivos do pacote

| Pasta | Descrição |
|---|---|
| `registries/` | Inventário de 128 identidades; crosswalk; exclusividade de Task Definitions; 15 tarefas da origem + 10 propostas; 16 validadores de referência |
| `policies/` | Política Zero-Write, assinaturas, segregação de funções, ciclo FIND |
| `contracts/` | 7 JSON Schemas: identidade, Task Definition, solicitação WO, WO assinada, Run, FIND e evento |
| `cko_guard/` | Motor Python de política offline, assinador HMAC de teste, assinador raiz, verificação de WO, FIND automático, evidência e auditoria |
| `tests/` | Testes positivos/negativos de identidade, task, WO, superagent, hash, licença, alvo, FIND, replay, assinatura e corrupção de evidência |
| `examples/` | Simulação com manifesto de bloqueio e de sucesso, FIND e cadeia de auditoria assinados com **chaves de teste** |
| `integration/` | Exemplo de guard para gateway LLM, ACL SQL desativada (`ROLLBACK`), matriz de enforcement e passos de integração |

## Executar offline

```bash
cd CKO_KERNEL_ZERO_TRUST_WO_v0_1_0
python -m unittest discover -s tests -v
python examples/run_demo.py
python verify_package.py
```

**Não há dependências de rede** para o protótipo. Os exemplos só alteram seus próprios arquivos temporários/locais quando executados pelo usuário. Nenhuma integração de GitHub, Supabase ou Drive é acionada.

## Critérios de integração obrigatórios (P0)

1. Kernel com identidade de serviço separada e credencial não acessível a agentes.
2. RLS + ACL reais em TODAS as tabelas/buckets, inclusive rotas administrativas; proteção contra bypass `service_role`.
3. Assinatura de WO vinculada à identidade autenticada, ao digest dos inputs, à Task Definition e à política válida; escopo, tenant, nonce e expiração.
4. Gateway de LLM recusa qualquer modelo/prompt/mensagem sem introspecção transacional da WO junto ao Kernel; nenhuma chave de provider fica com agentes.
5. `registry.py`, CLI, GitHub, filesystem e Builders perdem capacidade de escrita direta; REST, WebSocket, Edge Functions e jobs são abrangidos.
6. Cada VALIDATOR obrigatório deve emitir PASS/HOLD/FAIL, com evidências vinculadas por hash. Nenhum nome de validator sem executor qualificado conta como cobertura.
7. FIND automático para violação, com política, validador, erro, identidade, alvo, run, WO e evidência. Bloqueio sem perda do histórico.
8. O fechamento exige correção, reteste independente, aprovação autenticada e transição pelo Kernel; **sem exceção `auto-approve` de agente ou LLM**.
9. Testes E2E de impossibilidade de bypass, idempotência, concorrência, revogação e restauração de evidências. Pass/fail por requisito `REQUIRED × PRESENT × VALIDATED × EVIDENCED`.

Os itens acima **NÃO estão implementados em produção por este pacote**. A instalação exigiria autorização explícita e reconciliação do projeto existente.
