"""Build static candidate registries from the source inventory identified at commit 7cea80c.
This does NOT read or modify the original repository and is not an installation script.
"""
from __future__ import annotations
import json
from pathlib import Path
R=Path(__file__).resolve().parent
REF="7cea80c572b1a789aa45388ff2af6828c1ff82b4"
def dump(name,obj):
 p=R/name;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+"\n",encoding="utf-8")

historical=[]
def add(identifier,kind,source_status,activity="DIAGNOSTICO",delegates=None):
 assert not any(a["agent_id"]==identifier for a in historical),identifier
 superagent=kind in ("SUPERAGENT","ORCHESTRATOR","DOMAIN_COORDINATOR")
 historical.append({"agent_id":identifier,"identity_class":kind,"status_source":source_status,"target_state":"HOLD_RECONCILE","allowed_intent":["REQUEST_WO","READ_AUTHORIZED_SNAPSHOT","PROPOSE_DIAGNOSTIC"],"forbidden_effects":["ISSUE_WO","APPROVE_WO","EXECUTE_WITHOUT_VALID_WO","PERSIST_ANY_ARTIFACT_WITHOUT_WO","CHANGE_STATE_DIRECTLY","CLOSE_FIND_DIRECTLY","WRITE_PROVIDER_GATEWAY_DIRECTLY","PUBLISH_DIRECTLY","CREATE_AGENTS_DIRECTLY","CHANGE_POLICIES_DIRECTLY"],"task_ownership":"NOT_QUALIFIED","superagent":superagent,"delegable_request_roles":delegates or [],"source_ref":"agents/registry.json","source_sha":REF,"activity_tag":activity})
# 2 currently described as vigente; independently unverified.
add("AGT-EXTRATOR-001","SPECIALIST","vigente","EXTRACAO_LITERAL")
add("AGT-AUDITOR-001","SPECIALIST","vigente","AUDITORIA_FIDELIDADE")
# Governance of IT: 40 objective agents + 5 domain + 1 master + 8 cross-domain + 4 GRC.
add("AG-CKO-ITG-MASTER","SUPERAGENT","candidato","PORTFOLIO_IT_GOVERNANCE")
for domain,n in [("EDM",5),("APO",14),("BAI",11),("DSS",6),("MEA",4)]:
 add("AG-CKO-ITG-"+domain,"DOMAIN_COORDINATOR","candidato",f"COORDINACAO_{domain}")
 for i in range(1,n+1):add(f"AG-CKO-ITG-{domain}{i:02}","SPECIALIST","candidato",f"DIAGNOSTICO_{domain}{i:02}")
for name in ["ASSET-RECONCILER","CONTROL-VALIDATOR","CYCLE-RETESTER","EVIDENCE-INSPECTOR","FIND-TRIAGER","POLICY-INSPECTOR","PUBLICATION-GUARD","SOD-ANALYST"]:
 add("AG-CKO-ITG-"+name,"SPECIALIST","candidato",name)
for name in ["COSO-DEFICIENCY","COSO-DESIGN","COSO-OPERATION","CROSSWALK"]:
 add("AG-CKO-GRC-"+name,"SPECIALIST","candidato",name)
add("AG-COSO-MASTER","SUPERAGENT","candidato","PORTFOLIO_COSO")
for family,parts,nn in [("ICIF",["AC","AR","CA","IC","MO"],17),("ERM",["EO","GC","IR","PE","RR"],20)]:
 add(f"AG-{family}-ORQ","ORCHESTRATOR","candidato",f"COORDINACAO_{family}")
 for part in parts:add(f"AG-{family}-{part}","DOMAIN_COORDINATOR","candidato",f"COMPONENTE_{family}_{part}")
 for i in range(1,nn+1):add(f"AG-{family}-P{i:02}","SPECIALIST","candidato",f"PRINCIPIO_{family}_P{i:02}")
assert len(historical)==110,len(historical)
new_roles=[
("AGT-CKO-REG-AUTHORITY-001","QUALIFICAR_AUTORIDADE"),
("AGT-CKO-REG-LICENSE-001","QUALIFICAR_DIREITOS"),
("AGT-CKO-REG-SOURCE-001","QUALIFICAR_FONTE"),
("AGT-CKO-REG-STRUCTURE-001","VALIDAR_ESTRUTURA_NORMATIVA"),
("AGT-CKO-REG-ATOM-001","GERAR_CANDIDATOS_ATOMICOS"),
("AGT-CKO-REG-TEMPORAL-001","ANALISAR_VIGENCIA_CANDIDATA"),
("AGT-CKO-REG-RELATIONS-001","PROPOR_RELACOES_NORMATIVAS"),
("AGT-CKO-REG-APPLICABILITY-001","PROPOR_APLICABILIDADE"),
("AGT-CKO-MD-BINDING-001","PROPOR_BINDINGS_MD"),
("AGT-CKO-POLICY-REVIEW-001","REVISAR_POLITICAS"),
("AGT-CKO-VAL-QA-001","ANALISAR_VALIDACAO"),
("AGT-CKO-EVIDENCE-001","INSPECIONAR_EVIDENCIAS"),
("AGT-CKO-FIND-DIAG-001","ANALISAR_FINDS"),
("AGT-CKO-FIND-RETEST-001","RETESTAR_CORRECOES"),
("AGT-CKO-RELEASE-REVIEW-001","REVISAR_RELEASE"),
("AGT-CKO-API-CONTRACT-001","QUALIFICAR_CONTRATOS_API"),
("AGT-CKO-SOURCE-MONITOR-001","MONITORAR_ALTERACOES"),
("AGT-ORCH-001","SOLICITAR_ORQUESTRACAO")]
for ident,activity in new_roles:
 add(ident,"SUPERAGENT" if ident=="AGT-ORCH-001" else "SPECIALIST","NOT_PRESENT_IN_REPO_CANDIDATE",activity)
assert len(historical)==128
names=[x["agent_id"] for x in historical];assert len(names)==len(set(names))
for a in historical:
 if a["superagent"]:a["may_issue_wo"]=False;a["may_execute_wo"]=False;a["may_delegate_authority"]=False
 else:a["may_issue_wo"]=False;a["may_execute_wo"]="ONLY_IF_HOMOLOGATED_AND_WO_AUTHORIZED"
dump("registries/agent_identity_inventory.json",{"schema_version":"0.1.0","source_repository":"IndiciumFIN/calculadorasdeenfermagem","source_commit":REF,"source_identifiers":110,"new_candidate_identifiers":len(new_roles),"total_identifiers":len(historical),"do_not_promote_source_status":True,"agents":historical})
# A role can be exclusive per task only when prevalidated and assigned by policy. All are HOLD in production.
source_tasks=[("TAREFA-OBTER","obter",True),("TAREFA-ATOMIZAR","atomizar",True),("TAREFA-VALIDAR","validar",True),("TAREFA-RETIRAR","retirar",True),("TAREFA-T01","ingest",False),("TAREFA-T02","process",False),("TAREFA-T03","validate",False),("TAREFA-T04","pipeline",False),("TAREFA-T07","set-status",False),("TAREFA-LLM-RUN","llm_runner",False),("TAREFA-FIND-REGISTRAR","registrar-find",True),("TAREFA-FIND-VINCULAR","vincular-find",True),("TAREFA-FIND-ENCERRAR","encerrar-find",True),("TAREFA-FIND-ANALISAR","analisar-find",True),("TAREFA-FIND-CORRIGIR","corrigir-find",True)]
new_tasks=[
 ("TD-REG-LICENSE-CHECK-001","AGT-CKO-REG-LICENSE-001","CREATE_CANDIDATE","regulatory/licenses/"),
 ("TD-REG-SOURCE-CHECK-001","AGT-CKO-REG-SOURCE-001","CREATE_CANDIDATE","regulatory/sources/"),
 ("TD-REG-ATOM-CANDIDATE-001","AGT-CKO-REG-ATOM-001","CREATE_CANDIDATE","regulatory/atoms/"),
 ("TD-REG-TEMPORAL-CANDIDATE-001","AGT-CKO-REG-TEMPORAL-001","CREATE_CANDIDATE","regulatory/temporal/"),
 ("TD-REG-RELATION-CANDIDATE-001","AGT-CKO-REG-RELATIONS-001","CREATE_CANDIDATE","regulatory/relations/"),
 ("TD-REG-APPLICABILITY-001","AGT-CKO-REG-APPLICABILITY-001","CREATE_CANDIDATE","regulatory/applicability/"),
 ("TD-API-CONTRACT-CANDIDATE-001","AGT-CKO-API-CONTRACT-001","CREATE_CANDIDATE","api/contracts/"),
 ("TD-FIND-DIAG-CANDIDATE-001","AGT-CKO-FIND-DIAG-001","CREATE_CANDIDATE","audit/find-candidates/"),
 ("TD-FIND-RETEST-001","AGT-CKO-FIND-RETEST-001","CREATE_CANDIDATE","audit/retests/"),
 ("TD-REG-CAPTURE-001","AGT-EXTRATOR-001","CREATE_CANDIDATE","regulatory/candidates/"),
]
reg={}
for tid,procedure,qualified in source_tasks:
 reg[tid]={"task_id":tid,"origin":"EXISTING_REPO_TASK_REGISTRY","source_qualification":"QUALIFICADA" if qualified else "NAO_QUALIFICADA","state":"HOLD_RECONCILE","independently_homologated":False,"version":"SOURCE_VERSION_UNVERIFIED","owner_agent_id":None,"action":None,"target_prefix":None,"validator_ids":[],"effect":"NONE_UNTIL_HOMOLOGATED"}
for tid,owner,action,prefix in new_tasks:
 reg[tid]={"task_id":tid,"origin":"NEW_PROPOSED_CANDIDATE","source_qualification":"N/A","state":"CANDIDATE_NOT_HOMOLOGATED","independently_homologated":False,"version":"0.1.0","owner_agent_id":owner,"action":action,"target_prefix":prefix,"validator_ids":["V-AUTH-WO","V-AGENT-EXCLUSIVE","V-INPUT-DIGEST","V-LICENSE","V-PROVENANCE","V-TARGET-PREFIX","V-FIND-BLOCKER","V-OUTPUT-NONEMPTY"],"effect":"CANDIDATE_ONLY"}
dump("registries/task_definition_registry.json",{"schema_version":"0.1.0","denominator_existing_tasks":15,"proposed_task_definitions":len(new_tasks),"all_nonoperational_until_homologated":True,"tasks":reg})
validators={
 "V-AUTH-WO":"Verify WO MAC, issuer, expiry, registry existence, scope, nonce and caller credential",
 "V-AGENT-EXCLUSIVE":"One qualified executor ID per Task Definition; no superagent execution",
 "V-INPUT-DIGEST":"Compare SHA256 over exact canonical payload bytes before mutation",
 "V-LICENSE":"Check rights classification allows the specifically requested kind of storage",
 "V-PROVENANCE":"Require valid source_id and retrievable source reference metadata",
 "V-TARGET-PREFIX":"Verify normalized resource belongs to task's approved namespace",
 "V-FIND-BLOCKER":"Reject new privileged operations when a blocking FIND affects target",
 "V-OUTPUT-NONEMPTY":"Reject empty or malformed generated content",
 "V-CLOSURE-RETEST":"Check independent retest evidence; must reject self-declared PASS",
 "V-CLOSURE-AUTHORITY":"Check human closure approval bound to FIND, task and validated retest",
 "V-GATEWAY-AUTH":"Introspect WO with Kernel (audience=llm_gateway, policy and request digest)",
 "V-CI-CONTROL":"Detect unmanaged mutation paths in source and release permission scope"}
dump("registries/validator_registry.json",{"schema_version":"0.1.0","validator_status":"CANDIDATE_REFERENCE_IMPLEMENTATION","validators":{k:{"validator_id":k,"description":v,"required_for_promotion":True} for k,v in validators.items()}})
dump("registries/role_exclusivity.json",{"schema_version":"0.1.0","enforcement_state":"HOLD_CANDIDATE","rule":"Only one qualified primary executor per atomic task. Superagents coordinate requests, never inherit child capabilities.","exclusive_task_owner":{t[0]:t[1] for t in new_tasks},"superagent_ids":[a["agent_id"] for a in historical if a["superagent"]],"separation_of_duties":[["executor","approver"],["executor","independent_validator"],["find_reporter","closure_reviewer"],["policy_author","policy_approver"]],"no_claim_of_existing_technical_exclusivity":True})
dump("registries/crosswalk_repository.json",{"source_repo":"IndiciumFIN/calculadorasdeenfermagem","commit":REF,"read_only":True,"findings":[{"id":"ID-001","status":"EXISTS","description":"110 distinct agent IDs, but activity ownership/agent recertification not fully qualified","paths":["agents/registry.json","data/grc/agentes.json"]},{"id":"ID-002","status":"GAP","description":"Superagents represented in candidate roles; no enforced delegation caps or distinct authenticated identity service","paths":["agents/registry.json","docs/AGENTS.md"]},{"id":"AUTH-001","status":"CRITICAL","description":"WO authorized_by is textual and there is no trusted issuer or signature verification","paths":["packages/cli/pep.py","contracts/work_order.schema.json"]},{"id":"AUTH-002","status":"CRITICAL","description":"Gateway accepts model/messages without verifying Kernel-issued WO capability","paths":["supabase/functions/cko-deepseek-gateway/index.ts"]},{"id":"SIDE-001","status":"CRITICAL","description":"registry CLI add/set-status can write directly without Kernel WO","paths":["packages/cli/registry.py"]},{"id":"FIND-001","status":"CRITICAL","description":"Denial and validator FAIL are not guaranteed to append policy-attributed FIND and signed evidence","paths":["packages/cli/kernel.py","data/finds/registro.json"]}]})
policy={"policy_id":"POL-CKO-ZERO-WRITE-WITHOUT-WO-001","version":"0.1.0","status":"CANDIDATE_NOT_DEPLOYED","default":"DENY","enforcement_points":["CLI","RUNTIME","SUPABASE_RLS","STORAGE","GIT_WRITE","GATEWAY_LLM","BUILDER","CMS","AGENT_SDK","AUTOMATION","EDGE_FUNCTION"],"rules":{"any_artifact_creation_requires_wo":True,"any_state_transition_requires_wo":True,"any_remote_mutation_requires_wo":True,"any_llm_call_requires_wo":True,"agent_identity_credential_required":True,"human_approval_required":True,"task_prequalified_required":True,"wo_signature_required":True,"execution_manifest_signature_required":True,"validator_coverage_required":True,"find_on_policy_denial":True,"blocking_find_denies_promotion":True,"superagent_cannot_execute":True,"superagent_cannot_issue_wo":True,"no_delegation_of_authority":True,"unique_executor_per_task":True,"immutable_evidence_ledger_required":True,"replay_protection_required":True,"audit_log_break_glass_only_kernel":True},"emergency_audit_wo":{"id":"WO-SYSTEM-AUDIT-ROOT-001","purpose":"Kernel-private, preauthorized and signed system WO solely for mandatory security/denial recording, never for user content writes","agents_may_use":False,"external_effects_allowed":False,"must_be_preprovisioned":True},"license_allowlist":["PUBLIC_FREE_NO_REGISTRATION_PERMITTED","PROJECT_OWNED_LICENSED"],"never_auto_promote":["CANDIDATE_NOT_HOMOLOGATED","REFERENCE_ONLY","LICENSE_BLOCKED","VERIFY_PENDING"]}
dump("policies/zero_trust_wo.json",policy)
print(json.dumps({"historical_agents":110,"proposed":len(new_roles),"total":len(historical),"superagents":len([a for a in historical if a['superagent']]),"source_tasks":15,"candidate_tasks":len(new_tasks),"validators":len(validators)},ensure_ascii=False))
