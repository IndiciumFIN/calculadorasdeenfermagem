"""Verify the package's SHA-256 manifest; no network or side effects."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
MANIFEST=ROOT/'SHA256SUMS.json'

def checksum(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def verify():
    if not MANIFEST.is_file():return False,['Manifest missing']
    record=json.loads(MANIFEST.read_text(encoding='utf-8'))
    got={p.relative_to(ROOT).as_posix():checksum(p) for p in ROOT.rglob('*')
         if p.is_file() and '__pycache__' not in p.parts and p!=MANIFEST}
    original=record['files']
    errors=[]
    for path in sorted(set(got)|set(original)):
        if path not in got:errors.append('MISSING '+path)
        elif path not in original:errors.append('UNLISTED '+path)
        elif got[path]!=original[path]:errors.append('SHA_MISMATCH '+path)
    return not errors,errors
if __name__=='__main__':
    ok,errors=verify()
    print('PASS — SHA-256 manifest verified' if ok else 'FAIL — manifest verification failed')
    if errors:print('\n'.join(errors[:30]))
    sys.exit(0 if ok else 2)
