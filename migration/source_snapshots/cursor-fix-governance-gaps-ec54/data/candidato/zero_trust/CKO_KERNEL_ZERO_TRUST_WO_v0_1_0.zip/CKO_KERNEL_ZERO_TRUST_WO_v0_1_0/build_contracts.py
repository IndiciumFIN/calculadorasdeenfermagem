import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SCHEMA='https://json-schema.org/draft/2020-12/schema'
def emit(name,title,required,properties):
 d={'$schema':SCHEMA,'$id':f'urn:cko:contract:{name}:0.1.0','title':title,'type':'object','additionalProperties':False,'required':required,'properties':properties}
 (ROOT/'contracts'/f'{name}.schema.json').write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
str_=lambda n=1:{'type':'string','minLength':n}
hex64={'type':'string','pattern':'^[a-f0-9]{64}$'}
idtype=lambda prefix:{'type':'string','pattern':f'^{prefix}[A-Z0-9_-]+$'}
status={'type':'string','enum':['CANDIDATE_NOT_HOMOLOGATED','HOMOLOGATED','SUSPENDED','REVOKED']}
validators={'type':'array','minItems':1,'uniqueItems':True,'items':idtype('V-')}
emit('agent-identity','Identity for a unique agent or superagent',['agent_id','identity_class','operational_status','superagent','status_source'],{
 'agent_id':str_(3),'identity_class':{'enum':['SPECIALIST','SUPERAGENT','ORCHESTRATOR','DOMAIN_COORDINATOR']},'operational_status':{'enum':['CANDIDATE','ACTIVE','SUSPENDED','REVOKED']},'status_source':str_(1),'superagent':{'type':'boolean'},'owner_activities':{'type':'array','uniqueItems':True,'items':str_(3)},'source_ref':str_(1),'source_sha':hex64})
emit('task-definition','Deterministic prequalified task contract',['task_id','version','owner_agent_id','state','independently_homologated','action','target_prefix','validator_ids'],{
 'task_id':str_(3),'version':str_(1),'owner_agent_id':str_(3),'state':status,'independently_homologated':{'type':'boolean'},'action':str_(3),'target_prefix':str_(3),'validator_ids':validators,'qualification_evidence_ids':{'type':'array','items':str_(3)}})
emit('wo-request','Unpersisted request, not an authorization',['request_id','requester_id','executor_agent_id','task_id','task_version','action','target','payload_sha256','expires_at','source_id','source_url','license_code'],{
 'request_id':str_(4),'requester_id':str_(3),'executor_agent_id':str_(3),'task_id':str_(3),'task_version':str_(1),'action':str_(3),'target':str_(4),'payload_sha256':hex64,'expires_at':{'type':'integer'},'source_id':str_(3),'source_url':{'type':'string','format':'uri'},'license_code':str_(3)})
wo_required=['wo_id','issuer','state','request_sha256','requested_by','executor_agent_id','task_id','task_version','action','target','payload_sha256','source_id','source_url','license_code','policy_sha256','task_sha256','validators_catalog_sha256','approval_id','approved_by','issued_at','expires_at','nonce','audience','required_validators','signature']
wo_fields={x:str_() for x in wo_required}
for x in ('request_sha256','payload_sha256','policy_sha256','task_sha256','validators_catalog_sha256','approval_id','signature'):wo_fields[x]=hex64
for x in ('issued_at','expires_at'):wo_fields[x]={'type':'integer'}
wo_fields['required_validators']=validators;wo_fields['issuer']={'const':'CKO-KERNEL-ONLY'};wo_fields['state']={'const':'AUTHORIZED'};wo_fields['audience']={'const':'CKO-KERNEL-ARTIFACT-WRITER'}
emit('work-order-authorized','Signed, scope-bound single-use WO',wo_required,wo_fields)
validation_item={'type':'object','additionalProperties':False,'required':['validator_id','status','policy_id','reason_code'],'properties':{'validator_id':str_(3),'status':{'enum':['PASS','FAIL','HOLD','SKIPPED']},'policy_id':str_(3),'reason_code':str_(2)}}
run_req=['run_id','wo_id','agent_id','timestamp','result','policy_id','policy_sha256','validators','output_sha256','find_id','non_promotable','signature']
emit('signed-run-evidence','Kernel-authenticated validation verdict',run_req,{'run_id':str_(),'wo_id':str_(),'agent_id':str_(),'timestamp':str_(),'result':{'enum':['PASS','DENIED','FAIL','HOLD']},'policy_id':str_(),'policy_sha256':hex64,'validators':{'type':'array','minItems':1,'items':validation_item},'output_sha256':{'oneOf':[hex64,{'type':'null'}]},'find_id':{'oneOf':[str_(),{'type':'null'}]},'non_promotable':{'const':True},'signature':hex64})
find_req=['find_id','status','severity','policy_id','validator_id','reason_code','resource','observations','retest_status','closure_status']
obs={'type':'object','additionalProperties':False,'required':['at','actor','wo_id','reason'],'properties':{'at':str_(),'actor':str_(),'wo_id':str_(),'reason':str_()}}
emit('policy-find','Policy-denial FIND record with cycle metadata',find_req,{
 'find_id':str_(),'status':{'enum':['OPEN','RETEST_PENDING','CLOSURE_CANDIDATE','CLOSED']},'severity':{'enum':['CRITICAL','HIGH','MEDIUM','LOW']},'policy_id':str_(),'validator_id':str_(),'reason_code':str_(),'resource':str_(),'observations':{'type':'array','minItems':1,'items':obs},'retest_status':str_(),'closure_status':str_()})
emit('audit-event','Signed hash-chain audit event',['event_id','time','kind','wo_id','actor','detail','decision','prev_hash','policy_id','event_hash','signature'],{
 'event_id':str_(),'time':str_(),'kind':str_(),'wo_id':str_(),'actor':str_(),'detail':str_(),'decision':str_(),'prev_hash':hex64,'policy_id':str_(),'event_hash':hex64,'signature':hex64})
print('schemas generated:',len(list((ROOT/'contracts').glob('*.schema.json'))))
