# FIND candidatos — revisão em somente leitura

**Fonte:** branch `cursor/fix-governance-gaps-ec54`, registro observado em 2026-10-15. FINDs de auditoria, **não inseridos** no FIND Registry remoto.

| ID | Severidade | Evidência no repositório | Não conformidade |
|---|---|---|---|
| AG-KER-001 | CRITICAL | `packages/cli/pep.py` | `authorized_by` é apenas texto, sem identidade autenticada nem aprovação vinculada a WO |
| AG-KER-002 | CRITICAL | `packages/cli/registry.py` | `add` e `set_status` escrevem fora da porta do Kernel e sem WO |
| AG-KER-003 | CRITICAL | `supabase/functions/cko-deepseek-gateway/index.ts` | Gateway aceita `model`, `messages` e temperatura sem validar WO assinada por Kernel |
| AG-KER-004 | HIGH | `agents/registry.json` | 110 IDs sem contrato operacional universal de exclusividade por atividade; 108 candidatos |
| AG-KER-005 | HIGH | `data/grc/agentes.json` | Superagents/orquestradores são candidatos, sem delegação autenticada e permissões negadas no runtime |
| AG-KER-006 | HIGH | `policies/definicoes_tarefa.json` | 9 qualificações declaradas, sem dossiê de homologação obrigatoriamente verificado; 6 ainda não qualificadas |
| AG-KER-007 | CRITICAL | `packages/cli/kernel.py` + `data/finds/registro.json` | Bloqueios produzem exit 2 nos casos testados, mas não há evento FIND automaticamente ligado a toda falha operacional |
| AG-KER-008 | HIGH | `packages/cli/finds.py` | Fechamento de FIND sem cadeia obrigatória comprovada de correção, reteste independente e aprovação segura |
| AG-KER-009 | HIGH | `.github/workflows/gate.yml` | CI não comprova a impossibilidade de escrita fora do Kernel em todos os providers e perfis |
| AG-KER-010 | CRITICAL | `contracts/work_order.schema.json` + `packages/cli/pep.py` | Duas famílias de WO sem contrato unificado de assinatura/autorização, nem emissor exclusivo verificado |
| AG-KER-011 | HIGH | `packages/cli/llm_runner.py` | Runner local restringe modelo, mas gateway não exige token com política, tarefa, prompt e request digest específicos |
| AG-KER-012 | HIGH | `packages/cli/registry.py` | Histórico local mutável e evidência textual não constituem event ledger assinado/imutável |

**Proposta:** abrir FINDs canônicos apenas após autorizar uma Task Definition própria de registro de FINDs, com vínculo à evidência original; violações sem WO são registradas somente pela capacidade interna de auditoria do Kernel, pré-provisionada e não delegável. Nenhuma limpeza/migração/deploy foi executada.
