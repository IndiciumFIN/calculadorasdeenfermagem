"""CKO Kernel access-control reference (isolated offline demonstration).

SECURITY BOUNDARY: this is a code-level PEP, not a substitute for externally
isolated credentials, Supabase RLS, immutable persistence, IAM and KMS.
All root/identity/approval keys must come from dedicated services in production.
No real repository, file, network or external service is written by this module.
"""
from __future__ import annotations
import copy, hashlib, hmac, json, re, secrets, uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import PurePosixPath
from typing import Any

POLICY_ID = "POL-CKO-ZERO-WRITE-WITHOUT-WO-001"
SYSTEM_WO = "WO-SYSTEM-AUDIT-ROOT-001"
HEX64 = re.compile(r"^[0-9a-f]{64}$")


def canonical(data: Any) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def digest(data: Any) -> str:
    return hashlib.sha256(data if isinstance(data, bytes) else canonical(data)).hexdigest()


def mac(key: bytes, data: Any) -> str:
    return hmac.new(key, canonical(data), hashlib.sha256).hexdigest()


def check_mac(key: bytes, signed: dict) -> bool:
    if not isinstance(signed, dict):
        return False
    sig = signed.get("signature")
    if not isinstance(sig, str) or not HEX64.fullmatch(sig):
        return False
    body = {k: v for k, v in signed.items() if k != "signature"}
    return hmac.compare_digest(mac(key, body), sig)


def stamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def now_unix() -> int:
    return int(datetime.now(timezone.utc).timestamp())


def sign(key: bytes, payload: dict) -> dict:
    if "signature" in payload:
        raise ValueError("Cannot sign an already signed object")
    return {**copy.deepcopy(payload), "signature": mac(key, payload)}


class GuardDenied(Exception):
    def __init__(self, code: str, manifest: dict, find_id: str):
        super().__init__(code)
        self.code, self.manifest, self.find_id = code, manifest, find_id


class IdentityAuthority:
    """Demo external identity issuer; credentials are HMAC-bound to a context.

    Do NOT bundle this signing authority with the real Kernel runtime. Replace
    with OIDC verification or workload identity under independently protected keys.
    """
    def __init__(self, key: bytes):
        self.__key = key

    def issue(self, agent_id: str, audience: str, binding: str, ttl_s: int = 60) -> dict:
        return sign(self.__key, {"agent_id": agent_id, "audience": audience,
                                 "binding": binding, "exp": now_unix() + ttl_s,
                                 "token_id": str(uuid.uuid4())})

    def verify(self, token: dict, audience: str, binding: str) -> str | None:
        if not check_mac(self.__key, token):
            return None
        if token.get("audience") != audience or token.get("binding") != binding:
            return None
        if type(token.get("exp")) is not int or token["exp"] <= now_unix():
            return None
        return token.get("agent_id") if isinstance(token.get("agent_id"), str) else None


class AuditRootAuthority:
    """An independently provisioned, narrow system WO signer (demo only)."""
    def __init__(self, key: bytes):
        self.__key = key

    def provision(self) -> dict:
        return sign(self.__key, {"wo_id": SYSTEM_WO,
                                 "issuer": "OPERATIONS_ROOT_OFFLINE",
                                 "scope": "DENIAL_FIND_SECURITY_AUDIT_ONLY",
                                 "can_write_user_content": False})

    def verify(self, root: dict) -> bool:
        return bool(check_mac(self.__key, root)
                    and root.get("wo_id") == SYSTEM_WO
                    and root.get("issuer") == "OPERATIONS_ROOT_OFFLINE"
                    and root.get("scope") == "DENIAL_FIND_SECURITY_AUDIT_ONLY"
                    and root.get("can_write_user_content") is False)


class HumanApprovalAuthority:
    """Demo human approval issuer; distinct from identity and Kernel signer."""
    def __init__(self, key: bytes, authorized_reviewers: set[str]):
        self.__key, self._reviewers = key, set(authorized_reviewers)

    def issue(self, request: dict, reviewer_id: str, ttl_s: int = 60) -> dict:
        if reviewer_id not in self._reviewers:
            raise PermissionError("Reviewer is not authorized")
        return sign(self.__key, {"request_digest": digest(request),
                                 "reviewer_id": reviewer_id,
                                 "exp": now_unix() + ttl_s,
                                 "decision": "APPROVED"})

    def verify(self, signed_approval: dict, request: dict) -> bool:
        return bool(check_mac(self.__key, signed_approval)
                    and signed_approval.get("reviewer_id") in self._reviewers
                    and signed_approval.get("decision") == "APPROVED"
                    and signed_approval.get("request_digest") == digest(request)
                    and type(signed_approval.get("exp")) is int
                    and signed_approval["exp"] > now_unix())


@dataclass(frozen=True)
class Validation:
    validator_id: str
    status: str
    policy_id: str
    reason_code: str = "OK"

    def serialize(self) -> dict:
        return {"validator_id": self.validator_id, "status": self.status,
                "policy_id": self.policy_id, "reason_code": self.reason_code}


class Kernel:
    """In-memory simulation with no external side effects.

    Protected internals are illustrative. Production MUST put Kernel and write
    authority behind a distinct service identity and transactional DB ACL.
    Agents cannot be allowed to import this class in production as a writer.
    """
    def __init__(self, *, key: bytes, identity: IdentityAuthority,
                 approval: HumanApprovalAuthority, agents: dict, tasks: dict,
                 policy: dict, audit_root: dict, root_authority: AuditRootAuthority,
                 validator_registry: dict | None = None):
        if len(key) < 32:
            raise ValueError("Kernel key must have at least 256 bits")
        if not policy.get("rules", {}).get("any_artifact_creation_requires_wo"):
            raise ValueError("Refuse weak policy")
        self.__key, self.identity, self.approval = key, identity, approval
        self.agents = copy.deepcopy(agents)
        self.tasks = copy.deepcopy(tasks)
        self.policy = copy.deepcopy(policy)
        self.policy_digest = digest(policy)
        self.validator_registry = copy.deepcopy(validator_registry or {})
        self.validator_registry_digest = digest(self.validator_registry)
        self.issued: dict[str, dict] = {}
        self.consumed: set[str] = set()
        self.approved_requests: set[str] = set()
        self.artifacts: dict[str, dict] = {}
        self.events: list[dict] = []
        self.finds: dict[str, dict] = {}
        self.find_proofs: dict[str, list[dict]] = {}
        self.runs: list[dict] = []
        self._audit_root_verified = (policy.get("emergency_audit_wo", {}).get("id") == SYSTEM_WO
                                     and root_authority.verify(audit_root))
        if not self._audit_root_verified:
            raise ValueError("Missing preprovisioned system-audit authority")

    def _event(self, *, kind: str, wo_id: str, actor: str, detail: str, decision: str) -> dict:
        prev = self.events[-1]["event_hash"] if self.events else "0" * 64
        item = {"event_id": str(uuid.uuid4()), "time": stamp(), "kind": kind,
                "wo_id": wo_id, "actor": actor, "detail": detail,
                "decision": decision, "prev_hash": prev, "policy_id": POLICY_ID}
        item["event_hash"] = digest(item)
        item["signature"] = mac(self.__key, {k: v for k, v in item.items() if k != "signature"})
        self.events.append(item)
        return item

    def verify_events(self) -> bool:
        prev = "0" * 64
        for event in self.events:
            body = {k: v for k, v in event.items() if k not in ("event_hash", "signature")}
            if event.get("prev_hash") != prev or digest(body) != event.get("event_hash"):
                return False
            if not check_mac(self.__key, event):
                return False
            prev = event["event_hash"]
        return True

    def _find(self, *, wo_id: str | None, actor: str, code: str,
              validator_id: str, resource: str) -> str:
        # Dedup by substantive violation and target, not by random occurrence ID.
        fid = "FIND-" + digest([POLICY_ID, code, resource])[:20].upper()
        f = self.finds.get(fid)
        if f is None:
            f = {"find_id": fid, "status": "OPEN", "severity": "CRITICAL",
                 "policy_id": POLICY_ID, "validator_id": validator_id,
                 "reason_code": code, "resource": resource,
                 "observations": [], "retest_status": "NOT_PERFORMED",
                 "closure_status": "NOT_ALLOWED"}
            self.finds[fid] = f
        f["observations"].append({"at": stamp(), "actor": actor,
                                  "wo_id": wo_id or SYSTEM_WO,
                                  "reason": code})
        snapshot = sign(self.__key, {"find_id": fid, "state_sha256": digest(f)})
        self.find_proofs.setdefault(fid, []).append(snapshot)
        self._event(kind="FIND_RECORDED",wo_id=wo_id or SYSTEM_WO,actor="CKO-KERNEL-ONLY",
                    detail=f"{fid}:{snapshot['state_sha256']}",decision="HOLD")
        return fid

    def verify_finds(self) -> bool:
        return all(self.find_proofs.get(fid)
                   and check_mac(self.__key, self.find_proofs[fid][-1])
                   and self.find_proofs[fid][-1]["state_sha256"]==digest(f)
                   for fid,f in self.finds.items())

    def _evidence(self, *, status: str, wo_id: str, agent_id: str,
                  results: list[Validation], output_sha: str | None,
                  find_id: str | None) -> dict:
        # Every run/denial receives signed proof, including negative validation.
        body = {"run_id": "RUN-" + str(uuid.uuid4()), "wo_id": wo_id,
                "agent_id": agent_id, "timestamp": stamp(), "result": status,
                "policy_id": POLICY_ID, "policy_sha256": self.policy_digest,
                "validators": [x.serialize() for x in results], "output_sha256": output_sha,
                "find_id": find_id, "non_promotable": True}
        result = sign(self.__key, body)
        self.runs.append(result)
        return result

    def verify_manifest(self, m: dict) -> bool:
        return check_mac(self.__key, m)

    def _deny(self, code: str, *, wo_id: str | None = None, actor: str = "UNVERIFIED",
              resource: str = "UNKNOWN", validator_id: str = "V-AUTH-WO",
              prior_results: list[Validation] | None = None):
        find_id = self._find(wo_id=wo_id, actor=actor, code=code,
                             validator_id=validator_id, resource=resource)
        self._event(kind="POLICY_DENIAL", wo_id=wo_id or SYSTEM_WO, actor=actor,
                    detail=f"{validator_id}:{code}:{find_id}", decision="DENY")
        observed=(prior_results or [])+[Validation(validator_id,"FAIL",POLICY_ID,code)]
        # Demonstrate coverage honestly: unexecuted gates are SKIPPED, never PASS.
        registered=self.issued.get(wo_id or "",{}).get("required_validators",[])
        seen={v.validator_id for v in observed}
        observed += [Validation(vid,"SKIPPED",POLICY_ID,"NOT_EXECUTED_AFTER_DENIAL")
                     for vid in registered if vid not in seen]
        outcome = self._evidence(status="DENIED", wo_id=wo_id or SYSTEM_WO,
                                 agent_id=actor, results=observed,
                                 output_sha=None, find_id=find_id)
        raise GuardDenied(code, outcome, find_id)

    def authorize(self, request: dict, requester_credential: dict,
                  human_approval: dict) -> dict:
        """Only the Kernel mints a WO. Agents may send ephemeral *requests*.

        Requires independent signed human approval and authenticated requester.
        """
        reqid = request.get("request_id") if isinstance(request,dict) else None
        requester = self.identity.verify(requester_credential, "wo-request", reqid or "")
        if not requester or not isinstance(request, dict) or request.get("requester_id") != requester:
            self._deny("REQUESTER_IDENTITY_UNVERIFIED", actor=request.get("requester_id","UNVERIFIED") if isinstance(request, dict) else "UNVERIFIED")
        requesting_agent=self.agents.get(requester)
        if not requesting_agent or requesting_agent.get("operational_status")!="ACTIVE":
            self._deny("REQUESTER_NOT_REGISTERED_OR_INACTIVE",actor=requester)
        if digest(self.policy)!=self.policy_digest:
            self._deny("POLICY_CHANGED_WITHOUT_VERSION",actor=requester)
        rid = request.get("request_id", "")
        if not isinstance(rid,str) or rid in self.approved_requests:
            self._deny("REQUEST_REPLAY",actor=requester)
        needed={"request_id","requester_id","executor_agent_id","task_id","task_version",
                "action","target","payload_sha256","expires_at","source_id","source_url","license_code"}
        if set(request) != needed:
            self._deny("REQUEST_CONTRACT_INVALID",actor=requester)
        agent=self.agents.get(request["executor_agent_id"])
        task=self.tasks.get(request["task_id"])
        if not task or not task.get("independently_homologated") or task.get("state")!="HOMOLOGATED":
            self._deny("TASK_NOT_HOMOLOGATED",actor=requester,resource=request["target"],validator_id="V-AGENT-EXCLUSIVE")
        if (not agent or agent.get("operational_status") != "ACTIVE"
            or agent.get("superagent") or task.get("owner_agent_id")!=request["executor_agent_id"]):
            self._deny("AGENT_NOT_EXCLUSIVE_OR_NOT_ACTIVE",actor=requester,resource=request["target"],validator_id="V-AGENT-EXCLUSIVE")
        if (task.get("version")!=request["task_version"]
            or task.get("action")!=request["action"]):
            self._deny("TASK_SCOPE_MISMATCH",actor=requester,resource=request["target"],validator_id="V-AUTH-WO")
        if not self._valid_path(request["target"],task["target_prefix"]):
            self._deny("RESOURCE_OUT_OF_SCOPE",actor=requester,resource=request["target"],validator_id="V-TARGET-PREFIX")
        if (not isinstance(request["payload_sha256"],str)
            or not HEX64.fullmatch(request["payload_sha256"])):
            self._deny("DIGEST_MISSING",actor=requester,resource=request["target"],validator_id="V-INPUT-DIGEST")
        if type(request.get("expires_at")) is not int or request["expires_at"] <= now_unix():
            self._deny("REQUEST_EXPIRED",actor=requester,resource=request["target"])
        if not self.approval.verify(human_approval, request):
            self._deny("HUMAN_APPROVAL_INVALID",actor=requester,resource=request["target"])
        wo_id="WO-KER-" + str(uuid.uuid4())
        body={"wo_id":wo_id,"issuer":"CKO-KERNEL-ONLY","state":"AUTHORIZED",
              "request_sha256":digest(request),"requested_by":requester,
              "executor_agent_id":request["executor_agent_id"],
              "task_id":request["task_id"],"task_version":request["task_version"],
              "action":request["action"],"target":request["target"],
              "payload_sha256":request["payload_sha256"],
              "source_id":request["source_id"],"source_url":request["source_url"],
              "license_code":request["license_code"],
              "policy_sha256":self.policy_digest,
              "task_sha256":digest(task),
              "validators_catalog_sha256":self.validator_registry_digest,
              "approval_id":digest(human_approval),"approved_by":human_approval["reviewer_id"],
              "issued_at":now_unix(),"expires_at":request["expires_at"],
              "nonce":secrets.token_hex(16),"audience":"CKO-KERNEL-ARTIFACT-WRITER",
              "required_validators":list(task["validator_ids"])}
        wo=sign(self.__key,body)
        self.issued[wo_id]=wo
        self.approved_requests.add(rid)
        self._event(kind="WO_ISSUED",wo_id=wo_id,actor="CKO-KERNEL-ONLY",detail=digest(wo),decision="AUTHORIZED")
        self._evidence(status="PASS",wo_id=wo_id,agent_id="CKO-KERNEL-ONLY",results=[
            Validation("V-REQUESTER-ID", "PASS", POLICY_ID),
            Validation("V-TASK-HOMOLOGATED", "PASS", POLICY_ID),
            Validation("V-AGENT-EXCLUSIVE", "PASS", POLICY_ID),
            Validation("V-APPROVAL-BOUND", "PASS", POLICY_ID),
            Validation("V-WO-SIGNATURE", "PASS", POLICY_ID)
        ],output_sha=digest(wo),find_id=None)
        return copy.deepcopy(wo)

    @staticmethod
    def _valid_path(target: str, prefix: str) -> bool:
        if not isinstance(target,str) or not isinstance(prefix,str) or "\\" in target:
            return False
        pure=PurePosixPath(target)
        return bool(target.startswith(prefix) and len(target)>len(prefix)
                    and not pure.is_absolute() and ".." not in pure.parts
                    and not target.startswith("/") and not target.startswith("./")
                    and "//" not in target and target.strip()==target)

    def execute(self, *, wo: dict | None, agent_credential: dict | None,
                payload: dict, target: str) -> dict:
        """Simulate a candidate creation. ALL mutations are post-validation.

        Each failed validation produces a signed negative run and a policy FIND.
        No external writes; exact target is checked again at use time.
        """
        wid=wo.get("wo_id") if isinstance(wo,dict) else None
        if not wid or wid not in self.issued or not check_mac(self.__key,wo):
            self._deny("WO_ABSENT_OR_FORGED",wo_id=wid,resource=target)
        stored=self.issued[wid]
        if canonical(stored)!=canonical(wo):
            self._deny("WO_NOT_REGISTERED_EXACTLY",wo_id=wid,resource=target)
        if wid in self.consumed:
            self._deny("WO_REPLAY",wo_id=wid,resource=target)
        # Any attempted WO consumption, including unsuccessful, invalidates nonce.
        self.consumed.add(wid)
        agent_id=self.identity.verify(agent_credential,"execute-wo",wid)
        if not agent_id or agent_id!=wo["executor_agent_id"]:
            self._deny("EXECUTOR_IDENTITY_INVALID",wo_id=wid,actor=agent_id or "UNVERIFIED",resource=target)
        if (wo["expires_at"]<=now_unix() or wo["policy_sha256"]!=self.policy_digest
            or digest(self.policy)!=self.policy_digest):
            self._deny("WO_EXPIRED_OR_POLICY_CHANGED",wo_id=wid,actor=agent_id,resource=target)
        t=self.tasks.get(wo["task_id"])
        a=self.agents.get(agent_id)
        if not t or not t.get("independently_homologated") or t.get("state")!="HOMOLOGATED":
            self._deny("TASK_NO_LONGER_QUALIFIED",wo_id=wid,actor=agent_id,resource=target)
        if digest(t)!=wo.get("task_sha256"):
            self._deny("TASK_DEFINITION_CHANGED",wo_id=wid,actor=agent_id,resource=target,validator_id="V-AGENT-EXCLUSIVE")
        if (digest(self.validator_registry)!=wo.get("validators_catalog_sha256")
            or digest(self.validator_registry)!=self.validator_registry_digest):
            self._deny("VALIDATOR_CATALOG_CHANGED",wo_id=wid,actor=agent_id,resource=target)
        if not a or a.get("operational_status")!="ACTIVE" or a.get("superagent") or t.get("owner_agent_id")!=agent_id:
            self._deny("AGENT_ROLE_CHANGED",wo_id=wid,actor=agent_id,resource=target,validator_id="V-AGENT-EXCLUSIVE")
        if target != wo["target"] or not self._valid_path(target,t["target_prefix"]):
            self._deny("TARGET_TAMPERED",wo_id=wid,actor=agent_id,resource=target,validator_id="V-TARGET-PREFIX")
        if target in self.artifacts:
            self._deny("ARTIFACT_EXISTS_NO_OVERWRITE",wo_id=wid,actor=agent_id,resource=target)
        required=set(t["validator_ids"])
        if required != set(wo["required_validators"]) or len(t["validator_ids"])!=len(wo["required_validators"]):
            self._deny("VALIDATOR_REGISTRY_DRIFT",wo_id=wid,actor=agent_id,resource=target)
        results=[]
        def gate(vid: str, okay: bool, code: str) -> None:
            if vid not in required:
                self._deny("REQUIRED_VALIDATOR_MISSING",wo_id=wid,actor=agent_id,resource=target,validator_id=vid,prior_results=results)
            results.append(Validation(vid,"PASS" if okay else "FAIL",POLICY_ID,"OK" if okay else code))
            if not okay:
                self._deny(code,wo_id=wid,actor=agent_id,resource=target,validator_id=vid,prior_results=results[:-1])
        gate("V-AUTH-WO",wo["issuer"]=="CKO-KERNEL-ONLY" and wo["audience"]=="CKO-KERNEL-ARTIFACT-WRITER","WRONG_ISSUER_OR_AUDIENCE")
        gate("V-AGENT-EXCLUSIVE",t["owner_agent_id"]==agent_id and not a["superagent"],"AGENT_NOT_EXCLUSIVE")
        gate("V-INPUT-DIGEST",digest(payload)==wo["payload_sha256"],"PAYLOAD_DIGEST_MISMATCH")
        gate("V-LICENSE",(wo["license_code"] in self.policy["license_allowlist"]
                          and payload.get("license_code")==wo["license_code"]),"LICENSE_DENIED")
        gate("V-PROVENANCE",isinstance(wo["source_id"],str) and len(wo["source_id"])>=3
             and isinstance(wo["source_url"],str) and wo["source_url"].startswith("https://")
             and payload.get("source_id")==wo["source_id"] and payload.get("source_url")==wo["source_url"],"PROVENANCE_INCOMPLETE")
        gate("V-TARGET-PREFIX",self._valid_path(target,t["target_prefix"]),"TARGET_INVALID")
        gate("V-FIND-BLOCKER",not any(f["resource"]==target and f["status"]=="OPEN" for f in self.finds.values()),"OPEN_BLOCKING_FIND")
        gate("V-OUTPUT-NONEMPTY",isinstance(payload.get("content"),str) and bool(payload["content"].strip()),"OUTPUT_EMPTY")
        if results and set(x.validator_id for x in results) != required:
            self._deny("VALIDATOR_NOT_EXECUTED",wo_id=wid,actor=agent_id,resource=target)
        # Reference simulation: actual persistence must be atomic with manifest, nonce and event.
        content=payload["content"].encode("utf-8")
        output_sha=digest(content)
        evidence=self._evidence(status="PASS",wo_id=wid,agent_id=agent_id,
                                results=results,output_sha=output_sha,find_id=None)
        self.artifacts[target]={"bytes":content,"sha256":output_sha,
                                "wo_id":wid,"run_id":evidence["run_id"],
                                "state":"CANDIDATE_NOT_HOMOLOGATED"}
        self._event(kind="CANDIDATE_CREATED",wo_id=wid,actor=agent_id,
                    detail=f"{target}:{output_sha}",decision="PASS")
        return evidence

    def verify_artifact(self, target: str) -> bool:
        obj=self.artifacts.get(target)
        return bool(obj and digest(obj["bytes"])==obj["sha256"])

    def close_find(self, find_id: str, **kwargs):
        # Closure is deliberately unimplemented until its dedicated task,
        # independent retest and human approval are homologated and enforced.
        self._deny("FIND_CLOSURE_WITHOUT_HOMOLOGATED_CONTRACT",resource=find_id,
                   validator_id="V-CLOSURE-RETEST")
