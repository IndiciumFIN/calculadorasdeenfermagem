-- CANDIDATE / REVIEW ONLY. DO NOT EXECUTE WITHOUT DBA AND SUPABASE REVIEW.
-- The Kernel must be the sole persistence identity for user artifacts/status/FINDs.
-- RLS alone is insufficient if agents have service_role or direct DB owner creds.
-- Illustrative scope; adapt verified tables/schema/ownership after inventory.
BEGIN;
-- Deny untrusted actors any insert/update/delete on governed tables.
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON TABLE public.normatives FROM PUBLIC, anon, authenticated;
-- IMPORTANT: replace names below only after actual DB metadata is inspected;
-- do not assert these tables exist or execute against production unmodified.
-- REVOKE INSERT, UPDATE, DELETE ON TABLE public.registry FROM anon, authenticated;
-- REVOKE INSERT, UPDATE, DELETE ON TABLE public.finds FROM anon, authenticated;
-- REVOKE INSERT, UPDATE, DELETE ON TABLE public.work_orders FROM anon, authenticated;
-- Kernel writer must be a dedicated role without agent-held credentials,
-- using a server-side verified WO and a SECURITY DEFINER write boundary where
-- needed, with safe search_path, explicit field/tenant/target checks and audit.
ROLLBACK;
