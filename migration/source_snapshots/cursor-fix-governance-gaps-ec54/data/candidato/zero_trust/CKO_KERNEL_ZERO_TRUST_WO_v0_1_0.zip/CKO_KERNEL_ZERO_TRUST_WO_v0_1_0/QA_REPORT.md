# Relatório QA — CKO Kernel Zero Trust v0.1.0

**Resultado de testes locais:** 43 PASS / 0 FAIL (Python `unittest` e validação de JSON Schema 2020-12 com `jsonschema` disponível na execução de QA).

## Testes negativos demonstrados

- Sem WO; WO forjada; identidade de solicitante inválida; executor incorreto; solicitação repetida.
- Aprovação humana ausente/adulterada; tarefa não homologada; superagente como executor; agente não proprietário, inativo ou revogado.
- Alvo fora do escopo, traversal, troca de alvo, ação diferente da Task Definition e solicitação expirada.
- Digest divergente, licença bloqueada, proveniência insuficiente, conteúdo vazio.
- Deriva de política, Task Definition e Validator Registry após autorização; WO de execução repetida.
- FIND aberto bloqueia nova execução sobre mesmo alvo; FIND deduplicado e não encerrável pelo agente.
- Corrupção de prova assinada, trilha de auditoria ou FIND é detectada no mecanismo de verificação do protótipo.

## Provas positivas

- WO autorizada é emitida e assinada pelo Kernel **somente após aprovação independente** simulada por chave separada.
- Emissão da WO produz manifesto de validação `PASS` assinado.
- Execução com credencial de agente, WO válida e oito validadores obrigatórios produz manifesto `PASS` assinado e artefato **apenas candidato** em memória.
- WO ausente produz manifesto `DENIED`, `V-AUTH-WO=FAIL`, FIND `OPEN` e evento sob WO raiz previamente provisionada.
- Falha intermediária registra `FAIL` e deixa verificações não executadas em `SKIPPED`, nunca em `PASS`.

## Limites de evidência e homologação

Este pacote demonstra enforcement **somente dentro de um serviço Python em memória**. Não há privilégio operacional em GitHub, Supabase, Drive, rede ou disco do site. As chaves no exemplo são fictícias e embutidas somente nos testes. Não há assinatura digital institucional, KMS, ACL aplicada, imutabilidade externa, concorrência transacional testada, proteção interprocessos, homologação de tarefa ou integração E2E.

**Não aplicar à produção nem afirmar proteção global.** Permanecem `HOLD`: fechamento de FIND com reteste independente; assinatura assimétrica institucional; autoridade humana real; policy/validator bindings de produção; exclusividade por credenciais; bloqueio do gateway/CLI/Storage/DB; proteção da main.
