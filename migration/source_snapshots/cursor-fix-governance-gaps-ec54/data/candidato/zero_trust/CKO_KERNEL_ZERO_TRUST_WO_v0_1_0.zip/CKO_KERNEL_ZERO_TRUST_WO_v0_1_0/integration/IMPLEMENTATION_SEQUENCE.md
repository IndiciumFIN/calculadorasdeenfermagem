# Plano de incorporação — sem implementar nesta entrega

## Gate A — identidade e contratos (HOLD até aprovar)
- Reconciliar 110 IDs; impedir colisão por índice UNIQUE e namespace; registrar issuer, ambiente, versão, recertificação, perfis de efeito.
- Revisar 18 novas identidades candidatas evitando duplicação de tarefas já existentes.
- Definir hierarquia supervisionada: superagent pode PROPOR; não pode MINT/APPROVE/EXECUTE por delegação tácita.
- Fixar ownership por Task Definition; uma atividade técnica atômica tem responsável técnico e validador distintos.

## Gate B — plano de controle
- Master Data/Canonical Control Plane mantém estado, contratos e decisões aprovadas.
- Kernel/PMO Control Service é único emissor/validador/persistidor de WO; PMO Agent apenas solicita.
- WO sign/verify ligado a versão e hash de tarefa, política, validators, aprovação e escopo do alvo.
- Todo `DENY` gera evento e FIND com provas; serviço raiz para auditoria é provisionado e assinado por autoridade externa.

## Gate C — fechar todas as rotas de escrita
- DB ACL/RLS + API não deixa roles agentes `INSERT/UPDATE/DELETE` nem service_role; service role do Kernel separado.
- Storage privado e write-only do Kernel, E2E testando upload/move/delete não autorizados.
- GitHub credential do agente read-only; commit/PR creation somente Kernel writer com WO.
- CLI/Work/cron/tool plugins não executam escrita direta. Agentes não devem ter credenciais diretas de infraestrutura.
- Gateway LLM e modelos locais/cloud passam por introspecção Kernel com identidade, nonce e orçamento/custo, sem chave direta.

## Gate D — validação de conclusão
- Matriz política ↔ Task Definition ↔ validador ↔ fixture ↔ resultado ↔ evento ↔ FIND.
- Logs imutáveis assinados e auditáveis, com data/hora atestada, key version, digests, autor, checker, resultado PASS/HOLD/FAIL e lineage.
- Reteste por agente/serviço independente com uma nova WO; fechamento de FIND controlado e auditável.

## Gate E — homologação
- Negativos em produção restrita: sem WO, forged WO, expired, replay, wrong agent, superagent, model direct, DB direct, storage direct, CLI direct, GitHub direct, FIND open, license blocked.
- Criar relatório por rota PEP: `REQUIRED → INSTALLED → TESTED_NEGATIVE → EVIDENCED → HUMAN_APPROVED`.
- Não declarar controle completo sem todos os negativos **e** sem prova de restrição das credenciais externas.
