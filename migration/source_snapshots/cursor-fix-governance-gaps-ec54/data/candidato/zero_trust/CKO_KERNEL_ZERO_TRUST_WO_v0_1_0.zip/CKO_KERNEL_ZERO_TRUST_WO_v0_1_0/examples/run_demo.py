"""Generate evidence from an isolated reference simulation. No real writes.
Keys are literal DEMO TEST KEYS, never use them in production.
"""
from pathlib import Path
import json
import uuid
from cko_guard import Kernel, IdentityAuthority, HumanApprovalAuthority, AuditRootAuthority, GuardDenied, digest, now_unix
BASE=Path(__file__).resolve().parents[1]
def load(p):return json.loads((BASE/p).read_text(encoding='utf-8'))
p=load('policies/zero_trust_wo.json')
agents={a['agent_id']:a for a in load('registries/agent_identity_inventory.json')['agents']}
tasks=load('registries/task_definition_registry.json')['tasks']
# Intentionally temporary, test-only qualification. The on-disk catalog remains HOLD.
agent_id='AGT-EXTRATOR-001';superagent_id='AGT-ORCH-001';task_id='TD-REG-CAPTURE-001'
agents[agent_id]['operational_status']='ACTIVE'
agents[superagent_id]['operational_status']='ACTIVE'
tasks[task_id]['state']='HOMOLOGATED';tasks[task_id]['independently_homologated']=True
identity=IdentityAuthority(b'I'*32)
approval=HumanApprovalAuthority(b'A'*32,{'HUMAN-CKO-APPROVER-001'})
audit=AuditRootAuthority(b'R'*32)
k=Kernel(key=b'K'*32,identity=identity,approval=approval,agents=agents,tasks=tasks,policy=p,
         audit_root=audit.provision(),root_authority=audit)
resource='regulatory/candidates/demo.json'
payload={'content':'Candidato de exemplo — sem homologação clínica/jurídica',
         'source_id':'SRC-DEMO-001','source_url':'https://example.org/public',
         'license_code':'PUBLIC_FREE_NO_REGISTRATION_PERMITTED'}
find=None;failure=None
try:
 k.execute(wo=None,agent_credential=None,payload=payload,target='regulatory/candidates/denied.json')
except GuardDenied as exc:failure=exc.manifest;find=k.finds[exc.find_id]
req={'request_id':'REQ-'+str(uuid.uuid4()),'requester_id':superagent_id,'executor_agent_id':agent_id,
     'task_id':task_id,'task_version':'0.1.0','action':'CREATE_CANDIDATE','target':resource,
     'payload_sha256':digest(payload),'source_id':payload['source_id'],'source_url':payload['source_url'],
     'license_code':payload['license_code'],'expires_at':now_unix()+150}
credential=identity.issue(superagent_id,'wo-request',req['request_id'])
human=approval.issue(req,'HUMAN-CKO-APPROVER-001')
wo=k.authorize(req,credential,human)
run=k.execute(wo=wo,agent_credential=identity.issue(agent_id,'execute-wo',wo['wo_id']),
              payload=payload,target=resource)
result={'status':'TEST_ONLY_NO_EXTERNAL_WRITES','notice':'All signatures use public demo test secrets; not operational authentication',
        'proposed_work_order_request':req,'kernel_signed_wo':wo,
        'signed_wo_issuance_evidence':k.runs[1],
        'signed_denial_manifest':failure,'auto_created_find':find,
        'signed_success_manifest':run,'signed_audit_events':k.events,
        'signatures_verifiable':k.verify_manifest(failure) and k.verify_manifest(run) and k.verify_events() and k.verify_finds(),
        'artifact_state':k.artifacts[resource]['state'],'target_created_without_wo':False}
(BASE/'examples'/'demo_evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('DEMO PASS — denied request logged and FIND created; authorized WO signed; candidate generated; audit verifiable')
