"""Negative tests for a NON-DEPLOYED Kernel PEP reference simulation."""
import copy
import json
import unittest
import uuid
from pathlib import Path

from cko_guard import (Kernel, IdentityAuthority, HumanApprovalAuthority,
                       AuditRootAuthority, GuardDenied, digest, now_unix)

ROOT=Path(__file__).resolve().parents[1]
def load(p):return json.loads((ROOT/p).read_text(encoding="utf8"))
BASE_POLICY=load("policies/zero_trust_wo.json")
BASE_AGENTS=load("registries/agent_identity_inventory.json")["agents"]
BASE_TASKS=load("registries/task_definition_registry.json")["tasks"]
BASE_ROLES=load("registries/role_exclusivity.json")

class ZeroTrustTests(unittest.TestCase):
    def setUp(self):
        self.identity=IdentityAuthority(b"I"*32)
        self.approval=HumanApprovalAuthority(b"A"*32,{"HUMAN-CKO-APPROVER-001"})
        self.root=AuditRootAuthority(b"R"*32)
        agents={a["agent_id"]:copy.deepcopy(a) for a in BASE_AGENTS}
        self.executor="AGT-EXTRATOR-001"
        self.requester="AGT-ORCH-001"
        # Test-only simulated approvals: do NOT modify the package registries.
        agents[self.executor]["operational_status"]="ACTIVE"
        agents[self.requester]["operational_status"]="ACTIVE"
        tasks=copy.deepcopy(BASE_TASKS)
        self.task="TD-REG-CAPTURE-001"
        tasks[self.task]["state"]="HOMOLOGATED"
        tasks[self.task]["independently_homologated"]=True
        self.kernel=Kernel(key=b"K"*32,identity=self.identity,approval=self.approval,
                           agents=agents,tasks=tasks,policy=BASE_POLICY,
                           audit_root=self.root.provision(),root_authority=self.root)
        self.target="regulatory/candidates/demo-"+str(uuid.uuid4())+".json"
        self.payload={"content":"Normative source candidate — not an approved requirement",
                      "license_code":"PUBLIC_FREE_NO_REGISTRATION_PERMITTED",
                      "source_id":"SRC-001","source_url":"https://example.org/official"}

    def request(self, **overrides):
        q={"request_id":"REQ-"+str(uuid.uuid4()),"requester_id":self.requester,
           "executor_agent_id":self.executor,"task_id":self.task,"task_version":"0.1.0",
           "action":"CREATE_CANDIDATE","target":self.target,
           "payload_sha256":digest(self.payload),"expires_at":now_unix()+150,
           "source_id":self.payload["source_id"],"source_url":self.payload["source_url"],
           "license_code":self.payload["license_code"]}
        q.update(overrides)
        return q

    def issue(self, request=None, approval=None, requester_credential=None):
        q=request or self.request()
        cred=requester_credential or self.identity.issue(self.requester,"wo-request",q["request_id"])
        appr=approval or self.approval.issue(q,"HUMAN-CKO-APPROVER-001")
        return self.kernel.authorize(q,cred,appr)

    def execute(self, wo, *, credential=None, payload=None, target=None):
        cred=credential if credential is not None else self.identity.issue(self.executor,"execute-wo",wo["wo_id"])
        return self.kernel.execute(wo=wo,agent_credential=cred,
                                   payload=payload if payload is not None else self.payload,
                                   target=target if target is not None else self.target)

    def assertDenied(self, expected, func):
        with self.assertRaises(GuardDenied) as ec:
            func()
        exc=ec.exception
        self.assertEqual(exc.code,expected)
        self.assertTrue(self.kernel.verify_manifest(exc.manifest))
        self.assertEqual(exc.manifest["result"],"DENIED")
        self.assertEqual(exc.manifest["find_id"],exc.find_id)
        self.assertEqual(self.kernel.finds[exc.find_id]["policy_id"],BASE_POLICY["policy_id"])
        self.assertEqual(self.kernel.finds[exc.find_id]["status"],"OPEN")
        self.assertTrue(self.kernel.verify_events())
        self.assertTrue(self.kernel.verify_finds())
        self.assertEqual(len(self.kernel.artifacts),0)
        return exc

    def test_inventory_has_unique_identifiers_and_only_candidates_new(self):
        ids=[a["agent_id"] for a in BASE_AGENTS]
        self.assertEqual(len(ids),128)
        self.assertEqual(len(set(ids)),128)
        self.assertEqual(sum(a["status_source"]!="NOT_PRESENT_IN_REPO_CANDIDATE" for a in BASE_AGENTS),110)
        self.assertEqual(sum(a["superagent"] for a in BASE_AGENTS),20)
        self.assertEqual(len(BASE_ROLES["exclusive_task_owner"]),10)

    def test_production_candidacy_is_unqualified_by_default(self):
        self.assertTrue(all(not x["independently_homologated"] for x in BASE_TASKS.values()))
        self.assertTrue(all(a.get("target_state")=="HOLD_RECONCILE" for a in BASE_AGENTS))

    def test_reject_unsigned_system_wo_root(self):
        with self.assertRaises(ValueError):
            Kernel(key=b"K"*32,identity=self.identity,approval=self.approval,
                   agents={},tasks={},policy=BASE_POLICY,audit_root={"wo_id":"WO-SYSTEM-AUDIT-ROOT-001"},root_authority=self.root)

    def test_fail_without_wo_auto_find_and_signed_audit(self):
        self.assertDenied("WO_ABSENT_OR_FORGED",lambda:self.kernel.execute(
            wo=None,agent_credential=None,payload=self.payload,target=self.target))
        self.assertEqual(self.kernel.events[0]["wo_id"],"WO-SYSTEM-AUDIT-ROOT-001")

    def test_fail_fake_wo(self):
        self.assertDenied("WO_ABSENT_OR_FORGED",lambda:self.kernel.execute(
            wo={"wo_id":"WO-KER-not-authorized"},agent_credential=None,payload=self.payload,target=self.target))

    def test_requester_identity_is_bound_to_request(self):
        q=self.request()
        wrong=self.identity.issue("AGT-SOMEONE-ELSE","wo-request",q["request_id"])
        self.assertDenied("REQUESTER_IDENTITY_UNVERIFIED",lambda:self.issue(q,requester_credential=wrong))

    def test_reject_unsigned_human_approval(self):
        q=self.request()
        self.assertDenied("HUMAN_APPROVAL_INVALID",lambda:self.issue(q,approval={"decision":"APPROVED"}))

    def test_reject_tampered_human_approval(self):
        q=self.request()
        approval=self.approval.issue(q,"HUMAN-CKO-APPROVER-001")
        approval["decision"]="DENIED"
        self.assertDenied("HUMAN_APPROVAL_INVALID",lambda:self.issue(q,approval=approval))

    def test_reject_unhomologated_task(self):
        self.kernel.tasks[self.task]["independently_homologated"]=False
        self.assertDenied("TASK_NOT_HOMOLOGATED",lambda:self.issue())

    def test_superagent_cannot_execute_even_if_named_owner(self):
        self.kernel.tasks[self.task]["owner_agent_id"]=self.requester
        q=self.request(executor_agent_id=self.requester)
        self.assertDenied("AGENT_NOT_EXCLUSIVE_OR_NOT_ACTIVE",lambda:self.issue(q))

    def test_reject_nonowner_agent(self):
        q=self.request(executor_agent_id=self.requester)
        self.assertDenied("AGENT_NOT_EXCLUSIVE_OR_NOT_ACTIVE",lambda:self.issue(q))

    def test_reject_wrong_task_action(self):
        q=self.request(action="PUBLISH")
        self.assertDenied("TASK_SCOPE_MISMATCH",lambda:self.issue(q))

    def test_reject_path_escape(self):
        q=self.request(target="regulatory/candidates/../../secret.json")
        self.assertDenied("RESOURCE_OUT_OF_SCOPE",lambda:self.issue(q))

    def test_reject_external_target(self):
        q=self.request(target="regulatory/releases/published.json")
        self.assertDenied("RESOURCE_OUT_OF_SCOPE",lambda:self.issue(q))

    def test_reject_expired_request(self):
        q=self.request(expires_at=now_unix()-1)
        self.assertDenied("REQUEST_EXPIRED",lambda:self.issue(q))

    def test_reject_duplicate_request(self):
        q=self.request();self.issue(q)
        self.assertDenied("REQUEST_REPLAY",lambda:self.issue(q))

    def test_reject_bad_wo_mac(self):
        w=self.issue();w["target"]="regulatory/candidates/tampered.json"
        self.assertDenied("WO_ABSENT_OR_FORGED",lambda:self.execute(w))

    def test_reject_validator_catalog_tampering(self):
        w=self.issue()
        self.kernel.validator_registry["V-INPUT-DIGEST"]="unapproved change"
        self.assertDenied("VALIDATOR_CATALOG_CHANGED",lambda:self.execute(w))

    def test_reject_wrong_executor_identity(self):
        w=self.issue()
        bad=self.identity.issue(self.requester,"execute-wo",w["wo_id"])
        self.assertDenied("EXECUTOR_IDENTITY_INVALID",lambda:self.execute(w,credential=bad))

    def test_reject_payload_digest_mismatch(self):
        w=self.issue()
        changed={**self.payload,"content":"injected output"}
        exc=self.assertDenied("PAYLOAD_DIGEST_MISMATCH",lambda:self.execute(w,payload=changed))
        ids=[x["validator_id"] for x in exc.manifest["validators"]]
        self.assertIn("V-INPUT-DIGEST",ids)
        self.assertEqual([v["status"] for v in exc.manifest["validators"] if v["validator_id"]=="V-INPUT-DIGEST"],["FAIL"])
        self.assertIn("SKIPPED",[v["status"] for v in exc.manifest["validators"]])

    def test_reject_license_blocked(self):
        self.payload["license_code"]="LICENSE_BLOCKED"
        w=self.issue()
        self.assertDenied("LICENSE_DENIED",lambda:self.execute(w))

    def test_reject_no_provenance(self):
        self.payload["source_url"]="not-an-official-url"
        w=self.issue()
        self.assertDenied("PROVENANCE_INCOMPLETE",lambda:self.execute(w))

    def test_reject_empty_output(self):
        self.payload["content"]="  "
        w=self.issue()
        self.assertDenied("OUTPUT_EMPTY",lambda:self.execute(w))

    def test_reject_changed_target_after_issuance(self):
        w=self.issue()
        self.assertDenied("TARGET_TAMPERED",lambda:self.execute(w,target="regulatory/candidates/other.json"))

    def test_reject_policy_drift(self):
        w=self.issue()
        self.kernel.policy_digest="f"*64
        self.assertDenied("WO_EXPIRED_OR_POLICY_CHANGED",lambda:self.execute(w))

    def test_reject_changed_task_definition_after_issue(self):
        w=self.issue()
        self.kernel.tasks[self.task]["action"]="ALTER"
        self.assertDenied("TASK_DEFINITION_CHANGED",lambda:self.execute(w))

    def test_reject_policy_content_tampered_without_digest(self):
        w=self.issue()
        self.kernel.policy["license_allowlist"].append("LICENSE_BLOCKED")
        self.assertDenied("WO_EXPIRED_OR_POLICY_CHANGED",lambda:self.execute(w))

    def test_reject_unregistered_requester(self):
        self.kernel.agents[self.requester]["operational_status"]="REVOKED"
        self.assertDenied("REQUESTER_NOT_REGISTERED_OR_INACTIVE",lambda:self.issue())

    def test_reject_revoked_agent(self):
        w=self.issue()
        self.kernel.agents[self.executor]["operational_status"]="REVOKED"
        self.assertDenied("AGENT_ROLE_CHANGED",lambda:self.execute(w))

    def test_reject_validator_registry_drift(self):
        w=self.issue()
        self.kernel.tasks[self.task]["validator_ids"].pop()
        self.assertDenied("TASK_DEFINITION_CHANGED",lambda:self.execute(w))

    def test_success_has_all_passes_signed_evidence_and_unpromoted_artifact(self):
        w=self.issue(); m=self.execute(w)
        self.assertTrue(self.kernel.verify_manifest(m))
        self.assertEqual(m["result"],"PASS")
        self.assertEqual(len(m["validators"]),8)
        self.assertTrue(all(v["status"]=="PASS" for v in m["validators"]))
        self.assertTrue(self.kernel.verify_artifact(self.target))
        self.assertTrue(self.kernel.verify_events())
        self.assertEqual(self.kernel.artifacts[self.target]["state"],"CANDIDATE_NOT_HOMOLOGATED")
        self.assertTrue(m["non_promotable"])

    def test_wo_cannot_be_replayed(self):
        w=self.issue();self.execute(w)
        with self.assertRaises(GuardDenied) as ec:
            self.execute(w)
        self.assertEqual(ec.exception.code,"WO_REPLAY")
        self.assertEqual(len(self.kernel.artifacts),1)
        self.assertTrue(self.kernel.verify_events())

    def test_find_dedup_and_block_on_same_target(self):
        self.payload["license_code"]="LICENSE_BLOCKED"
        w1=self.issue()
        f1=self.assertDenied("LICENSE_DENIED",lambda:self.execute(w1)).find_id
        w2=self.issue()
        f2=self.assertDenied("LICENSE_DENIED",lambda:self.execute(w2)).find_id
        self.assertEqual(f1,f2)
        self.assertEqual(len(self.kernel.finds[f1]["observations"]),2)
        self.assertTrue(self.kernel.verify_finds())

    def test_critical_find_prevents_next_wo_creation(self):
        # A valid payload for the same target cannot silently overcome an open FIND.
        self.payload["license_code"]="LICENSE_BLOCKED"
        w1=self.issue()
        self.assertDenied("LICENSE_DENIED",lambda:self.execute(w1))
        self.payload["license_code"]="PUBLIC_FREE_NO_REGISTRATION_PERMITTED"
        w2=self.issue()
        self.assertDenied("OPEN_BLOCKING_FIND",lambda:self.execute(w2))

    def test_no_agent_can_close_find_directly(self):
        exc=self.assertDenied("WO_ABSENT_OR_FORGED",lambda:self.kernel.execute(
            wo=None,agent_credential=None,payload=self.payload,target=self.target))
        with self.assertRaises(GuardDenied) as ec:
            self.kernel.close_find(exc.find_id)
        self.assertEqual(ec.exception.code,"FIND_CLOSURE_WITHOUT_HOMOLOGATED_CONTRACT")
        self.assertEqual(self.kernel.finds[exc.find_id]["status"],"OPEN")

    def test_detect_tampered_evidence(self):
        w=self.issue();m=self.execute(w)
        m["result"]="DENIED"
        self.assertFalse(self.kernel.verify_manifest(m))

    def test_detect_tampered_audit_log(self):
        w=self.issue();self.execute(w)
        self.kernel.events[0]["detail"]="edited"
        self.assertFalse(self.kernel.verify_events())

    def test_detect_tampered_find_snapshot(self):
        self.assertDenied("WO_ABSENT_OR_FORGED",lambda:self.kernel.execute(
            wo=None,agent_credential=None,payload=self.payload,target=self.target))
        fid=next(iter(self.kernel.finds))
        self.kernel.finds[fid]["status"]="CLOSED"
        self.assertFalse(self.kernel.verify_finds())

if __name__=="__main__":unittest.main()
