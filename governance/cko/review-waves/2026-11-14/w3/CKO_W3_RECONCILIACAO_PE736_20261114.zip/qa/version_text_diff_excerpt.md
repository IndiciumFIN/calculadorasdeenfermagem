# Alterações textuais — revisão humana exigida

Comparação de parágrafos/itens visíveis; não representa diff de HTML estrutural. Primeiras 160 linhas:

```diff
--- older copy 37357 bytes
+++ annotated copy 49533 bytes
@@ -111,9 +111,28 @@
 utilizar escala ou protocolo desatualizado;
 manter campos obrigatórios que não alteram cuidado e não geram informação útil.
-A fonte normativa primária deste conteúdo é a publicação da Resolução Cofen nº 736/2024 no Diário Oficial da União. O texto disponibilizado pelo Cofen é utilizado como visão oficial auxiliar para leitura e estruturação editorial.
-A página deve ser revisada quando houver alteração, revogação ou nova resolução que modifique materialmente o Processo de Enfermagem.
-PRIMARY DOU — Resolução Cofen nº 736/2024 — publicação no DOU
-OFFICIAL AUXILIARY — Cofen — Resolução Cofen nº 736/2024
-OFFICIAL CONTEXT — Cofen — atualização do Processo de Enfermagem
-Revisão de referências: 03 out. 2026. Vigência, alterações e relacionamentos serão reconferidos no gate editorial final.
-Continue pelos conteúdos relacionados para conectar norma, prática profissional e organização do cuidado.
+Aprofunde as bases profissionais, documentais e digitais que sustentam o Processo de Enfermagem e entenda as normas anteriores hoje revogadas.
+Lei 7.498/1986 + Decreto 94.406/1987
+Registros de Enfermagem - Cofen 514/2016
+Guia Cofen de Registros 2023
+Prescrições à distância - Cofen 689/2022
+Telenfermagem - Cofen 696/2022
+Prontuário digital - Lei 13.787/2018
+LGPD e dados de saúde
+Histórico: Cofen 358/2009 → 736/2024
+Histórico: Cofen 429/2012 → 754/2024
+Explore conceitos e aplicações derivados do mesmo conjunto normativo, com rastreabilidade por bloco.
+SAE e Processo de Enfermagem: qual é a diferença?
+Consulta de Enfermagem e Processo de Enfermagem
+Quem faz o quê no Processo de Enfermagem?
+Diagnóstico e Prescrição de Enfermagem
+Anotação e Evolução de Enfermagem: diferenças
+Como documentar o Processo de Enfermagem no prontuário
+Suporte teórico no Processo de Enfermagem
+Linguagens padronizadas no Processo de Enfermagem
+Avaliação de Enfermagem: dados, escalas e protocolos
+Planejamento de Enfermagem: resultados e prescrição
+Implementação e Evolução de Enfermagem
+Ver mapa completo de conteúdos relacionados
+CONSELHO FEDERAL DE ENFERMAGEM (Brasil). Resolução Cofen nº 736, de 17 de janeiro de 2024. Dispõe sobre a implementação do Processo de Enfermagem em todo contexto socioambiental onde ocorre o cuidado de enfermagem. Diário Oficial da União: seção 1, Brasília, DF, n. 16, p. 74, 23 jan. 2024. Disponível em: https://pesquisa.in.gov.br/imprensa/servlet/INPDFViewer?captchafield=firstAccess&data=23%2F01%2F2024&jornal=515&pagina=74 . Acesso em: 3 out. 2026.
+CONSELHO FEDERAL DE ENFERMAGEM (Brasil). Resolução Cofen nº 736, de 17 de janeiro de 2024. Dispõe sobre a implementação do Processo de Enfermagem em todo contexto socioambiental onde ocorre o cuidado de enfermagem. Brasília, DF: Cofen, 2024. Disponível em: https://www.cofen.gov.br/resolucao-cofen-no-736-de-17-de-janeiro-de-2024/ . Acesso em: 3 out. 2026.
+CONSELHO FEDERAL DE ENFERMAGEM (Brasil). Cofen atualiza resolução sobre implementação do Processo de Enfermagem. Brasília, DF: Cofen, 24 jan. 2024. Disponível em: https://www.cofen.gov.br/cofen-atualiza-resolucao-sobre-implementacao-do-processo-de-enfermagem/ . Acesso em: 3 out. 2026.
```
