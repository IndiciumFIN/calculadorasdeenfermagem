-- Reprodutível apenas no projeto Supabase Calculadoras-Smart; SELECT/read-only.
SELECT snapshot_id, source_id, length(content_text) AS len,
       encode(digest(convert_to(content_text,'UTF8'),'sha256'),'hex') AS sha256
FROM cko_evidence.snapshots
WHERE snapshot_id='SNAP-MON-07C620AF5BC36341D890A60B';

WITH s AS (SELECT content_text FROM cko_evidence.snapshots WHERE snapshot_id='SNAP-MON-07C620AF5BC36341D890A60B'),
c AS (SELECT substring(content_text FROM greatest(1,strpos(content_text,'Art. 1º')-130) FOR 18000) h FROM s),
p AS (SELECT n::int,regexp_replace(part,'^.*<p[^>]*>','','s') AS inner_html FROM c CROSS JOIN LATERAL regexp_split_to_table(h,'</p>') WITH ORDINALITY t(part,n)),
norm AS (SELECT n,inner_html,trim(regexp_replace(replace(replace(inner_html,'&nbsp;',' '),'&#8211;','–'),'<[^>]+>','','g')) plain FROM p)
SELECT n,left(plain,155) AS preview,encode(digest(convert_to(inner_html,'UTF8'),'sha256'),'hex') AS sha_inner_html
FROM norm WHERE plain ~ '^(Art[.]?[ ]*[0-9]+º|§[ ]*[1-5]º|I[IVX]*[ ]*–)' ORDER BY n;
