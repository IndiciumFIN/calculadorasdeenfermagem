# W0/W1 — microtarefas executadas

1. **W0-01: SHA e inventário** — arquivo de documentação (59 entradas), M08 (18) e M09 (16) abertos localmente; hashes confrontados; HTML e JSONL da Biblioteca recuperados; `dados/W0_INVENTARIO_ENTRADAS.csv`.
2. **W0-02: reconciliação entre fontes** — verificação do contrato canônico na main, M08/M09 nas PRs #39/#66, PMO no Drive e tabelas existentes em Supabase; divergência de IDs 736 preservada como candidato.
3. **W1-01: atomização de COFEN 754/2024** — fonte oficial inspecionada, snapshot no banco SHA recomputado, 16 segmentos normativos com SHA de conteúdo HTML por SQL somente leitura, NormAtoms candidatos.
4. **W1-02: reaproveitamento editorial** — recuperados 21 blocos e vinculadas 32 referências; 17 textos equivalentes byte a byte, quatro diferem no glifo do checklist.
5. **W1-03: complemento didático** — caso sintético, seis questões com justificativa, oito flashcards, checklist e projeções. Não reescreveu o artigo antigo.
6. **W1-04: QA e HOLD** — validação JSON Schema 2020-12 dos sidecars candidatos, testes negativos, manifesto SHA, recibos e decisão sem publicação.

## HOLDs

- A comparação histórica dos 12 `canonical_object` com violações de `provenance_refs` não foi reexecutada sobre os 12 arquivos originais; só está provada pelo relatório histórico. Exige os ZIPs correspondentes.
- Fonte de 754 e vigência sem recibo final de jurista/representante normativo; Snapshot textual no Supabase continua `PENDING_NORMATIVE_VALIDATION`.
- A rede de IDs legados e o alias de fontes 736 ainda não foram admitidos.
- 0 claims clínicos aprovados e 0 publicação.
