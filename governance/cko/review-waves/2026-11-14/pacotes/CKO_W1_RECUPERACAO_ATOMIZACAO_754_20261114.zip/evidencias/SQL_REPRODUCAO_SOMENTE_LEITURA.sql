-- Reprodutibilidade no Supabase; SELECT apenas, sem alterar dados.
SELECT snapshot_id, content_sha256,
  encode(digest(convert_to(content_text,'UTF8'),'sha256'),'hex') AS recomputed
FROM cko_evidence.snapshots WHERE snapshot_id='SNAP-MON-448784A961ADFDA701BE09AD';
WITH s AS (SELECT content_text FROM cko_evidence.snapshots
  WHERE snapshot_id='SNAP-MON-448784A961ADFDA701BE09AD'),
c AS (SELECT substring(content_text FROM greatest(1,strpos(content_text,'Art. 1º')-120) FOR 5100) AS h FROM s),
p AS (SELECT n::int,regexp_replace(part,'^.*<p[^>]*>','','s') AS inner_html
  FROM c CROSS JOIN LATERAL regexp_split_to_table(h,'</p>') WITH ORDINALITY AS t(part,n)),
norm AS (SELECT n,inner_html,trim(regexp_replace(inner_html,'<[^>]+>','','g')) AS plain FROM p)
SELECT n,left(plain,115) AS preview,
 encode(digest(convert_to(inner_html,'UTF8'),'sha256'),'hex') AS sha_inner_html
FROM norm WHERE plain ~ '^(Art[.]|§|Parágrafo Único)' ORDER BY n;
