# CKO W1 — Reuso + atomização COFEN 754/2024

**Estado:** DRAFT_EDITORIAL / HOLD_HUMAN / NO_PUBLICATION

## O que realmente foi executado
- Biblioteca: HTML integral recuperado e preservado com SHA-256 `01f75ab05f58254ea5a968185cd8ead90190e6a810994477658e5d7aa379135a`.
- Blocos: 21/21 com ID, 17 idênticos no texto e 4 equivalentes após retirar apenas `☐ `; 79 blocos encontrados no JSONL histórico (quatro conteúdos).
- Supabase: snapshot `SNAP-MON-448784A961ADFDA701BE09AD`, SHA-256 armazenado `448784a961adfda701be09ad6bb6cf8b0f89724abcf1189de0e186c28677950e`, recalculado por `digest(convert_to(content_text,'UTF8'),'sha256')` com correspondência.
- Estrutura COFEN 754: 9 artigos e 7 parágrafos (16 segmentos), 16 NormAtoms/16 evidências candidatas com hashes de `inner_html` calculados por SQL de leitura.
- 32 relacionamentos bloco->NormAtom; nenhum órfão; 14 dos 16 NormAtoms usados pelo HTML legado.
- 6 questões novas, 8 flashcards novos, caso fictício e checklist educacional no `CONTENT_MASTER_RECONCILED_754.md`.
- 7/7 testes locais negativos/integridade.
- Direitos, vigência jurídica exaustiva, aprovação clínica e editorial permanecem HOLD. Não houve writes em GitHub, Drive, Supabase ou site.

## Limites
- `NAT-754-*`, `CLM-*`, `KA-*` são IDs históricos, não prova de admissão no cânone nem de certificação clínica.
- Os hashes dos fragmentos são do conteúdo **inner HTML** dos parágrafos, não do PDF original nem de eventual texto normalizado.
- O SHA do snapshot é do texto armazenado no Supabase; foi recalculado no banco, não rebaixado a hash do ato original no DOU.
- O ZIP de excelência continha 59 entradas documentais; os oito ZIPs históricos citados nele não estão todos materializados neste lote.
