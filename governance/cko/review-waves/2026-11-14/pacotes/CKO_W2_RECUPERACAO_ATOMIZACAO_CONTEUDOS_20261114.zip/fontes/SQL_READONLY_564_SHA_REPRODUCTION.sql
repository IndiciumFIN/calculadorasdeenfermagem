-- READ ONLY. Supabase: Calculadoras-Smart. Original snapshot is unchanged.
select snapshot_id,content_sha256,
encode(digest(convert_to(content_text,'UTF8'),'sha256'),'hex') as recomputed
from cko_evidence.snapshots
where snapshot_id='SNAP-MON-4758C303A935A8119D60BEAA';
with s as (select content_text from cko_evidence.snapshots
 where snapshot_id='SNAP-MON-4758C303A935A8119D60BEAA'),
c as (select substring(content_text from greatest(1,strpos(content_text,'Art. 35')-50) for 4100) h from s),
p as (select n::int,regexp_replace(part,'^.*<p[^>]*>','','s') inner_html from c
 cross join lateral regexp_split_to_table(h,'</p>') with ordinality t(part,n)),
norm as (select n,inner_html,trim(regexp_replace(inner_html,'<[^>]+>','','g')) plain from p)
select n,left(plain,140) preview,
 encode(digest(convert_to(inner_html,'UTF8'),'sha256'),'hex') sha_inner_html,
 length(inner_html)::int len
from norm where plain ~ '^(Art. (35|36|37|38|46)(\s|$)|§ [12]º)' order by n;
