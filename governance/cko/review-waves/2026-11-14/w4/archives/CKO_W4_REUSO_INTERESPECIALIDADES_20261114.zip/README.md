# CKO W4 — Reutilização interdisciplinar do Processo de Enfermagem (14/11/2026)

**DRAFT_EDITORIAL / HOLD_HUMAN / NO_GO.** Onda dedicada a conteúdo educacional efetivo. Não há alteração da main, site ou Supabase.

## Entregas verificáveis

- Quatro **novos complementos de especialidade**, em Markdown completo, reutilizando o CORE de Processo de Enfermagem da W3 e M08/M09, sem reescrever ou sobrescrever o artigo principal.
- 4 casos fictícios comentados, 16 questões com gabaritos e justificativas, 16 flashcards e 4 checklists de estudo.
- Ledger de fontes oficiais, vínculos contextuais candidato→claim existente e registro da colisão UC07/UC08/UC09.
- QA estrutural local e gate de publicação.

## Escopos deliberadamente não ampliados

- Urgência: não fornece triagem, tratamento ou dosagens.
- Enfermagem do Trabalho: não interpreta integralmente NR-32 nem estabelece protocolo de exposição.
- Centro Cirúrgico/CME: não estabelece critérios SRPA nem reprocessabilidade de dispositivos.
- Cardiologia: não define cuidado ECMO, transplante, indicação de dispositivo ou solução curricular UC08.

## Provas de entrada

- W3 `CKO_W3_RECONCILIACAO_PE736_20261114.zip`, com artigo 112 blocos, CORE e companion.
- M09 `CKO_M09_CANONICAL_ATOMIC_REVIEW_2026-11-14.zip`, com claims candidatos e textos de PE/segurança, usando os IDs existentes.
- `IndiciumFIN/dev-chatgpt-workspace` PR #66, branch `cko/cardiologia-corpus-editorial-20261114`, com catálogo e conflitos curriculares.
- Textos oficiais de COFEN 736/2024, COFEN 754/2024, RDC 36/2013, RDC 15/2012, NR-32 e manual OMS 2009 (localizadores/URLs em `referencias/`).

## Gate clínico e direitos

Os vínculos contextuais são **candidatos sem verificação proposicional exaustiva**, embora apontem para IDs de claims reais de M08/M09. Fontes web atuais foram consultadas, sem criar hashes falsos ou provar vigência exaustiva. É indispensável revisão humana de cada aplicação especial, controle de direitos por operação, análise normativa e recibo de aprovação antes de qualquer publicação.
