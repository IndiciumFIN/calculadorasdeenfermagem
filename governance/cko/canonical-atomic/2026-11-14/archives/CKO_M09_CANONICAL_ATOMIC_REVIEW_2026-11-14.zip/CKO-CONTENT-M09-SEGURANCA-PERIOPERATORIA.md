# Segurança perioperatória: recorte normativo do Plano de Segurança do Paciente

> **Rascunho M09 — NÃO PUBLICAR.** Revisão de vigência, direitos e clínica pendente. Origem do conteúdo anterior: CKO-CONTENT-M08-SEGURANCA-PERIOPERATORIA.

## Gestão de risco e organização

- A direção do serviço de saúde abrangido deve instituir o Núcleo de Segurança do Paciente e nomear sua composição com as atribuições previstas. **[CKO-CLAIM-M08-PS-06]** (SRC-ANVISA-RDC36-2013 art. 4º; átomo ATM-c2a6d8a8fcd21c75b95b)
- Implantar protocolos de segurança do paciente e monitorar seus indicadores integra as competências do Núcleo de Segurança do Paciente. **[CKO-CLAIM-M08-PS-08]** (SRC-ANVISA-RDC36-2013 art. 7º, VI; átomo ATM-e0eccd28e6e2e21073ea)
- O Plano de Segurança do Paciente, elaborado pelo Núcleo, deve prever estratégias de gestão de riscos conforme as atividades do serviço de saúde. **[CKO-CLAIM-M08-PS-09]** (SRC-ANVISA-RDC36-2013 art. 8º; átomo ATM-1856900b1580c5922170)

## Práticas previstas no plano

- A identificação do paciente é uma das áreas contempladas pelas ações do Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-10]** (SRC-ANVISA-RDC36-2013 art. 8º, IV; átomo ATM-dbcb695f50a74ee46de7)
- A higiene das mãos é uma das áreas contempladas pelas ações do Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-11]** (SRC-ANVISA-RDC36-2013 art. 8º, V; átomo ATM-6d7c82e618b62e833d46)
- A segurança cirúrgica é uma das áreas contempladas pelas ações do Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-12]** (SRC-ANVISA-RDC36-2013 art. 8º, VI; átomo ATM-d02d37f7b31490b6cb01)
- A segurança na prescrição, no uso e na administração de medicamentos deve ser contemplada no Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-13]** (SRC-ANVISA-RDC36-2013 art. 8º, VII; átomo ATM-3bb244eef3b13532f106)
- O Plano de Segurança do Paciente deve contemplar estímulo à participação de pacientes e familiares na assistência. **[CKO-CLAIM-M08-PS-14]** (SRC-ANVISA-RDC36-2013 art. 8º, XVI; átomo ATM-6d90dcd3e125630f7d7d)

## Registro e monitoramento

- O monitoramento de incidentes e eventos adversos é atribuição do Núcleo de Segurança do Paciente. **[CKO-CLAIM-M08-PS-15]** (SRC-ANVISA-RDC36-2013 art. 9º; átomo ATM-fe05c83310f1445108e3)
- O Processo de Enfermagem deve ser documentado formalmente em prontuário físico ou eletrônico pelos integrantes da equipe, observadas suas responsabilidades. **[CKO-CLAIM-M08-PE-16]** (SRC-COFEN-736-2024 art. 8º; átomo ATM-453b13d0c6ffb9fb44aa)

## Atribuições e documentação — complementação M09

- Cabe ao enfermeiro registrar todas as etapas do Processo de Enfermagem; aos demais integrantes da equipe cabem os registros e as checagens relativos às suas responsabilidades profissionais. **[CKO-CLAIM-M09-PE-20]** (SRC-COFEN-736-2024 Art. 8º; átomo ATM-453b13d0c6ffb9fb44aa)

## Plano de Segurança do Paciente — complementação M09

- A prevenção de quedas dos pacientes integra as estratégias e ações previstas para o Plano de Segurança do Paciente. **[CKO-CLAIM-M09-PS-17]** (SRC-ANVISA-RDC36-2013 Art. 8º, XI; átomo ATM-36a0e175b9d1903cfb42)
- A prevenção de úlceras por pressão integra as estratégias e ações previstas para o Plano de Segurança do Paciente. **[CKO-CLAIM-M09-PS-18]** (SRC-ANVISA-RDC36-2013 Art. 8º, XII; átomo ATM-e1316592b0cd56579d4e)
- A comunicação efetiva entre profissionais e entre serviços de saúde é contemplada entre as ações do Plano de Segurança do Paciente. **[CKO-CLAIM-M09-PS-19]** (SRC-ANVISA-RDC36-2013 Art. 8º, XV; átomo ATM-f321c26debc25219bbb0)
- A promoção de ambiente seguro integra as estratégias previstas no Plano de Segurança do Paciente. **[CKO-CLAIM-M09-PS-23]** (SRC-ANVISA-RDC36-2013 Art. 8º, XVII; átomo ATM-cfa42bf82061dae0c3e8)

---
**Status:** SOURCE_EVIDENCE_BOUND; HUMAN_HOLD; PROHIBITED_PUBLICATION.
