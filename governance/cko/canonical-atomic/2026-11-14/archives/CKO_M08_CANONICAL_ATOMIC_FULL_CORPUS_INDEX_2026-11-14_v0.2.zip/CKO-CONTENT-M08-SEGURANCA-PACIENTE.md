# Segurança do paciente: Núcleo, Plano, risco e monitoramento

> **Rascunho normativo / NÃO PUBLICAR.** Claims rastreáveis ao corpus extraído; requer revisão de vigência, direitos por operação, revisão editorial e clínica.

Fonte estruturante: RDC Anvisa 36/2013.

## Objeto, abrangência e conceitos

- A RDC Anvisa 36/2013 institui ações para promover a segurança do paciente e melhorar a qualidade nos serviços de saúde. **[CKO-CLAIM-M08-PS-01]** (SRC-ANVISA-RDC36-2013 art. 1º; átomo ATM-b21c4d65d66d1a2a6c44).
- A RDC Anvisa 36/2013 abrange serviços de saúde públicos e privados e outros tipos de organização nela especificados, inclusive os que realizam ensino e pesquisa. **[CKO-CLAIM-M08-PS-02]** (SRC-ANVISA-RDC36-2013 art. 2º; átomo ATM-eaa7debe124ab513b7ee).
- A RDC Anvisa 36/2013 exclui explicitamente de seu escopo consultórios individualizados, laboratórios clínicos e serviços móveis e de atenção domiciliar. **[CKO-CLAIM-M08-PS-03]** (SRC-ANVISA-RDC36-2013 art. 2º, parágrafo único; átomo ATM-38ad17fdc58ef83ef992).
- Incidente é evento ou circunstância que poderia causar ou causou dano desnecessário à saúde. **[CKO-CLAIM-M08-PS-04]** (SRC-ANVISA-RDC36-2013 art. 3º, VII; átomo ATM-36d062b88b37d39454cf).
- Evento adverso é incidente que produz dano à saúde. **[CKO-CLAIM-M08-PS-05]** (SRC-ANVISA-RDC36-2013 art. 3º, IV; átomo ATM-f7acbd31ea03280f2244).

## Núcleo de Segurança do Paciente

- A direção do serviço de saúde abrangido deve instituir o Núcleo de Segurança do Paciente e nomear sua composição com as atribuições previstas. **[CKO-CLAIM-M08-PS-06]** (SRC-ANVISA-RDC36-2013 art. 4º; átomo ATM-c2a6d8a8fcd21c75b95b).
- Elaborar, implantar, divulgar e manter atualizado o Plano de Segurança do Paciente integra as competências do Núcleo de Segurança do Paciente. **[CKO-CLAIM-M08-PS-07]** (SRC-ANVISA-RDC36-2013 art. 7º, IV; átomo ATM-968b5ef613f118b45337).
- Implantar protocolos de segurança do paciente e monitorar seus indicadores integra as competências do Núcleo de Segurança do Paciente. **[CKO-CLAIM-M08-PS-08]** (SRC-ANVISA-RDC36-2013 art. 7º, VI; átomo ATM-e0eccd28e6e2e21073ea).

## Plano de Segurança do Paciente

- O Plano de Segurança do Paciente, elaborado pelo Núcleo, deve prever estratégias de gestão de riscos conforme as atividades do serviço de saúde. **[CKO-CLAIM-M08-PS-09]** (SRC-ANVISA-RDC36-2013 art. 8º; átomo ATM-1856900b1580c5922170).
- A identificação do paciente é uma das áreas contempladas pelas ações do Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-10]** (SRC-ANVISA-RDC36-2013 art. 8º, IV; átomo ATM-dbcb695f50a74ee46de7).
- A higiene das mãos é uma das áreas contempladas pelas ações do Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-11]** (SRC-ANVISA-RDC36-2013 art. 8º, V; átomo ATM-6d7c82e618b62e833d46).
- A segurança cirúrgica é uma das áreas contempladas pelas ações do Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-12]** (SRC-ANVISA-RDC36-2013 art. 8º, VI; átomo ATM-d02d37f7b31490b6cb01).
- A segurança na prescrição, no uso e na administração de medicamentos deve ser contemplada no Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-13]** (SRC-ANVISA-RDC36-2013 art. 8º, VII; átomo ATM-3bb244eef3b13532f106).
- O Plano de Segurança do Paciente deve contemplar estímulo à participação de pacientes e familiares na assistência. **[CKO-CLAIM-M08-PS-14]** (SRC-ANVISA-RDC36-2013 art. 8º, XVI; átomo ATM-6d90dcd3e125630f7d7d).

## Monitoramento e notificação

- O monitoramento de incidentes e eventos adversos é atribuição do Núcleo de Segurança do Paciente. **[CKO-CLAIM-M08-PS-15]** (SRC-ANVISA-RDC36-2013 art. 9º; átomo ATM-fe05c83310f1445108e3).
- A RDC Anvisa 36/2013 estabelece notificação mensal de eventos adversos pelo Núcleo de Segurança do Paciente, observadas as regras e prazos normativos aplicáveis. **[CKO-CLAIM-M08-PS-16]** (SRC-ANVISA-RDC36-2013 art. 10; átomo ATM-fa753adc3f3f2484cce1).

---
**Gate:** EVIDENCE_BOUND → revisão normativa → revisão de direitos, editorial e segurança clínica → aprovação humana → publicação.
