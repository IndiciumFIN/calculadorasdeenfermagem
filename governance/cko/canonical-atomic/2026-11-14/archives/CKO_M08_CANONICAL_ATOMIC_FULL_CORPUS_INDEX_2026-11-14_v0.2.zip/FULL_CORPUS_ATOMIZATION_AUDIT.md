# M08 — Auditoria completa dos átomos extraídos (metadados; sem texto bruto)

A tabela original `evidence_atoms` foi relida integralmente em SQLite **somente leitura** e serializada para CSV de metadados. Os textos NÃO foram redistribuídos: o índice traz hashes SHA-256 do trecho, fonte, documento, localização, classe de direitos, idioma e situação de review.

O arquivo `CORPUS_TOPIC_EVIDENCE_9102_CANDIDATES.csv` mantém os relacionamentos lexicais/semânticos **como candidatos, não como fontes aprovadas**. O arquivo `LEGACY_29_CLAIMS_HOLD_REVIEW.csv` registra 29 claims históricos sem propagar o estado de validação.

A construção de 34 claims novos é **um lote piloto de 2 normas**, não uma reclassificação automática dos 28.001 fragmentos existentes. Distinções: EVIDENCE_ATOM (transcrição) ≠ CLAIM (asserção validável) ≠ KNOWLEDGE_ATOM (proposição canônica admitida) ≠ CONTENT_MASTER (síntese editorial) ≠ PROJECTION (formato de entrega).

Nenhuma dessas tabelas deve ser importada diretamente como conteúdo publicado no CE. Requer direito de cada item, semântica, vigência e revisão independente.
