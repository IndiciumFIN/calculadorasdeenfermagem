# Segurança perioperatória: recorte normativo do Plano de Segurança do Paciente

> **Rascunho normativo / NÃO PUBLICAR.** Claims rastreáveis ao corpus extraído; requer revisão de vigência, direitos por operação, revisão editorial e clínica.

Fonte estruturante: COFEN 736/2024 e RDC Anvisa 36/2013.

## Gestão de risco e organização

- A direção do serviço de saúde abrangido deve instituir o Núcleo de Segurança do Paciente e nomear sua composição com as atribuições previstas. **[CKO-CLAIM-M08-PS-06]** (SRC-ANVISA-RDC36-2013 art. 4º; átomo ATM-c2a6d8a8fcd21c75b95b).
- Implantar protocolos de segurança do paciente e monitorar seus indicadores integra as competências do Núcleo de Segurança do Paciente. **[CKO-CLAIM-M08-PS-08]** (SRC-ANVISA-RDC36-2013 art. 7º, VI; átomo ATM-e0eccd28e6e2e21073ea).
- O Plano de Segurança do Paciente, elaborado pelo Núcleo, deve prever estratégias de gestão de riscos conforme as atividades do serviço de saúde. **[CKO-CLAIM-M08-PS-09]** (SRC-ANVISA-RDC36-2013 art. 8º; átomo ATM-1856900b1580c5922170).

## Práticas previstas no plano

- A identificação do paciente é uma das áreas contempladas pelas ações do Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-10]** (SRC-ANVISA-RDC36-2013 art. 8º, IV; átomo ATM-dbcb695f50a74ee46de7).
- A higiene das mãos é uma das áreas contempladas pelas ações do Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-11]** (SRC-ANVISA-RDC36-2013 art. 8º, V; átomo ATM-6d7c82e618b62e833d46).
- A segurança cirúrgica é uma das áreas contempladas pelas ações do Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-12]** (SRC-ANVISA-RDC36-2013 art. 8º, VI; átomo ATM-d02d37f7b31490b6cb01).
- A segurança na prescrição, no uso e na administração de medicamentos deve ser contemplada no Plano de Segurança do Paciente. **[CKO-CLAIM-M08-PS-13]** (SRC-ANVISA-RDC36-2013 art. 8º, VII; átomo ATM-3bb244eef3b13532f106).
- O Plano de Segurança do Paciente deve contemplar estímulo à participação de pacientes e familiares na assistência. **[CKO-CLAIM-M08-PS-14]** (SRC-ANVISA-RDC36-2013 art. 8º, XVI; átomo ATM-6d90dcd3e125630f7d7d).

## Registro e monitoramento

- O monitoramento de incidentes e eventos adversos é atribuição do Núcleo de Segurança do Paciente. **[CKO-CLAIM-M08-PS-15]** (SRC-ANVISA-RDC36-2013 art. 9º; átomo ATM-fe05c83310f1445108e3).
- O Processo de Enfermagem deve ser documentado formalmente em prontuário físico ou eletrônico pelos integrantes da equipe, observadas suas responsabilidades. **[CKO-CLAIM-M08-PE-16]** (SRC-COFEN-736-2024 art. 8º; átomo ATM-453b13d0c6ffb9fb44aa).

---
**Gate:** EVIDENCE_BOUND → revisão normativa → revisão de direitos, editorial e segurança clínica → aprovação humana → publicação.
