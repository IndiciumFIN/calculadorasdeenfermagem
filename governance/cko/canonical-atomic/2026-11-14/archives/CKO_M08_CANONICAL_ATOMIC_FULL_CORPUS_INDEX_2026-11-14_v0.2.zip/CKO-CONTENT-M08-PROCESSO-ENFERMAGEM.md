# Processo de Enfermagem: etapas, responsabilidades e registros

> **Rascunho normativo / NÃO PUBLICAR.** Claims rastreáveis ao corpus extraído; requer revisão de vigência, direitos por operação, revisão editorial e clínica.

Fonte estruturante: COFEN 736/2024.

## Fundamentos e organização

- O Processo de Enfermagem deve ser realizado deliberada e sistematicamente nos contextos onde ocorre cuidado de enfermagem. **[CKO-CLAIM-M08-PE-01]** (SRC-COFEN-736-2024 art. 1º; átomo ATM-4a876a36cd0d4d3d17fc).
- Os diagnósticos, resultados, indicadores e intervenções de enfermagem podem utilizar sistemas de linguagem padronizada, protocolos e evidências científicas como suporte. **[CKO-CLAIM-M08-PE-02]** (SRC-COFEN-736-2024 art. 3º; átomo ATM-4e64606ec6e71ce33839).
- O Processo de Enfermagem é organizado em cinco etapas relacionadas entre si e de caráter recorrente e cíclico. **[CKO-CLAIM-M08-PE-03]** (SRC-COFEN-736-2024 art. 4º; átomo ATM-ff3f126ecf286676e52e).

## Avaliação, diagnóstico e planejamento

- A Avaliação de Enfermagem compreende a coleta inicial e contínua de dados subjetivos e objetivos relacionados às necessidades de cuidado. **[CKO-CLAIM-M08-PE-04]** (SRC-COFEN-736-2024 art. 4º, § 1º; átomo ATM-53b6f9d2908d6e439425).
- O Diagnóstico de Enfermagem expressa julgamento clínico sobre informações da avaliação relacionadas a problemas, vulnerabilidades ou potencial de melhoria. **[CKO-CLAIM-M08-PE-05]** (SRC-COFEN-736-2024 art. 4º, § 2º; átomo ATM-be8403145873716f6d05).
- O Planejamento de Enfermagem desenvolve um plano assistencial compartilhado com os sujeitos do cuidado e com a equipe pertinente. **[CKO-CLAIM-M08-PE-06]** (SRC-COFEN-736-2024 art. 4º, § 3º; átomo ATM-d8520560089b1aac9015).
- A priorização dos diagnósticos de enfermagem integra o planejamento assistencial. **[CKO-CLAIM-M08-PE-07]** (SRC-COFEN-736-2024 art. 4º, § 3º, I; átomo ATM-8a418dd2de338a524699).
- A definição de resultados esperados e exequíveis integra o planejamento de enfermagem. **[CKO-CLAIM-M08-PE-08]** (SRC-COFEN-736-2024 art. 4º, § 3º, II; átomo ATM-e6913e14d05a504cf1d1).
- A prescrição de intervenções, ações ou atividades integra a tomada de decisão do planejamento de enfermagem. **[CKO-CLAIM-M08-PE-09]** (SRC-COFEN-736-2024 art. 4º, § 3º, III; átomo ATM-56ad6a1d0752519a24d6).

## Implementação e evolução

- A Implementação de Enfermagem corresponde à realização dos cuidados planejados pela equipe, observadas as competências profissionais. **[CKO-CLAIM-M08-PE-10]** (SRC-COFEN-736-2024 art. 4º, § 4º; átomo ATM-798cd5bf9e9f9e85c14a).
- A Evolução de Enfermagem avalia os resultados alcançados e subsidia a revisão do Processo de Enfermagem. **[CKO-CLAIM-M08-PE-11]** (SRC-COFEN-736-2024 art. 4º, § 5º; átomo ATM-b2826bb2afa283c94b62).

## Atribuições e documentação

- A consulta de Enfermagem deve ser organizada e registrada conforme as etapas do Processo de Enfermagem. **[CKO-CLAIM-M08-PE-12]** (SRC-COFEN-736-2024 art. 5º; átomo ATM-ccb7d39d8d6f7f338782).
- O Diagnóstico de Enfermagem é atribuição privativa do enfermeiro no Processo de Enfermagem, observada a legislação aplicável. **[CKO-CLAIM-M08-PE-13]** (SRC-COFEN-736-2024 art. 6º; átomo ATM-27596c438e5eeb2ad2a7).
- A Prescrição de Enfermagem é atribuição privativa do enfermeiro no Processo de Enfermagem, observada a legislação aplicável. **[CKO-CLAIM-M08-PE-14]** (SRC-COFEN-736-2024 art. 6º; átomo ATM-27596c438e5eeb2ad2a7).
- Técnicos e auxiliares participam do Processo de Enfermagem por registros e implementação/checagem de cuidados prescritos, sob supervisão e orientação do enfermeiro. **[CKO-CLAIM-M08-PE-15]** (SRC-COFEN-736-2024 art. 7º; átomo ATM-baa9a4612f6f22fd0ef3).
- O Processo de Enfermagem deve ser documentado formalmente em prontuário físico ou eletrônico pelos integrantes da equipe, observadas suas responsabilidades. **[CKO-CLAIM-M08-PE-16]** (SRC-COFEN-736-2024 art. 8º; átomo ATM-453b13d0c6ffb9fb44aa).

## Educação permanente

- Profissionais e instituições devem buscar meios para capacitação e qualificação no uso do Processo de Enfermagem. **[CKO-CLAIM-M08-PE-17]** (SRC-COFEN-736-2024 art. 9º; átomo ATM-ce7927065a94e0cc08a6).
- A educação permanente e a formação em enfermagem devem contemplar conteúdos que favoreçam a implementação do Processo de Enfermagem. **[CKO-CLAIM-M08-PE-18]** (SRC-COFEN-736-2024 art. 10; átomo ATM-824e4c3a521da499c31f).

---
**Gate:** EVIDENCE_BOUND → revisão normativa → revisão de direitos, editorial e segurança clínica → aprovação humana → publicação.
