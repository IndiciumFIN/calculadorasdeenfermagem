# M08 — Conteúdo canônico e atômico, lote 1

**Base:** fontes e documentos já recuperados no corpus original M03, mais confronto textual das páginas oficiais do COFEN 736/2024 e da RDC Anvisa 36/2013 (14/11/2026).

**Entrega:** 34 afirmações normativas distintas, com 33 evidências textuais específicas (o mesmo art. 6º da Resolução 736 subsidia duas atribuições privativas), 2 documentos HTML canônicos, 34 knowledge atoms candidatos, 3 content masters com 42 blocos vinculados, 8 questões com explicação e 10 flashcards.

**Nunca confundir:** 28.001 fragmentos de evidência NÃO são 28.001 knowledge atoms; 9.102 vínculos são candidatos; os 29 knowledge atoms legados não foram revalidados. Este lote não aprova conteúdo clínico, profissional nem licenças para IA externa.

**Fluxo:** fonte oficial → documento + SHA → evidence_atom ID + locator + SHA do trecho → claim (esquema CKO existente) → knowledge atom candidato → master editorial → projeções quiz/flashcard/artigo.

**Pendências:** versão vigente formal (com especial atenção à notificação art. 10), revisão de direitos por formato/operação, revisão independente clínica/editorial, especialidade contextual, ativação de conteúdo e publicação. O vínculo para Centro Cirúrgico e CME é contextual candidato, não grade ou estágio profissional.

**Validação:** 34/34 claims com texto e trecho efetivamente existentes no SQLite; todo vínculo fonte→documento→átomo e seus hashes conferidos; sem IDs órfãos nem recurso publicado.

**Originais:** corpus SQLite e ZIPs restritos permanecem intactos; este pacote contém somente sínteses próprias, IDs, hashes e metadados, sem republicar os textos integrais dos documentos.
